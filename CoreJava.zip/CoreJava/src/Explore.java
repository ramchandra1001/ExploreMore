import java.util.HashSet;

public class Explore {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet shortSet = new HashSet();
		for (short i = 0; i < 100; i++) 
		{
		shortSet.add(i);
		shortSet.remove(i-1);
		}
		System.out.println(shortSet.size());

		int x1 = 10*10-10;

		System.out.println(x1);
		
		String s1 = "abc";
		String s2 = "abc";

		System.out.println("s1 equals s2 is:" + s1.equals(s2));
		System.out.println(""+s1 == s2);
		
		int x = 5;
		int y = x++;
		int z = ++x;
			
		System.out.println("X: "+x);
		System.out.println("Y: "+y);
		System.out.println("Z: "+z);

	}

	
}
