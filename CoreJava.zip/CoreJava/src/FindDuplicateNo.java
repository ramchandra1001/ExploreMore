import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class FindDuplicateNo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a[] ={ 4,4,5,5,5,4,6,6,9,4}; 
		
		// Print unique number from the list- Amazon  
		//print the string in reverse 

		ArrayList<Integer>ab =new ArrayList<Integer>(); 
		//HashSet<Integer> ab= new HashSet<Integer>();
		for(int i=0;i<a.length;i++) 
		{ 
			int k=0; 
			if(!ab.contains(a[i])) 
			{ 
				ab.add(a[i]); 
				k++; 
				for(int j=i+1;j<a.length;j++) 
				{ 
					if(a[i]==a[j]) 
					{ 
						k++; 
					} 
				} 
				System.out.println(a[i]+ " is repeated "+k+" times"); 
				//System.out.println(k); 
				if(k==1) System.out.println(a[i]+" is unique number");  
			}
		}

	}

}
