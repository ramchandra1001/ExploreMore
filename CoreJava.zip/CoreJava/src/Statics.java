
public class Statics {

	static int count=0;
	
	public Statics()
	{
		count++;
	}
	
	public static void main(String[] args) {

		Statics s1= new Statics();
		Statics s2= new Statics();
		Statics s3= new Statics();
		
		System.out.println("Count: "+s1.count);

	}

}
