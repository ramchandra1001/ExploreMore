
public class PowerOfTwo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int N=24;
		  double rem=0;
	        int power=0;
	        int num=1;
		while(rem==0)
        {
            num=(int)Math.pow(2, power);
            rem=N%num;
          System.out.println(num);
            if(rem==0)
            {
                //rem=N%num;
                power=power+1;
            }
            else
            {
            	power--;
                break;
            }
            rem=N%num;
        }
      
		System.out.println("Power: "+power);
	}

}
