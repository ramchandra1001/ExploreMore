package alpha;

import org.apache.logging.log4j.LogManager;

import org.apache.logging.log4j.Logger;

public class Demo {

	
	public static Logger log=LogManager.getLogger(Demo.class.getName());
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		log.debug("I am in debug");
		log.info("object present");
		log.error("object not present");
		log.fatal("fatal error");
		
	}

}
