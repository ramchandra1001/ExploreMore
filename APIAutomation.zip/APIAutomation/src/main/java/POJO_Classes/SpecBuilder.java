package POJO_Classes;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import com.Learning.APIAutomation.Payload;
import com.fasterxml.jackson.databind.jsonschema.JsonSchema;
import com.github.fge.jsonschema.messages.JsonSchemaValidationBundle;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class SpecBuilder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AddPlace addPlace = new AddPlace();
		addPlace.setAccuracy(50);
		addPlace.setAddress("504 Greewoods India");
		addPlace.setLanguage("en-US");
		addPlace.setName("Atul");
		addPlace.setPhone_number("8605487744");
		addPlace.setWebsite("abcd.com");

		List<String> myList= new ArrayList<String>();
		myList.add("shoe park");
		myList.add("shop");
		addPlace.setTypes(myList);

		Locations l=new Locations();
		l.setLat(-38.383494);
		l.setLng(33.427362);
		addPlace.setLocation(l);

		//Request & Response Spec Builder
		RequestSpecification req= new RequestSpecBuilder().setBaseUri("https://rahulshettyacademy.com").addQueryParam("key", "qaclick123").setContentType(ContentType.JSON).build();
		ResponseSpecification resspec=new ResponseSpecBuilder().expectStatusCode(200).expectContentType(ContentType.JSON).build();
		
		//Add place  
		RequestSpecification res=given().log().all().spec(req).body(addPlace);
		Response response=res.when().post("maps/api/place/add/json").then().spec(resspec).extract().response();

		System.out.println(response.asString());

	}

}
