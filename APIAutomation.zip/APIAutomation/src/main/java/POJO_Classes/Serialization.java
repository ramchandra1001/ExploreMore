package POJO_Classes;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import java.util.ArrayList;
import java.util.List;

import com.Learning.APIAutomation.Payload;

import io.restassured.RestAssured;

public class Serialization {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AddPlace addPlace = new AddPlace();
		addPlace.setAccuracy(50);
		addPlace.setAddress("504 Greewoods India");
		addPlace.setLanguage("en-US");
		addPlace.setName("Atul");
		addPlace.setPhone_number("8605487744");
		addPlace.setWebsite("abcd.com");
		
		List<String> myList= new ArrayList<String>();
		myList.add("shoe park");
		myList.add("shop");
		addPlace.setTypes(myList);
		
		Locations l=new Locations();
		l.setLat(-38.383494);
		l.setLng(33.427362);
		addPlace.setLocation(l);
		
		RestAssured.baseURI="https://rahulshettyacademy.com";
		//Add place  
		String addResponse=given().log().all().queryParam("key", "qaclick123").header("Content-Type","application/json")
				.body(addPlace)
				.when().post("maps/api/place/add/json")
				.then().log().all().assertThat().statusCode(200).body("scope", equalTo("APP"))
				.header("Connection", "Keep-Alive").extract().response().asString();
		System.out.println(addResponse);
		

	}

}
