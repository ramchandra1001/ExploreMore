package POJO_Classes;

import java.util.List;

public class Courses {

	private List<WebAutomation> webautomation;
	private List<APIs> api;
	private List<Mobiles> mobile;
	
	public List<WebAutomation> getWebautomation() {
		return webautomation;
	}
	public void setWebautomation(List<WebAutomation> webautomation) {
		this.webautomation = webautomation;
	}
	public List<APIs> getApi() {
		return api;
	}
	public void setApi(List<APIs> api) {
		this.api = api;
	}
	public List<Mobiles> getMobile() {
		return mobile;
	}
	public void setMobile(List<Mobiles> mobile) {
		this.mobile = mobile;
	}


}
