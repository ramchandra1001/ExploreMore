package com.Learning.APIAutomation;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;

public class DynamicJson {

	@Test(dataProvider="UsersData")
	public void addUser(String name, String role)
	{
		RestAssured.baseURI="https://reqres.in/";

		//Add user
		String addBookResponse=given().log().all().header("Content-Type","application/json")
				.body(Payload.addUserPayload(name,role))
				.when().post("/api/users")
				.then().log().all().statusCode(201).extract().response().asString();

		JsonPath js=new JsonPath(addBookResponse);
		int userID=js.getInt("id");
		System.out.println(userID);

		//Delete user
		String deleteUserResponse=given().log().all().header("Content-Type","application/json")
				.when().delete("/api/users/"+userID+"")
				.then().log().all().statusCode(204).extract().response().asString();
		System.out.println("Deleting users: "+userID);
	}

	@DataProvider (name="UsersData")
	public Object[][] getData()
	{
		return new Object[][] {
			{"abcd","student"},
			{"xyz","hero"},
			{"lmn","actor"},
			{"opq","army"}
		};
	}
}
