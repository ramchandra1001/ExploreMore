package com.Learning.APIAutomation;

import org.testng.Assert;

import io.restassured.path.json.JsonPath;

public class ComplexJsonParse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JsonPath jsPath=new JsonPath(Payload.mockResponse());

		//1. Print No of courses returned by API
		System.out.println("Courses: "+jsPath.getInt("courses.size()"));
		//2.Print Purchase Amount
		System.out.println("Purchase Amount: "+jsPath.getString("dashboard.purchaseAmount"));
		//3. Print Title of the first course
		System.out.println("Title of First Course: "+jsPath.getString("courses[0].title"));
		//4. Print All course titles and their respective Prices
		for(int i=0;i<jsPath.getInt("courses.size()");i++)
		{
			System.out.println("Title: "+jsPath.getString("courses["+i+"].title")+" ---- Price: "+jsPath.getString("courses["+i+"].price"));
		}

		//5. Print no of copies sold by RPA Course
		for(int i=0;i<jsPath.getInt("courses.size()");i++)
		{
			if(jsPath.getString("courses["+i+"].title").equalsIgnoreCase("RPA"))
			{
				System.out.println("RPA sold copies:"+jsPath.getInt("courses["+i+"].copies"));
				break;
			}
		}

		//6. Verify if Sum of all Course prices matches with Purchase Amount
		int purchaseAmt=jsPath.getInt("dashboard.purchaseAmount");
		int courseSum=0;
		for(int i=0;i<jsPath.getInt("courses.size()");i++)
		{
			courseSum=courseSum+(jsPath.getInt("courses["+i+"].price")*jsPath.getInt("courses["+i+"].copies"));
		}
		Assert.assertEquals(purchaseAmt, courseSum);

	}

}
