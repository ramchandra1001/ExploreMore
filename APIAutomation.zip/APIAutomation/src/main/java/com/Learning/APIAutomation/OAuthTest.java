package com.Learning.APIAutomation;
import io.restassured.RestAssured;
import io.restassured.parsing.Parser;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import POJO_Classes.GetCourse;

public class OAuthTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//-----------------Grant type= Authorization code-----------------		
		
		//Hit the URL to get the code from the Authorization server end point
		
/*		System.setProperty("webdriver.chrome.driver","C:\\Projects\\Eclipse_Learning\\APIAutomation\\Drivers_Jars\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("");
		driver.findElement(By.id("user")).sendKeys("username");
		driver.findElement(By.id("pwd")).sendKeys("password1235");
		String currentURL=driver.getCurrentUrl();
*/
		//Getting authorization code from url-this url is from browser when you select google option to login
		//Front end is not possible as google blocked such authentication, google may bring back this again but now its blocked
		//This step is not required for Client Credentials grant type
		
		String currentURL="https://rahulshettyacademy.com/getCourse.php?state=verifyfjdss&code=4%2FvAHBQUZU6o4WJ719NrGBzSELBFVBI9XbxvOtYpmYpeV47bFVExkaxWaF_XR14PHtTZf7ILSEeamywJKwo_BYs9M&scope=email+https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.email+openid&authuser=0&session_state=0c32992f0d47e93d273922018ade42d1072b9d1f..a35c&prompt=none#";
		
		//Parse the url to get the code=asdhkjahsdjhasfgkagfk
		String code=null;
		String partialCode=currentURL.split("code=")[1];
		code=partialCode.split("&scope")[0];
		System.out.println("Code: "+code);
		
		//Hit the end point with the code received from authorization end point
		String accessTokenResponse= given().log().all().urlEncodingEnabled(false)
				.queryParam("code", code)
				.queryParam("client_id", "692183103107-p0m7ent2hk7suguv4vq22hjcfhcr43pj.apps.googleusercontent.com")
				.queryParam("client_secret", "erZOWM9g3UtwNRj340YYaK_W")
				.queryParam("redirect_url", "https://rahulshettyacademy.com/getCourse.php")
				.queryParam("grant_type", "authorization_code")
				.queryParam("", "")
				.when().post("https://www.googleapis.com/oauth2/v4/token")
				.then().extract().response().asString();
				
		JsonPath js= new JsonPath(accessTokenResponse);
		String accessToken=js.getString("access_token");
		
		//Hit the actual end point of application to get the actual response from application
		String response=given().log().all().queryParam("access_token", accessToken)
		.when().get("https://rahulshettyacademy.com/getCourse.php")
		.then().log().all().assertThat().statusCode(200).extract().response().asString();
		System.out.println("Response: "+response);
		
		///POJO implementations
		
		GetCourse gc=given().queryParam("access_token", "").expect().defaultParser(Parser.JSON)
				.when().get("").as(GetCourse.class);
		System.out.println(gc.getLinkedIn());
		System.out.println(gc.getInstructor());
		
	}

}
