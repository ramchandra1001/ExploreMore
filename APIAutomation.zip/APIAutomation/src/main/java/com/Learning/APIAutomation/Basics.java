package com.Learning.APIAutomation;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import org.testng.*;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;


public class Basics {

	public static void main(String[] args) {
		
		System.out.println("Hello");
	
		RestAssured.baseURI="https://rahulshettyacademy.com";
		
		//Given - Input parameters, headers etc.
		//When - Submit the API call
		//Then - Validate the response

		//Add place  
		String addResponse=given().log().all().queryParam("key", "qaclick123").header("Content-Type","application/json")
				.body(Payload.addPlacePayload())
				.when().post("maps/api/place/add/json")
				.then().log().all().assertThat().statusCode(200).body("scope", equalTo("APP"))
				.header("Connection", "Keep-Alive").extract().response().asString();

		System.out.println("response: "+addResponse);

		JsonPath jp= new JsonPath(addResponse);
		String placeId=jp.getString("place_id");
		
		System.out.println("Place: "+placeId);
		
		String newAddress="7 NCR Delhi India";
		
		//Update place
		String updateResponse=given().log().all().queryParam("key", "qaclick123").header("Content-Type","application/json")
		.body(Payload.updatePlacePayload(placeId, newAddress))
		.when().put("maps/api/place/update/json")
		.then().log().all().assertThat().statusCode(200).body("msg", equalTo("Address successfully updated"))
		.extract().response().asString();
		
		System.out.println("Response: "+updateResponse);
		
		//Get Place
		String getResponse=given().log().all().queryParam("key", "qaclick123").header("Content-Type", "application/json")
		.queryParam("place_id",placeId)
		.when().get("maps/api/place/get/json")
		.then().log().all().statusCode(200).extract().response().asString();
		
		JsonPath js1=ReusableUtilities.getRawJson(getResponse);
		String actulAddress=js1.getString("address");
		
		System.out.println("Actual Address: "+actulAddress);
		Assert.assertEquals(actulAddress, "7 NCR Delhi India");
		
		
	}

}
