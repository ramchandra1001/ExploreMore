package com.Learning.APIAutomation;

import org.testng.annotations.Test;

import io.restassured.path.json.JsonPath;

public class SumValidation {

	@Test
	public void sumofCopies()
	{
		JsonPath jsp=new JsonPath(Payload.mockResponse());
		int purchaseAmt=jsp.getInt("dashboard.purchaseAmount");
		int courseSum=0;
		for(int i=0;i<jsp.getInt("courses.size()");i++)
		{
			courseSum=courseSum+(jsp.getInt("courses["+i+"].price")*jsp.getInt("courses["+i+"].copies"));
		}
	}
}
