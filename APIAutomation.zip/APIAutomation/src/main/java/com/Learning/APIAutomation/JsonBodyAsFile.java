package com.Learning.APIAutomation;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class JsonBodyAsFile {
	
	@Test
	public void createUser() throws IOException
	{
		RestAssured.baseURI="https://reqres.in/";

		//Add user
		String addBookResponse=given().log().all().header("Content-Type","application/json")
				.body(new String (Files.readAllBytes(Paths.get("C:\\Projects\\Eclipse_Learning\\APIResources\\AddUser.json"))))
				.when().post("/api/users")
				.then().log().all().statusCode(201).extract().response().asString();

		JsonPath js=new JsonPath(addBookResponse);
		int userID=js.getInt("id");
		System.out.println(userID);
	}

}
