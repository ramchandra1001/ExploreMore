package com.Learning.APIAutomation;

import io.restassured.path.json.JsonPath;

public class ReusableUtilities {

	public static JsonPath getRawJson(String response)
	{
		JsonPath js=new JsonPath(response);
		return js;
	}
}
