/**
 * 
 */
function add_numbers(a, b) {
	c=a+b;
	document.getElementById("123").innerHTML=c;
	console.log(c);
    return a + b;
}
