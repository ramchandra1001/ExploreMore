/**
 * 
 */
getAllElements();
function getAllElements() {
	var parentElement="body";
	var tags=['label','input','button'];
	var locators=['id','name','class','for','type'];
	var element='';
	var ele=document.getElementsByTagName(parentElement);
	var elementName=null;
	var elementLocator=null;
	var elementAttribute=null;
	var fileContents='';

	for (var i=0;i<ele[0].children.length;i++)
	{
		for (var k=0;k<tags.length;k++)
		{
			if (ele[0].children[i].localName==tags[k])
			{
				for (var j=0;j<locators.length;j++)
				{
					if(!ele[0].children[i].innerHTML) elementName=tags[k]+'_'+i+'_'+j;
					else elementName=ele[0].children[i].innerText+'_'+i+'_'+j;
					elementAttribute=ele[0].children[i].getAttribute(locators[j]);
					if(elementAttribute)
					{
						elementLocator="//"+ele[0].children[i].localName+'[@'+locators[j]+'='+"'"+elementAttribute+"']";
						//console.log(elementName+'_'+ elementLocator);
						fileContents=fileContents+elementName+'			'+'xpath'+'			'+elementLocator+'\n';
						break;
					}
				}
			}
		}
	}
	return '@objects'+'\n'+fileContents;
}
