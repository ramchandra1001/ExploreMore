package ApachePOI;


import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class JsonAsHashMap {

	@Test
	public void addUser() throws IOException
	{
		DataDriven dr= new DataDriven();
		ArrayList a=dr.getData("AddUser","RestAssured");
		RestAssured.baseURI="https://reqres.in/";
		
		Map<String, Object> jsonAsMap=new HashMap<String, Object>();
		jsonAsMap.put("name", a.get(1));
		jsonAsMap.put("job", a.get(2));
		
		//Add user
		String addBookResponse=given().log().all().header("Content-Type","application/json")
				.body(jsonAsMap)
				.when().post("/api/users")
				.then().log().all().statusCode(201).extract().response().asString();

		JsonPath js=new JsonPath(addBookResponse);
		int userID=js.getInt("id");
		System.out.println(userID);

		//Delete user
		String deleteUserResponse=given().log().all().header("Content-Type","application/json")
				.when().delete("/api/users/"+userID+"")
				.then().log().all().statusCode(204).extract().response().asString();
		System.out.println("Deleting users: "+userID);
	}

}
