package com.fisglobal.ktt.business.keywords.galen;

import static com.fisglobal.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.fisglobal.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.fisglobal.ktt.view.config.KTTGuiConstants.EMPTY_STRING;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.fisglobal.ktt.business.keywords.AbstractKeyword;
import com.fisglobal.ktt.business.keywords.KeywordUtilities;
import com.fisglobal.ktt.model.valueobjects.TestcaseExecutionResultVO;
import com.fisglobal.ktt.view.config.KTTGuiConstants;

public class CreateGalenSpec extends AbstractKeyword {
	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
	private String topLocator = null;
	private WebElement topPageElement = null;
	private String specFilePath = null;
	private String specFileName = null;
	private String frameName = null;
	private String htmlControlToCheck = null;	
	private String attributesToCheck=null;
	private String uniqueLocatorSequence=null;
	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();

	
	
	@Override
	public TestcaseExecutionResultVO validateKeyword(String... listOfParameters) {
		topLocator=listOfParameters[0];
		specFilePath=listOfParameters[1];
		specFileName=listOfParameters[2];		
		htmlControlToCheck=listOfParameters[3];
		attributesToCheck=listOfParameters[4];
		uniqueLocatorSequence=listOfParameters[5];
		
		if(topLocator==null || topLocator.isEmpty()){
			topLocator="@xpath=//body";			
		}
		
		if(specFilePath==null || specFilePath.isEmpty()){
			logger.error(ERROR_PARAMETERS_LIST);
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}
		if(specFileName==null || specFileName.isEmpty()){
			logger.error(ERROR_PARAMETERS_LIST);
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}		
		if(htmlControlToCheck==null || htmlControlToCheck.isEmpty()){
			htmlControlToCheck="label,input,select";
		}				
		if(attributesToCheck==null || attributesToCheck.isEmpty()){
			attributesToCheck="height,width,text";
		}
		if(uniqueLocatorSequence==null || uniqueLocatorSequence.isEmpty()){
			uniqueLocatorSequence="name,id,title,fisid,sgid";
		}
		
		
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}

	@Override
	public TestcaseExecutionResultVO validateObject(String... listOfParameters) {
		if (webDriver == null) {
			logger.error ("ERROR_BROWSER_NOT_INSTANTIATED");
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}
		
		topPageElement=KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap,webDriver, topLocator,"1", userName);
		if (topPageElement==null) {

			logger.error ("ERROR_REQUIRED_ELEMENT_NOT_FOUND");
			testCaseExecutionResult.setMessage("ERROR_REQUIRED_ELEMENT_NOT_FOUND");
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}

		try{
			File specFile=new File(specFilePath);
			specFile=null;
		}
		catch(Exception e){
			logger.error ("ERROR While creating file",e);
			testCaseExecutionResult.setMessage("ERROR While creating file"+e.getMessage());
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}
		frameName=getAllSelectedFramesDriver(webDriver);		
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}

	
	
	
	
	private String getTopLocator(String topLocator){
		
		String part1=topLocator.substring(0,topLocator.indexOf('='));
		String part2=topLocator.substring(topLocator.indexOf('=')+1,topLocator.length());
		if(part1.startsWith("@")){
			part1=part1.substring(1, part1.length());			
		}
		
		if(!part1.equals("xpath")){
			return "//*[@"+part1+"='"+part2+"']";
		}
		else{
			return part2;
		}
	}
	
	
	private static String getAllSelectedFramesDriver(WebDriver webDriver)
	{
		String actualSelectedFrames="";
		try {
			String selectedFrames=
					"f();function f()"
							+ "{"
							+ "	var AllFrames='';"
							+ "	var win=window;"
							+ "	while(win.parent && win.parent != win)"
							+ "	{"
							+ "	var winframeid='';"
							+ "	try{winframeid=win.frameElement.id;}catch(e1){winframeid='';}"
							+ "	if(winframeid=='')"
							+ "	{"
							+ "		try{winframeid=win.frameElement.name;}catch(e1){winframeid='';}"
							+ "	}"
							+ "		if(winframeid!=''){AllFrames=AllFrames+';'+winframeid;}"
							+ "	try"
							+ "		{"
							+ "			win=win.parent;"
							+ "		}"
							+ "	catch(e)"
							+ "		{win=null;}"
							+ "	}"
							+ "	return AllFrames;"
							+ "}"; 

			String gotSelectedFrames="";

			try {
				gotSelectedFrames=((JavascriptExecutor)webDriver).executeScript("return "+ selectedFrames).toString();
			} catch (Exception e1) {
				gotSelectedFrames="";
			} 

			if(!EMPTY_STRING.equals(gotSelectedFrames))
			{
				String[] selectedFrame=gotSelectedFrames.split(";");
				for (int j=selectedFrame.length-1;j>=0;j--)
				{
					if (j==selectedFrame.length-1)
					{
						actualSelectedFrames=selectedFrame[j];
					}
					else
					{
						actualSelectedFrames=actualSelectedFrames+";"+selectedFrame[j];
					}
				}
			}
			
		} catch (Exception e) {}
		return actualSelectedFrames;
	}


	public TestcaseExecutionResultVO executeScript(String... params) {
		
		String attributesToCheck="height,width,text";
		
		String sGetElements=

		"		CapturePageData(arguments[0],arguments[1]);	var ele=null;		"+
		 "		function CapturePageData(reqTopElement,newlineChar)		"
		 + "{"+
			"		var topElementXpath=\""+getTopLocator(topLocator)+"\";"+
			
			" 		var sHtmlElement=\""+htmlControlToCheck+"\";"+
			"		var  sAttributes=\""+attributesToCheck+"\";"+
			" 		var arrHtmlElements=sHtmlElement.split(',');"+
			" 		var arrAttributes=sAttributes.split(',');"+
			
			"		var  attForVarName=\""+uniqueLocatorSequence+"\";"+
			"		var  attributesForVarName=attForVarName.split(',');"+
			"		var newline=newlineChar;"+
			"		var strRetvar=null;"+
			"		var strCapturedObj='@objects'+newline+'=============================================================='+newline;"+
			"		var strCapturedAttribute='';"+
			"		var topElement = reqTopElement;"+
			"		var tagElements=null;	"+
			"		var objLocator=null;"+
			"		var varName=null;	"+
			"		var type='';"+
			"		var attrib='';"
			+ "     var bHiddenEle=false;"+
			" 		var isLocatorFound=false;"+
			"	    var isNotForTD=false;"+
			"		for(var i=0;i<arrHtmlElements.length;i++)"
			+ "{"+
			"			tagElements=topElement.getElementsByTagName(arrHtmlElements[i]);"
			
			+"			if(tagElements.length > 0)"
			+ "			{	"+
			
			"				for(var tagIndex=0;tagIndex < tagElements.length;tagIndex++)"
			+ "				{ele=tagElements[tagIndex];bHiddenEle=isHidden(ele);"+
			"					if(!bHiddenEle)"
		
			+ "					{"+
			"					varName='';" +			
			"					if(arrHtmlElements[i].toUpperCase()=='LABEL')"
			+ "						{"+
			"						varName=tagElements[tagIndex].innerText;"+
			"						if(varName!=null && varName.length > 0)"
			+ "						{"+
			"							varName='LABEL_'+varName.replace(/[\\*\\s:,]/g,'')+'_'+tagIndex+'    ';	"+
			"						}"+
			"						else{"+
			"							varName='LABEL_'+tagIndex+'    ';	"+
			"						}"+
			"					}"+
			"					else if(arrHtmlElements[i].toUpperCase()=='TD'){"+
			" 						if(tagElements[tagIndex].children.length==0){isNotForTD=false;"+
			"						varName=tagElements[tagIndex].innerText;"+
			"						if(varName!=null && varName.length > 0)"
			+ "						{"+
			"							varName='TD_'+varName.replace(/[\\*\\s:,]/g,'')+'_'+tagIndex+'    ';	"+
			"						}"+
			"						else{"+
			"							varName='TD_'+tagIndex+'    ';	"+
			"						}"+
			"					}else{isNotForTD=true;}"+
			
			"					}"+
			"					else{"+
			"						for(var varIndex=0;varIndex<attributesForVarName.length;varIndex++){"+
			
			"							attrib=tagElements[tagIndex].getAttribute(attributesForVarName[varIndex]);"+
			"							if(attrib!=null && attrib.length>0){						"+
			"								type='';"+
			"								if(arrHtmlElements[i].toUpperCase()=='INPUT'){"+
			"									type=tagElements[tagIndex].getAttribute('type');"+
			"								}"+
			"								if(type!=null && type.length>0 ){"+
			"									varName=arrHtmlElements[i].toUpperCase()+'_'+type+'_'+attrib+'_'+tagIndex;"+
			"								}"+
			"								else{varName=arrHtmlElements[i].toUpperCase()+'_'+attrib+'_'+tagIndex;}"+
			"								varName=varName.replace(/[\\*\\s,]/g,'');"+
			"								 if(attributesForVarName[varIndex]!='id' ){"+
			"									objLocator=topElementXpath+'//'+arrHtmlElements[i]+'[@'+attributesForVarName[varIndex]+'=\"'+attrib+'\"]';"+
			"									isLocatorFound=true;"+
			"								}"+
			
			"								 if(type!=null && type.toUpperCase().indexOf('RADIO')==0 ){"+
			"									var rInst=tagIndex+1;"+
			"									objLocator='('+topElementXpath+'//'+arrHtmlElements[i]+')['+rInst+']';"+
			"									isLocatorFound=true;"+
			"								}"+
			
			"								break;"+
			"							}"+
			"						}"+
			"						if(varName.length==0){"+
			"								varName=arrHtmlElements[i].toUpperCase()+'_'+tagIndex;"+
			"						}"+
			"					}"+
			"					var inst=tagIndex+1;"+			
			"					if(isLocatorFound==false && !isNotForTD){"+
			"						objLocator='('+topElementXpath+'//'+arrHtmlElements[i]+')['+inst+']';"+
			"					}"+
			"					isLocatorFound=false;"+
			"					objLocator='		xpath		'+objLocator+newline;"+
			"					if(tagElements[tagIndex].offsetHeight!=0 && tagElements[tagIndex].offsetWidth!=0 && !isNotForTD){"+
			"						strCapturedObj=strCapturedObj+varName+objLocator;"+
			"						strCapturedAttribute=strCapturedAttribute+varName+newline;	"+
			"						for(var attribCnt=0;attribCnt<arrAttributes.length;attribCnt++){"+			
			"							switch(arrAttributes[attribCnt]) {"+
			"								case 'height':"+			
			"									  strCapturedAttribute=strCapturedAttribute+'    height: '+tagElements[tagIndex].offsetHeight+'px'+newline;"+
			"										break;"+
			"								case 'width':"+			
			"										strCapturedAttribute=strCapturedAttribute+'    width: '+tagElements[tagIndex].offsetWidth+'px'+newline;"+
			"										break;"+
			"								case 'text':"+
			"											var value1='';"+
			"											if(arrHtmlElements[i].toUpperCase()=='LABEL' || arrHtmlElements[i].toUpperCase()=='SPAN'){"+
			"													var lText=getTextFromNode(tagElements[tagIndex]);"+
			"												if(trim(lText).length==0){"+
			"													strCapturedAttribute=strCapturedAttribute+'    text matches: \\\\s{'+lText.length+'}'+newline;}"+
			
			"												else{strCapturedAttribute=strCapturedAttribute+'    text is: '+lText+newline;}"+

			"											}"+
			"											else if(arrHtmlElements[i].toUpperCase()=='TD' ){"+
			"												var tdText=tagElements[tagIndex].innerText;"+
			"												if(trim(tdText).length==0 && tagElements[tagIndex].innerHTML.indexOf('&nbsp;')!=0){"+
			"													strCapturedAttribute=strCapturedAttribute+'    text matches: \\\\s{'+tdText.length+'}'+newline;}"+
			
			"												else{strCapturedAttribute=strCapturedAttribute+'    text is: '+tdText+newline;}"+
			"											}"+
			"											else if(arrHtmlElements[i].toUpperCase()=='SELECT'){"+
			"												value1=tagElements[tagIndex].getAttribute('value');"+
			"												if(value1==null){value1=tagElements[tagIndex].value;}"+
			"											 var options=tagElements[tagIndex].getElementsByTagName('option');"+
			"												for(var cnt1=0;cnt1<options.length;cnt1++){"+
			"													if(options[cnt1].value==value1){"+			
			"														if(trim(options[cnt1].innerText).length==0){"+
			"															strCapturedAttribute=strCapturedAttribute+'    text matches: \\\\s{'+options[cnt1].innerText.length+'}'+newline;}"+
			
			"														else{strCapturedAttribute=strCapturedAttribute+'    text contains: '+options[cnt1].innerText+newline;}"+
			"													}"+
			"												}"+
			"											}"+
			"											else{"+
			"												value1=tagElements[tagIndex].getAttribute('value');"+
			"												if(value1==null){value1=tagElements[tagIndex].value;}"+
			"													if( value1!=null && value1.length > 0   ){"+
			
			"															if(trim(value1).length==0){"+
			"																strCapturedAttribute=strCapturedAttribute+'    text matches: \\\\s{'+value1.length+'}'+newline;}"+
			
			"																else{strCapturedAttribute=strCapturedAttribute+'    text is: '+value1+newline;}"+
			"													}"+
			"													else{"+
			"															if(trim(tagElements[tagIndex].innerText).length==0){strCapturedAttribute=strCapturedAttribute+'    text matches: \\\\s{'+tagElements[tagIndex].innerText.length+'}'+newline;}"+
			
			"															else{strCapturedAttribute=strCapturedAttribute+'    text is: '+tagElements[tagIndex].innerText+newline;		}"+
			
			"											}"+
			"										}"+
			
			"							}"+			
			"					}"+
			"				}isNotForTD=false;"+			
			"			}"+
			
			"		}"+
			"	}"+
			"}"+
			
			"var blockSeperator='=============================================================='+newline+newline;"+
			"		return strCapturedObj+blockSeperator+strCapturedAttribute;"+
			"}"+
			"function isHidden(eleToCheck){" +
			"try{var tmpEle=eleToCheck;"+
			"var style = window.getComputedStyle(tmpEle);"+
			"if(style.display == 'none' || style.visibility == 'hidden' || style.getPropertyValue('opacity') == 0){ return true;}" +
			"else{tmpEle=tmpEle.parentElement;" +
			"	while(tmpEle.tagName!='BODY'){" +
			
			"		if(window.getComputedStyle(tmpEle).display == 'none'){ return true;}" +
			"		if(window.getComputedStyle(tmpEle).getPropertyValue('opacity') == 0){return true;}"+
		
			"   tmpEle=tmpEle.parentElement;}"+
			"	}" +
			" }"+			
			"catch(e){"+
			"var tmpEle=ele;" +
			"	while(tmpEle.tagName!='BODY'){" +
			"		if(tmpEle.type =='hidden' || tmpEle.style.display == 'none' || tmpEle.style.visibility == 'hidden' || tmpEle.style.opacity == 0){ return true;}" +
			"		tmpEle=tmpEle.parentElement;"+			
			"	}" +
			" }"+			
			"return false;}"+
			
			
			/*"function getEleText(ele){" +
			"		var tmpElement=ele;"+
			" var tmpTxt=tmpElement.innerText;"+
			"var newText='';"+
			"		if(trim(tmpTxt).length==0){tmpTxt='';}"+
			"		if(tmpElement!=null && !isHidden(tmpElement) && tmpElement.children.length > 0){"+
			"			while(tmpElement.children.length!=0){"+
			"				tmpElement=tmpElement.children(tmpElement.children.length-1);"+
			
			"			}"+
			"		}"+
			//"	if(tmpElement.innerText==null || tmpElement.innerText.length == 0){return tmpTxt;}"+
			"		return tmpElement.innerText;"+
			"}"+*/
			
			"function getTextFromNode(node) {"+
			"	var i, result, text, child;"+
			"	result = '';"+
			"	for (i = 0; i < node.childNodes.length; i++) {"+
			"	child = node.childNodes[i];"+
			"	text = null;"+
			"	if (child.nodeType === 1 && !isHidden(child)) {"+
			"	   text = getTextFromNode(child);"+
			"	} else if (child.nodeType === 3) {"+
			"	     text = child.nodeValue;"+
			"  	}"+
			"   if (text) {"+			   
			"         result += text;"+
			"      }"+
			"   }"+
			"    return result;"+
			"}"+	
			
			
			"		function trim(s){return s.replace(/^\\s*/,\"\").replace(/\\s*$/, \"\");}";
		
			String sgetBrowser=configurationMap.get("SAFAL_BROWSER_NAME");
			if(sgetBrowser==null){
				sgetBrowser=EMPTY_STRING;
			}
			
			String domStructure="";
			
			try{
				if(sgetBrowser.toUpperCase().contains(KTTGuiConstants.INTERNET_EXPLORER_STRING)) //End of SAF-2665 changes completed  
				{
					domStructure= ((JavascriptExecutor)webDriver).executeScript("return "+sGetElements,topPageElement,"\r\n").toString();
					
				}
				else
				{
					sGetElements=sGetElements.replaceAll("innerText", "textContent");
					domStructure= ((JavascriptExecutor)webDriver).executeScript("return "+sGetElements,topPageElement).toString();
				}
			} catch (Exception e) {
				logger.error("Failed to get table data",e);				
				testCaseExecutionResult.setMessage(e.getMessage());
				return testCaseExecutionResult;
			}	
			
			
			try{
						if(domStructure!=null && !domStructure.isEmpty()){
						if(frameName==null || frameName.isEmpty()){
								
								FileWriter fw=new FileWriter(specFilePath+File.separator+specFileName+".spec");		
								fw.write(domStructure);
								fw.flush();
								fw.close();
						}
						else{
							String[] frameArr=frameName.split(";");							
							for(int fcnt=0;fcnt<frameArr.length;fcnt++){
								if(frameArr[fcnt].trim().length() > 0){
							FileWriter fwMaster=new FileWriter(specFilePath+File.separator+specFileName+"_Master_"+fcnt+".spec");
							String master="@objects\r\n"+
			"==============================================================\r\n"+
		
			frameArr[fcnt]+"-frame     css	   iframe#"+frameArr[fcnt]+"\r\n"+
		
			"==============================================================\r\n"+
		
			frameArr[fcnt]+"-frame\r\n";
							if(fcnt+1 != frameArr.length ){
								master=master+"    component frame: "+specFileName+"_Master_"+(fcnt+1)+".spec";
							}
							else{
								master=master+"    component frame: "+specFileName+"_details.spec";
							}
							fwMaster.write(master);
							fwMaster.flush();
							fwMaster.close();
								}
							}
							FileWriter fwDetail=new FileWriter(specFilePath+File.separator+specFileName+"_details.spec");		
							fwDetail.write(domStructure);
							fwDetail.flush();
							fwDetail.close();
						
					}
					}
			}
			catch(IOException e){
				logger.error ("ERROR While writing to file",e);
				testCaseExecutionResult.setMessage("ERROR While writing to file"+e.getMessage());
				testCaseExecutionResult.setValid(false);
				return testCaseExecutionResult;
			}
			testCaseExecutionResult.setStatus(1);
			return testCaseExecutionResult;
			


	}
	
	
	
	private List<WebElement> getElements(String tagName){
		String sGetElements=

				"		CapturePageData(arguments[0]);																						"
						+ "		function CapturePageData(reqTopElement)																				"
						+ "		{							"
						+"			var tag = \""+ tagName+ "\";"
						+ "			var topEle=reqTopElement;"
						+ "			return topEle.getElementsByTagName(tag);"
						+ "}";
		
		

		String sgetBrowser=configurationMap.get("SAFAL_BROWSER_NAME");
		if(sgetBrowser==null){
			sgetBrowser=EMPTY_STRING;
		}
		
		
		try{
			if(sgetBrowser.toUpperCase().contains(KTTGuiConstants.INTERNET_EXPLORER_STRING)) //End of SAF-2665 changes completed  
			{
				return (List<WebElement>) ((JavascriptExecutor)webDriver).executeScript("return "+sGetElements,topPageElement);
			}
			else
			{
				sGetElements=sGetElements.replaceAll("innerText", "textContent");
				return (List<WebElement>) ((JavascriptExecutor)webDriver).executeScript("return "+sGetElements,topPageElement);
			}
		} catch (Exception e) {
			logger.error("Failed to get table data",e);
			testCaseExecutionResult.setMessage(e.getMessage());
			return null;
		}
	}
}

