package demo.Layout.GalenFrameworkTest;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class CreateSpecs {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Projects\\SAFAL21.3Latest\\SafalConfigs\\Drivers\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		//driver.get("file:///C:/Projects/Eclipse_Learning/Javascript/home.html");	
		driver.get("https://www.google.co.in/");
		String contents=null;
		contents="getAllElements();\r\n" + 
				"function getAllElements() {\r\n" + 
				"	var parentElement=\"body\";\r\n" + 
				"	var tags=['label','input','button','img'];\r\n" + 
				"	var locators=['id','name','class','src','type'];\r\n" + 
				"	var element='';\r\n" + 
				"	var ele=document.getElementsByTagName(parentElement);\r\n" + 
				"	var elementName=null;\r\n" + 
				"	var elementLocator=null;\r\n" + 
				"	var elementAttribute=null;\r\n" + 
				"	var fileContents='';\r\n" + 
				"\r\n" + 
				"	for (var i=0;i<ele[0].children.length;i++)\r\n" + 
				"	{\r\n" + 
				"		for (var k=0;k<tags.length;k++)\r\n" + 
				"		{\r\n" + 
				"			if (ele[0].children[i].localName==tags[k])\r\n" + 
				"			{\r\n" + 
				"				for (var j=0;j<locators.length;j++)\r\n" + 
				"				{\r\n" + 
				"					if(!ele[0].children[i].innerHTML) elementName=tags[k]+'_'+i+'_'+j;\r\n" + 
				"					else elementName=ele[0].children[i].innerText+'_'+i+'_'+j;\r\n" + 
				"					elementAttribute=ele[0].children[i].getAttribute(locators[j]);\r\n" + 
				"					if(elementAttribute)\r\n" + 
				"					{\r\n" + 
				"						elementLocator=\"//\"+ele[0].children[i].localName+'[@'+locators[j]+'='+\"'\"+elementAttribute+\"']\";\r\n" + 
				"						//console.log(elementName+'_'+ elementLocator);\r\n" + 
				"						fileContents=fileContents+elementName+'			'+'xpath'+'			'+elementLocator+'\\n';\r\n" + 
				"						break;\r\n" + 
				"					}\r\n" + 
				"				}\r\n" + 
				"			}\r\n" + 
				"		}\r\n" + 
				"	}\r\n" + 
				"	return '@objects'+'\\n'+fileContents;\r\n" + 
				"}";
		 
		String fileContents=((JavascriptExecutor) driver).executeScript("return "+contents).toString();
		System.out.println(fileContents);
		File file= new File("google.gspec");
		FileOutputStream fos=new FileOutputStream(file);
		fos.write(fileContents.getBytes());
		fos.close();
		
	}

}
