package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_INVALID_ROW_NUMBER_PASSED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_ROW_NUM_NOT_FOUND;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_SEARCH_VALUE_NOT_FOUND;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_TABLE_PARA_NOT_PASSED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_TABLE_ROW_VALUE_NOT_FOUND;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.EMPTY_STRING;
import static com.sungard.ktt.view.config.KTTGuiConstants.FAIL_STEP_STATUS;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS_STEP_STATUS;

import org.apache.log4j.Logger;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;
import com.sungard.ktt.view.config.KTTGuiConstants;
/**
 * @author Gyaneshwar.Nandanwar
 * This keyword verifies the cell value present in a table row of a web table.
 */
public class VerifyWebTableRowValueHTML5 extends AbstractKeyword {

	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();
	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
	/**
	 * This is web element object
	 */
	private WebElement elementTable;
	/**
	 * To find Table - refer Data grid locator
	 */
	private String sTableId=null;
	/**
	 * Row number in which the value is present 
	 */
	private String sRowNumber =null;
	/**
	 * Value which is to be verified
	 */
	private String sExpectedValue=null;		
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	private String dynamicTableTag=null;
	
	public TestcaseExecutionResultVO executeScript(String... listOfParameters) {
		int row=0;
		try 
		{
			
			if (!KeywordUtilities.isEmptyString(sRowNumber))
			{
				try {
						row = Integer.parseInt(sRowNumber);
						if(dynamicTableTag.equalsIgnoreCase("y")||dynamicTableTag.equalsIgnoreCase("yes")||dynamicTableTag.equalsIgnoreCase("True"))
						 {
							 row++;
						 }
						
					if(row<0){
						logger.error("Row number should start from 1");
						testCaseExecutionResult.setMessage("Row number should start from 1");
						return testCaseExecutionResult;
					}					
				} catch (Exception e) {
					row=0;
				}				
			}
		
			
			

			try {				
				elementTable=KeywordUtilities.getWebElement(webDriver, sTableId);
			} catch (Exception e) {
				logger.error("Unable To Find Element: "+ sTableId);
				testCaseExecutionResult.setMessage("Unable To Find Element: "+ sTableId);
			}
		} 
		catch (Exception e) 
		{
			logger.error("Exception::",e);
		}			

		String queryIE=
				"		VerifyRowData(arguments[0]);																			"+
						"		function VerifyRowData(HTML5_Table_obj)																	"+
						"		{																							            "+
						"		try {																									"+
						"		var StrtRow=\""+row+"\";																				"+
						"		var RowData = \""+ sExpectedValue+ "\";																	"+
						"		var rtbl=HTML5_Table_obj;																				"+
						"       var rwsCount=rtbl.rows.length;																			"+
						"       if(rwsCount<StrtRow)																					"+
						"		{																										"+
						"			return \""+ERROR_INVALID_ROW_NUMBER_PASSED+"\";														"+
						"		}																										"+
						"		var rs=rtbl.rows[StrtRow].cells;																		"+
						" 		for(i=0;i<rs.length;i++)																				"+
						"		{																										"+
						"			if(trim(rs[i].innerText)==trim(RowData))															"+
						"			{																									"+
						"				return \""+PASS_STEP_STATUS+"\";																"+
						"			}																									"+
						"		}																										"+
						"		return \""+FAIL_STEP_STATUS+"\";																		"+
						"		}																										"+
						"		catch(error)																							"+
						"		{																										"+
						"			return \""+FAIL_STEP_STATUS+"\";																	"+
						"		}																										"+
						"		}"+
						"function trim(s){return s.replace(/^\\s*/,\"\").replace(/\\s*$/, \"\");}";

		String sgetBrowser=EMPTY_STRING;
		//SAF-2665 Now sgetBrowser returns "INTERNET EXPLORER" instead of "MSIE".Hence adding logic to handle this.
		try
		{
			Capabilities caps = ((RemoteWebDriver) this.webDriver).getCapabilities();
			sgetBrowser = caps.getBrowserName();

		}catch(Exception e){						
			sgetBrowser=EMPTY_STRING;}

		String sfinalStatus=KTTGuiConstants.EMPTY_STRING;
		try{
			if(!sgetBrowser.toUpperCase().contains(KTTGuiConstants.INTERNET_EXPLORER_STRING)) //SAF-2665 changes completed. 
			{
				String productName = configurationMap.get("ProductName");
				
				if (productName==null || productName.isEmpty() || !productName.toLowerCase().contains("investone")) {
					queryIE=queryIE.replaceAll("innerText", "textContent");
				}
				//finalStatus = webDriver.getEval(sWebTableVerifyCellValue);
				sfinalStatus =(String)((JavascriptExecutor)webDriver).executeScript(("return "+queryIE).toString(),elementTable);
			}
			else{
			sfinalStatus =(String)((JavascriptExecutor)webDriver).executeScript(("return "+queryIE).toString(),elementTable);
			}

		} catch (Exception e) {
			testCaseExecutionResult.setMessage(e.getCause().toString());
			logger.error("Exception::"+e.getCause().toString());

			return testCaseExecutionResult;
		}
		if (sfinalStatus.equalsIgnoreCase(PASS_STEP_STATUS))
		{
			testCaseExecutionResult.setStatus(PASS);
		} 
		else
		{
			if(sfinalStatus.equalsIgnoreCase("FAIL"))
			{
				logger.error(ERROR_TABLE_ROW_VALUE_NOT_FOUND);
				testCaseExecutionResult.setMessage(ERROR_TABLE_ROW_VALUE_NOT_FOUND);
				
			}
			else
			{
				testCaseExecutionResult.setMessage(sfinalStatus);
				logger.error(sfinalStatus);
			}
		}	
		return testCaseExecutionResult;
	}

	/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters
	 *            - sTableId -sExpectedValue-sRowNumber
	 * 
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */


	public TestcaseExecutionResultVO validateKeyword( String... listOfParameters) {

		if (listOfParameters != null) {
			sTableId = listOfParameters[0];
			sExpectedValue = listOfParameters[2];
			sRowNumber = listOfParameters[1];
			dynamicTableTag=listOfParameters[3];
		} else {
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}

		testCaseExecutionResult.setTestData(sTableId +DELIMITER+sExpectedValue+DELIMITER+ sRowNumber);

		if (KeywordUtilities.isEmptyString(sTableId))
		{
			logger.error (ERROR_TABLE_PARA_NOT_PASSED);
			testCaseExecutionResult.setMessage(ERROR_TABLE_PARA_NOT_PASSED);
			return testCaseExecutionResult;
		}
		if (KeywordUtilities.isEmptyString(sRowNumber))
		{
			logger.error (ERROR_ROW_NUM_NOT_FOUND);
			testCaseExecutionResult.setMessage(ERROR_ROW_NUM_NOT_FOUND);
			return testCaseExecutionResult;
		}
		if (KeywordUtilities.isEmptyString(sExpectedValue))
		{
			logger.error (ERROR_SEARCH_VALUE_NOT_FOUND);
			testCaseExecutionResult.setMessage(ERROR_SEARCH_VALUE_NOT_FOUND);
			return testCaseExecutionResult;
		}

		// check for row number
		if (!KeywordUtilities.isValidPositiveNumbericValue(sRowNumber)) {
			logger.error (ERROR_INVALID_ROW_NUMBER_PASSED);
			testCaseExecutionResult.setMessage(ERROR_INVALID_ROW_NUMBER_PASSED);
			return testCaseExecutionResult;
		}

		testCaseExecutionResult.setValid(true);
		testCaseExecutionResult.setExpectedResultFlag(true);
		return testCaseExecutionResult;

	}

	public TestcaseExecutionResultVO validateObject(String... listOfParameters) {

		if (webDriver == null) {
			//Browser not instantiated
			logger.error(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}
		
		if (sTableId != null && sTableId.trim().startsWith(OBJECT_SPECIFIER)) {
			sTableId = sTableId.substring(OBJECT_SPECIFIER.length(), sTableId.length());
		}

		elementTable=KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap,webDriver, sTableId, "", userName);

		if (elementTable==null) {
			
			logger.error ("Table not found");
			testCaseExecutionResult.setMessage("Table not found");
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setObject(sTableId);
		testCaseExecutionResult.setValid(true);		
		return testCaseExecutionResult;
		
		
	}
}