package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.EMPTY_STRING;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;
/*This Keyword will get all values from the listbuilder box control*/
public class GetListBuilderValuesHTML5 extends AbstractKeyword{

	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();
	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());	
	/**
	 * This is web element object
	 */
	private WebElement listBuilderElement;	
	/**
	 * Enviromentvarible Name to store output value
	 */
	private String envVarName=null;
	/**
	 * Optional listbuilder locator left or right
	 */
	private String listBox=null;
	/**
	 * Optional listbuilder locator left or right
	 */
	private String ListBuilder=null;
	private String Values="";		
	@Override
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO executeScript(String... params) {

		try{							

			WebElement expectedListBox = null;				
			expectedListBox = listBuilderElement;
			List <WebElement> avilableOptions =   expectedListBox.findElements(By.tagName("li"));				
			for(WebElement opt :avilableOptions)
			{
				Values = Values+opt.getText()+","; 
			}
			if(!EMPTY_STRING.equalsIgnoreCase(Values))
			{
				if (Values.endsWith(",")) {	
					Values = Values.substring(0, Values.length()-1);}						
			}

			configurationMap.put(envVarName,Values);
			testCaseExecutionResult.setConfigUpdate(true);
			testCaseExecutionResult.setStatus(1);
			return testCaseExecutionResult;					
		}catch(Exception e){
			logger.error("Error while getting selected values from List Box");
			testCaseExecutionResult.setMessage("Error while getting selected values from List Box");
			return testCaseExecutionResult;
		}		
	}


	/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters
	 *            - envVarName - listBox  -ListBuilder-Values
	 * 
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */


	public TestcaseExecutionResultVO validateKeyword(String... params) {
		if(params!=null)
		{
			envVarName= params[0];
			listBox = params[1];
			ListBuilder =  params[2];
			Values=params[3];

		}else
		{
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setTestData(envVarName+DELIMITER +listBox+DELIMITER+ListBuilder+DELIMITER+Values);
		if (EMPTY_STRING.equalsIgnoreCase(envVarName) )
		{
			logger.error("parameters not correct : Param 1 (Env Variable Name)");
			testCaseExecutionResult.setMessage("parameters not correct : Param 1 (Env Variable Name)");
			return testCaseExecutionResult;
		}  

		if (EMPTY_STRING.equalsIgnoreCase(listBox) )
		{
			logger.error("parameters not correct : Param 2 (List Box Position)");
			testCaseExecutionResult.setMessage("parameters not correct : Param 2 (List Box Position)");
			return testCaseExecutionResult;
		}  

		if (!((listBox.equalsIgnoreCase("Right") || listBox.equalsIgnoreCase("Left"))))
		{
			logger.error("parameters not correct : Param 2 value should be 'Right' or 'Left'"); 
			testCaseExecutionResult.setMessage("parameters not correct : Param 2 value should be 'Right' or 'Left'");
			return testCaseExecutionResult;
		} 

		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;

	}

	/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... params) {		

		if (webDriver == null) {
			logger.error(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}			
		if (EMPTY_STRING.equalsIgnoreCase(ListBuilder)){
			if(listBox.equalsIgnoreCase("Left")){
				ListBuilder = "xpath=//div[@class='-list-builder-left']";//ListBuilder = "xpath=//div[@class='sg-list-builder-left']";
			}else if (listBox.equalsIgnoreCase("Right")){
				ListBuilder = "xpath=//div[@class='-list-builder-right']";
			}else{
				logger.error("correct operation not provided");
				testCaseExecutionResult.setMessage("correct operation not provided");
				return testCaseExecutionResult;
			}

		}
		else{		
			if (ListBuilder.startsWith(OBJECT_SPECIFIER)) {	
				ListBuilder = ListBuilder.substring(OBJECT_SPECIFIER.length(), ListBuilder.length());
			} }		

		listBuilderElement=KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, ListBuilder,"", userName);

		if (listBuilderElement==null){
			logger.error("List box not found");
			testCaseExecutionResult.setMessage("List box not found");
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}	
		//ask
		testCaseExecutionResult.setObject(envVarName);
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}

}
