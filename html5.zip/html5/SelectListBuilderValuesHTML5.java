package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;

public class SelectListBuilderValuesHTML5 extends AbstractKeyword{
	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();	
	/**
	 * This is webelement
	 */
	private WebElement listObjectElement;
	
	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
	
	/**
	 * Locator of the List Builder Control
	 */
	private String sList 	=null;
	/**
	 * Options need to be selected given using semicolon separated.
	 */
	private String svalueToSelect =null;
	/**
	 * Select Options using Key, Default Control
	 */
	private String selectValueUsingKey =null;
	
	
	@Override
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */

	public TestcaseExecutionResultVO executeScript(String... params) {
		try{
			String []SvalueToSelect = svalueToSelect.split(";");			
			List <WebElement> avilableOptions =   listObjectElement.findElements(By.tagName("li"));
			List <WebElement> requiredOptions = new ArrayList <WebElement>();
			
			List<Integer> requiredOptionsForShift = new ArrayList<Integer>();
			
			JavascriptExecutor js = ((JavascriptExecutor) webDriver);
			
			if("".equals(selectValueUsingKey))
			{
				selectValueUsingKey="CONTROL";
			}
			
			if(selectValueUsingKey.equalsIgnoreCase("SHIFT"))
			{
				if(SvalueToSelect.length!=2)
				{
					logger.error("Provide valid parameters to select using SHIFT key");
					testCaseExecutionResult.setMessage("Provide valid parameters to select using SHIFT key");					
					return testCaseExecutionResult;
				}
			}
			
		
			if(selectValueUsingKey.equalsIgnoreCase("SHIFT"))
			{
				
				for(String valu :SvalueToSelect)
				{
					int index=0;
					boolean found = false;
					for(WebElement opt :avilableOptions)
					{
						index=index+1;
						if (opt.getText().equalsIgnoreCase(valu))
						{
							requiredOptionsForShift.add(index);
							found = true;
							break;
						}
					}
					if (!found)
					{
						logger.error("List Option "+valu +" not found");
						testCaseExecutionResult.setMessage("List Option "+valu +" not found");					
						return testCaseExecutionResult;
					}							
				}
				Collections.sort(requiredOptionsForShift);
				int startIndex=requiredOptionsForShift.get(0);
				int stopIndex=requiredOptionsForShift.get(1);
						for(int index=startIndex;index<=stopIndex;index++)
						{
							////System.out.println(requiredOptions.size());
							requiredOptions.add(avilableOptions.get(index-1));
						}
			}
			else
			{
				for(String valu :SvalueToSelect)
				{
					boolean found = false;
					for(WebElement opt :avilableOptions)
					{
						if (opt.getText().equalsIgnoreCase(valu))
						{
							requiredOptions.add(opt);
							found = true;
							break;
						}
					}
					if (!found)
					{
						logger.error("List Option "+valu +" not found");
						testCaseExecutionResult.setMessage("List Option "+valu +" not found");					
						return testCaseExecutionResult;
					}							
				}
			}
			
			
			
			
			
			
			Thread.sleep(1000);
			String fScrollInView="" +
			"winScrollTo(arguments[0]);" +
			"function winScrollTo(ELE)" +
			"{" +
			"	var top=(getOffTop(ELE))-(window.innerHeight/2);" +
			//"	window.scrollTo(0,getOffTop(ELE));" +
			//"	alert(getOffTop(ELE));" +
			"	window.scrollTo(0,top);" +
			"}" +
			"function getOffTop(obj)" +
			"{" +
			"	var curtop = 0;" +
			"	if (obj.offsetParent) " +
			"	{" +
			"		do " +
			"		{" +
			"			curtop += obj.offsetTop;" +
			"		}" +
			"		while (obj = obj.offsetParent);" +
			"	" +
			//"" +
			"	}" +
			"	return curtop;" +
			//"	var offtop=0;" +
			//"	try {offtop=obj.offsetTop+(obj.offsetParent?obj.offsetParent.documentOffsetTop():0);}catch(e){}" +
			//"	return offtop;" +
			"}";
			
			
			try {
				js.executeScript("window.focus();", listObjectElement);
			} catch (Exception e1){logger.error("Exception::",e1);}
			
			try {
				js.executeScript("return "+fScrollInView, listObjectElement);
			} catch (Exception e1)
			{
				logger.error("Exception1::",e1);
			}
			Thread.sleep(500);
			//Mouse mouse = ((HasInputDevices) webDriver).getMouse();
			//Keyboard keyboard = ((HasInputDevices) webDriver).getKeyboard();
			//Actions a = new Actions(webDriver);
			Robot robot = new Robot();
			
			//SAF-2387 using element object to click instead of its coordinates 
			//mouse.click(((Locatable) requiredOptions.get(0)).getCoordinates());
			try {
				js.executeScript("arguments[0].click()", requiredOptions.get(0));
			} catch (Exception e1)
			{	
				logger.error("Failed click first select option",e1);
			}
			
			if(selectValueUsingKey.equalsIgnoreCase("SHIFT"))
			{
				if (SvalueToSelect.length > 1){
				//keyboard.pressKey(Keys.SHIFT);
				//a.keyDown(Keys.SHIFT).build().perform();
				robot.keyPress(KeyEvent.VK_SHIFT);

				}
			}
			else if (selectValueUsingKey.equalsIgnoreCase("CONTROL"))
			{
				if (SvalueToSelect.length > 1){
				//	keyboard.pressKey(Keys.CONTROL);
					//a.keyDown(Keys.CONTROL).build().perform();
					robot.keyPress(KeyEvent.VK_CONTROL);
				}
			}

			for(WebElement reqOpt:requiredOptions)
			{
				try {
					js.executeScript("return arguements[0].scrollIntoView();", reqOpt);
				} catch (Exception e1)
				{	
					logger.error("Exception::",e1);
				}
				if(reqOpt!=requiredOptions.get(0))
				{
					//SAF-2387 using element object to click instead of its coordinates 
					//mouse.click(((Locatable) reqOpt).getCoordinates());
					try {
						
						js.executeScript("arguments[0].click()", reqOpt);
					} catch (Exception e1)
					{	
						logger.error("Failed click select option",e1);
					}
				}
			}
				
			if(selectValueUsingKey.equalsIgnoreCase("SHIFT"))
			{
				if (SvalueToSelect.length > 1){
					//keyboard.releaseKey(Keys.SHIFT);
					//a.keyUp(Keys.SHIFT).build().perform();
					robot.keyRelease(KeyEvent.VK_SHIFT);
				}
			}
			else if (selectValueUsingKey.equalsIgnoreCase("CONTROL"))
			{
				if (SvalueToSelect.length > 1){
					//keyboard.releaseKey(Keys.CONTROL);	
					//a.keyUp(Keys.CONTROL).build().perform();
					robot.keyRelease(KeyEvent.VK_CONTROL);
				}
			}
			
			}catch(Exception e)
			{
				logger.error("Error while selection option value",e);
				testCaseExecutionResult.setMessage("Error while selection option value");
				return testCaseExecutionResult;
			}		
			testCaseExecutionResult.setStatus(1);
			return testCaseExecutionResult;	
	}
	/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters 
	 *              - sList -svalueToSelect-selectValueUsingKey
	 * 
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */


	public TestcaseExecutionResultVO validateKeyword(String... params) {

		if(params!=null)
		{
			sList=  params[0];
			svalueToSelect=  params[1];
			selectValueUsingKey =  params[2];
		}
		else{
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setTestData(sList +DELIMITER+svalueToSelect+DELIMITER+ svalueToSelect);
		if("".equals(params[0]))
		{
			logger.error("list box locator not given");
			testCaseExecutionResult.setMessage("list box locator not given");
			return testCaseExecutionResult;
		}
		
		if("".equals(params[1]))
		{
			logger.error("options not given");
			testCaseExecutionResult.setMessage("options not given");
			return testCaseExecutionResult;
		}

		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}
	/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... params) {

		if (webDriver == null) {
				logger.error(ERROR_BROWSER_NOT_INSTANTIATED);
				testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
				testCaseExecutionResult.setValid(false);
				return testCaseExecutionResult;
			}
			if (sList.startsWith(OBJECT_SPECIFIER)) {	
				sList = sList.substring(OBJECT_SPECIFIER.length(), sList.length());
			} 
			listObjectElement=KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, sList,"", userName);
			if (listObjectElement==null){
				logger.error("List box not found");
				testCaseExecutionResult.setMessage("List box not found");
				testCaseExecutionResult.setValid(false);
				return testCaseExecutionResult;
			}
			testCaseExecutionResult.setObject(sList);
			testCaseExecutionResult.setValid(true);
			return testCaseExecutionResult;
	}

}