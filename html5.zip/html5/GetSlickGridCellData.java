package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_ROW_NUM_NOT_FOUND;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_WAIT_VARIABLE;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;
import com.sungard.ktt.view.config.KTTGuiConstants;


public class GetSlickGridCellData extends AbstractKeyword { 
	private String isLast = "False";
	private String gridIdentifier="";
	private String rowNo = "";
	private String ColNo = "";
	private String Env = "";
	private String loadingIconXpath="";
	private WebElement girdObject = null;
	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();
	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());

	@Override
	public TestcaseExecutionResultVO validateKeyword(String... listOfParameters) {
		if(listOfParameters!=null)
		{
			gridIdentifier=listOfParameters[0];
			rowNo =listOfParameters[1];
			ColNo =listOfParameters[2];
			Env=listOfParameters[3];
			isLast=listOfParameters[4];
			loadingIconXpath=listOfParameters[5];
			
		}else{
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setTestData(gridIdentifier+DELIMITER+ rowNo +DELIMITER+sRowNumber +DELIMITER+isLast);
		// check for row number
		if (KeywordUtilities.isEmptyString(loadingIconXpath)) {
			loadingIconXpath= "//div[@class='slick-loader-parent']";
		}

				if (KeywordUtilities.isEmptyString(gridIdentifier)) {
					logger.error("Grid identifier not given");
					testCaseExecutionResult.setMessage(ERROR_ROW_NUM_NOT_FOUND);
					return testCaseExecutionResult;
				}
				
				if (KeywordUtilities.isEmptyString(Env)) {
					logger.error("Environment variable name not given");
					testCaseExecutionResult.setMessage("Environment variable name not given");
					return testCaseExecutionResult;
				}
				

				// check for environment variable
				if (KeywordUtilities.isEmptyString(isLast)) {
					isLast = "false";
					if (!KeywordUtilities.isValidPositiveNumbericValue(rowNo)) {
						logger.error("Row no is  not correct");
						testCaseExecutionResult.setMessage("Row no is not correct");
						return testCaseExecutionResult;
					}
					if (!KeywordUtilities.isValidPositiveNumbericValue(ColNo)) {
						logger.error("Col no not given");
						testCaseExecutionResult.setMessage("Col no is not correct");
						return testCaseExecutionResult;
					}
				}

				testCaseExecutionResult.setValid(true);
				return testCaseExecutionResult;

	}

	@Override
	public TestcaseExecutionResultVO validateObject(String... params) {
		if (webDriver == null) {
			logger.error ("ERROR_BROWSER_NOT_INSTANTIATED");
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}
	
		if (gridIdentifier != null && gridIdentifier.trim().startsWith(OBJECT_SPECIFIER)) {
			gridIdentifier = gridIdentifier.substring(OBJECT_SPECIFIER.length(), gridIdentifier.length());
		}

		girdObject=KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap,webDriver, gridIdentifier, "", userName);

		if (girdObject==null) {
			
			logger.error ("Grid not found");
			testCaseExecutionResult.setMessage("Table not found");
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setObject(gridIdentifier);
		testCaseExecutionResult.setValid(true);		
		return testCaseExecutionResult;
		
		
	}

	@Override
	public TestcaseExecutionResultVO executeScript(String... params) {
		try{
		WebElement gridViewPort=null;
		WebElement gridcanvas=null;
		// TODO Auto-generated method stub
		try{
			gridViewPort = girdObject.findElement(By.className("slick-viewport"));
		}catch(Exception e){
			testCaseExecutionResult.setMessage("grid view port not found");
			return testCaseExecutionResult;
		}
		
		try{
			gridcanvas = girdObject.findElement(By.className("grid-canvas"));
		}catch(Exception e){
			testCaseExecutionResult.setMessage("grid canvas not found");
			return testCaseExecutionResult;
		}
		if(isLast.equalsIgnoreCase("true")||isLast.equalsIgnoreCase("Yes")||isLast.equalsIgnoreCase("Y")){
		
			String res = ((JavascriptExecutor)webDriver).executeScript("try{var a = arguments[0];var b = arguments[1];  $(a).scrollLeft($(a).prop(\"scrollWidth\")); $(a).scrollTop($(a).prop(\"scrollHeight\"));return 'true';}catch(e){return 'false';}", gridViewPort,gridcanvas).toString();
			if (res==null ||res.equalsIgnoreCase("false")){
				testCaseExecutionResult.setMessage("not able to scroll to last element");
				return testCaseExecutionResult;				
			}
			
			
				int toWait_ObjWait=KTTGuiConstants.DEFAULT_OBJECT_WAIT_TIME;
				try{
					String val = configurationMap.get(OBJECT_WAIT_VARIABLE);
					if(val!=null){
						toWait_ObjWait =Integer.parseInt(val); 
					}					
					try	{
						Thread.sleep(500);
						Wait wt = new WebDriverWait(webDriver,toWait_ObjWait);
						wt.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(loadingIconXpath)));
					} catch (Exception e)
					{logger.debug("Exception occured",e);}
					
					
				}catch(Exception e){logger.debug("Failed to get 1OBJECT_WAIT_VARIABLE",e);}
			
		}
		
		
		int colNo = 0;
		int cnt = 0;
		String count ="";
		String colCount ="";
		
		if(isLast.equalsIgnoreCase("true")||isLast.equalsIgnoreCase("Yes")||isLast.equalsIgnoreCase("Y")){
			
			count =((JavascriptExecutor)webDriver).executeScript("try{var a = arguments[0];var b = $(a).prop('children').length; return b;}catch(e){return '-1';}", gridcanvas).toString();
			if (count==null ||count.equalsIgnoreCase("-1")){
				testCaseExecutionResult.setMessage("not able to get last element");
				return testCaseExecutionResult;				
			}	
			colCount =((JavascriptExecutor)webDriver).executeScript("try{var a = arguments[0];var b = $(a).prop('children')[ $(a).prop('children').length-1]; var c =$(b).prop('children').length; return c;}catch(e){return '-1';}", gridcanvas).toString();
			if (colCount==null ||colCount.equalsIgnoreCase("-1")){
				testCaseExecutionResult.setMessage("not able to get last col element");
				return testCaseExecutionResult;				
			}
			ColNo = colCount;
		}else{
			count =rowNo;
			
		}
		
		try{
			colNo = Integer.parseInt(ColNo);			
		}catch(Exception e){
			testCaseExecutionResult.setMessage("given col no is not correct");
			return testCaseExecutionResult;	
		}
		
		try{
			cnt = Integer.parseInt(count);
			cnt= cnt-1;
		}catch(Exception e){
			cnt = 0;
		}			
			String getCellValue=
					"var val = f(arguments[0]); return val;"+
					"function f(x){"+
					"var rowNo="+cnt+";"+
					"var colno="+colNo+";"+
					"try{"+
					"var a =x ;"+
					//"alert(a);"+
					"var b = $(a).prop('children');"+
					//"alert(b);"+
					"var expectedRow=b[rowNo];"+
					//"alert(expectedRow);"+
					"var expectedcells=$(expectedRow).prop('children');"+
					"var expectedcell=expectedcells[colno-1];"+
					//"alert(expectedcells.length);"+
					//"alert('got object');"+
					"var expetedValue =expectedcell.innerText; "+
					//"alert(expetedValue);"+
					//"alert(expectedcell.className);"+
					" return expetedValue;"+
					"}catch(e){return 'Error';}"+
					 "}"+
					"function trim(s)																						"+
					"{																										"+
					"	return s.replace(/^\\s*/,\"\").replace(/\\s*$/, \"\");												"+
					"}";
			
			String finalValue = ((JavascriptExecutor)webDriver).executeScript(getCellValue, gridcanvas).toString();
			if (finalValue==null ||finalValue.equalsIgnoreCase("Error")){
				testCaseExecutionResult.setMessage("Error while getting value from slickGrid");
				return testCaseExecutionResult;				
			}else{
				configurationMap.put(Env, finalValue);
				testCaseExecutionResult.setStatus(1);
			}
		}catch(Exception e){
			testCaseExecutionResult.setMessage("Error whie getting value from slickGrid");
		}
			return testCaseExecutionResult;			
		
	}
	
	

	
}
