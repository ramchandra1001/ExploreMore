package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_INVALID_ROW_NUMBER_PASSED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_SEARCH_VALUE_NOT_FOUND;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_TABLE_COLS_NOT_PASSED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_TABLE_COLUMNS_NOT_FOUND;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_TABLE_LOCATOR_NOT_PASSED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_TABLE_NOT_FOUND;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_TABLE_ROW_VALUE_NOT_FOUND;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS_STEP_STATUS;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;
/**
 * @ Created by Gyaneshwar.Nandanwar on 11-Nov-2013
 * This keyword verifies the values which are present in a row by providing multiple/Single column names
 */
public class VerifyWebTableColumnValueHTML5 extends AbstractKeyword 
{
	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();
	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
	public static final String KENDO_GRID_NAME="KendoGridName";
	public static final String DEFAULT_KENDO_GRID_NAME="kendoGrid";
	/**
	 * This is webelement
	 */
	private WebElement elementTable, elementTableHeader;
	/**
	 * To find Table - refer Data grid locator
	 */
	private String sTableHeader = null;
	/**
	 * column name or column number, multiple values separated by pipe (|)
	 */
	private String sColumnName = null;	
	/**
	 * Column value, multiple values separated by pipe (|)
	 */
	private String colValues = null;
	/**
	 * Start row number to start the search from specified row. 
	 * By default it will start from first row
	 */
	private String sStartRow = null;
	/**
	 * Header row number if header has multiple rows, by default it will take first row 
	 */
	private String sColHeaderStrtRowNum=null;

	@Override
	/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO executeScript(String... listOfParameters)
	{
		String sGridName=DEFAULT_KENDO_GRID_NAME;
		try {
			sGridName =configurationMap.get(KENDO_GRID_NAME);
		} catch (Exception e3) {
			sGridName=DEFAULT_KENDO_GRID_NAME;
		}

		if(sGridName==null)
		{
			sGridName=DEFAULT_KENDO_GRID_NAME;
		}
		if (KeywordUtilities.isEmptyString(sStartRow))
		{
			sStartRow="0";
		}
		if (KeywordUtilities.isEmptyString(sColHeaderStrtRowNum))
		{
			sColHeaderStrtRowNum="0";
		}
		try {
			elementTable=KeywordUtilities.getWebElement(webDriver, sTableHeader);
		} catch (Exception e) {
			logger.error("Unable TO Find Element: "+ sTableHeader);
			testCaseExecutionResult.setMessage("Unable TO Find Element: "+ sTableHeader);
		}		
		String numCols[] = sColumnName.trim().split("\\|");

		int iColFlag=1;
		try {
			Integer.parseInt(numCols[0]);
		} catch (NumberFormatException e3) {
			iColFlag=0;
		}
		
		try {
			elementTableHeader=KeywordUtilitiesHTML5.kendoDataControl(webDriver, elementTable,"grid");
		} catch (Exception e) {
			testCaseExecutionResult.setMessage("Unable TO Find Column Header Element");
			logger.error("Unable TO Find Column Header Element");
			return testCaseExecutionResult;
		}	
		
		if (iColFlag==0) {	
			sColumnName= KeywordUtilitiesHTML5.returnColumnNumber(webDriver,elementTableHeader, sColumnName,sColHeaderStrtRowNum,sGridName );
			if (sColumnName.contains("COL_ERR")) {
				logger.error(ERROR_TABLE_COLUMNS_NOT_FOUND);
				testCaseExecutionResult.setMessage(ERROR_TABLE_COLUMNS_NOT_FOUND);
				return testCaseExecutionResult;
			}
			iColFlag=1;
		}		
		String[] splitColumnNumbers = sColumnName.split("\\|");
		String colNumbers="";
		for (int i=0;i<splitColumnNumbers.length;i++){
			int colNum = Integer.parseInt(splitColumnNumbers[i]);
			colNum--;
			sColumnName=Integer.toString(colNum);
			if (i==0)
				colNumbers=sColumnName;
			else
				colNumbers=colNumbers+"|"+sColumnName;
		}
		String sFinalStatus = KeywordUtilitiesHTML5.verifyColumnValues(webDriver, elementTableHeader, colNumbers, colValues, sStartRow,sGridName);
				
		if (sFinalStatus.trim().equalsIgnoreCase(PASS_STEP_STATUS))
		{
			testCaseExecutionResult.setStatus(PASS);
			return testCaseExecutionResult;
		} 
		else
		{
			if(sFinalStatus.contains("ROW_ERR")){
				sFinalStatus=ERROR_TABLE_ROW_VALUE_NOT_FOUND;
			}
			else
				if(sFinalStatus.contains("INVALID_STRT_ROW")){
					sFinalStatus=ERROR_INVALID_ROW_NUMBER_PASSED;
				}
			logger.error(sFinalStatus);
			testCaseExecutionResult.setMessage(sFinalStatus);
			return testCaseExecutionResult;
		}
	}

	@Override

/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters
	 *            - sTableHeader -sColumnName-sStartRow-colValues-sColHeaderStrtRowNum
	 * 
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateKeyword(String... listOfParameters)
	{
		// check for required parameter count
		if (listOfParameters != null)
		{
			sTableHeader = listOfParameters[0];
			sColumnName = listOfParameters[1];
			sStartRow = listOfParameters[2];
			colValues = listOfParameters[3];
			sColHeaderStrtRowNum=listOfParameters[4];

		} else
		{
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setTestData ( sTableHeader+DELIMITER+sColumnName+DELIMITER+ sStartRow+DELIMITER+ colValues +DELIMITER+sColHeaderStrtRowNum);

		if (KeywordUtilities.isEmptyString(sTableHeader))
		{
			logger.error(ERROR_TABLE_LOCATOR_NOT_PASSED);
			testCaseExecutionResult.setMessage(ERROR_TABLE_LOCATOR_NOT_PASSED);
			return testCaseExecutionResult;
		}
		if (KeywordUtilities.isEmptyString(sColumnName))
		{
			logger.error(ERROR_TABLE_COLS_NOT_PASSED);
			testCaseExecutionResult.setMessage(ERROR_TABLE_COLS_NOT_PASSED);
			return testCaseExecutionResult;
		}
		if (KeywordUtilities.isEmptyString(colValues))
		{
			logger.error(ERROR_SEARCH_VALUE_NOT_FOUND);
			testCaseExecutionResult.setMessage(ERROR_SEARCH_VALUE_NOT_FOUND);
			return testCaseExecutionResult;
		}
		
		if (!KeywordUtilities.isEmptyString(sStartRow) && !KeywordUtilities.isValidPositiveNumbericValue(sStartRow))
		{
			logger.error("Start Row number must be numeric value");
			testCaseExecutionResult.setMessage("Start Row number must be numeric value");
			return testCaseExecutionResult;
		}
		// check for numeric instance value
		//testCaseExecutionResult.setExpectedResultFlag(true);
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}

	@Override

/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... listOfParameters)
	{
		
		if (webDriver == null)
		{
			// Browser not instantiated
			logger.error(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}

		testCaseExecutionResult.setObject(sTableHeader);

		if (sTableHeader.startsWith(OBJECT_SPECIFIER))
		{
			sTableHeader = sTableHeader.substring(OBJECT_SPECIFIER.length(),sTableHeader.length());

			//sgid is there but xpath is not there so let prepare it
			
			if (!KeywordUtilities.waitForElementPresent(configurationMap,webDriver,sTableHeader, userName))
			{
				logger.error(ERROR_TABLE_NOT_FOUND);
				testCaseExecutionResult.setMessage(ERROR_TABLE_NOT_FOUND);
				testCaseExecutionResult.setObjectError(true);
				testCaseExecutionResult.setValid(false);
				return testCaseExecutionResult;
			}
			/*if(sTableHeader.toLowerCase().contains("sgid=") && !sTableHeader.toUpperCase().contains("XPATH="))
			{
				sTableHeader="xpath=//table[@'"+sTableHeader+"']";
			}

			if (sTableHeader.toUpperCase().contains("XPATH="))
			{
				sTableHeader = KeywordUtilities.formXpath(sTableHeader);
				if (isValidationRequired() && !KeywordUtilities.waitForElementPresent(configurationMap,webDriver,sTableHeader))
				{
					testcaseExecutionRes.setMessage(ERROR_TABLE_NOT_FOUND_XPATH);
					return testcaseExecutionRes;
				}			
			}	*/		
		}
		testCaseExecutionResult.setObject(sTableHeader);
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}
}
