package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_INVALID_ROW_NUMBER_PASSED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_SEARCH_VALUE_NOT_FOUND;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_TABLE_COLS_NOT_PASSED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_TABLE_COLUMNS_NOT_FOUND;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_TABLE_LOCATOR_NOT_PASSED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_TABLE_NOT_FOUND_XPATH;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS_STEP_STATUS;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.util.TimeWatcher;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;
/**
 * @ Created by Gyaneshwar.Nandanwar on 11-Nov-2013
 */
public class WaitForWebTableValueToDisappearHTML5 extends AbstractKeyword 
{
	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();

	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
	public static final String KENDO_GRID_NAME="KendoGridName";
	public static final String DEFAULT_KENDO_GRID_NAME="kendoGrid";
	/**
	 * This is web element
	 */
	private WebElement elementTable, elementTableHeader;
	private String sTableHeader = null;
	private String sColumnName = null;		
	private String colValues = null;
	private String sStartRow = null;
	private String sColHeaderStrtRowNum=null;
	private String sWaitTimeInSeconds=null;
	private String sRefreshButton = null;

	@Override
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */

	public TestcaseExecutionResultVO executeScript(String... listOfParameters)
	{

		String sGridName=DEFAULT_KENDO_GRID_NAME;
		try {
			sGridName =configurationMap.get(KENDO_GRID_NAME);
		} catch (Exception e3) {
			sGridName=DEFAULT_KENDO_GRID_NAME;
		}

		if(sGridName==null)
		{
			sGridName=DEFAULT_KENDO_GRID_NAME;
		}
		if (KeywordUtilities.isEmptyString(sStartRow))
		{
			sStartRow="0";
		}
		if (KeywordUtilities.isEmptyString(sColHeaderStrtRowNum))
		{
			sColHeaderStrtRowNum="0";
		}
		try {
			elementTable=KeywordUtilities.getWebElement(webDriver, sTableHeader);
		} catch (Exception e) {
			logger.error("Unable TO Find Element: "+ sTableHeader);
			testCaseExecutionResult.setMessage("Unable TO Find Element: "+ sTableHeader);
		}		
		String numCols[] = sColumnName.trim().split("\\|");

		int iColFlag=1;
		try {
			Integer.parseInt(numCols[0]);
		} catch (NumberFormatException e3) {
			iColFlag=0;
		}

		try {
			elementTableHeader=KeywordUtilitiesHTML5.kendoDataControl(webDriver, elementTable,"grid");
		} catch (Exception e) {
			logger.error("Unable TO Find Column Header Element");
			testCaseExecutionResult.setMessage("Unable TO Find Column Header Element");
			
			return testCaseExecutionResult;
		}	

		if (iColFlag==0) {	
			sColumnName= KeywordUtilitiesHTML5.returnColumnNumber(webDriver,elementTableHeader, sColumnName,sColHeaderStrtRowNum,sGridName );
			if (sColumnName.contains("COL_ERR")) {
				logger.error(ERROR_TABLE_COLUMNS_NOT_FOUND);
				testCaseExecutionResult.setMessage(ERROR_TABLE_COLUMNS_NOT_FOUND);
				return testCaseExecutionResult;
			}
			iColFlag=1;
		}		
		String[] splitColumnNumbers = sColumnName.split("\\|");
		String colNumbers="";
		for (int i=0;i<splitColumnNumbers.length;i++){
			int colNum = Integer.parseInt(splitColumnNumbers[i]);
			colNum--;
			sColumnName=Integer.toString(colNum);
			if (i==0)
				colNumbers=sColumnName;
			else
				colNumbers=colNumbers+"|"+sColumnName;
		}
		int iWaitTimeInSeconds = Integer.parseInt(sWaitTimeInSeconds);
		if (iWaitTimeInSeconds>900) {
			logger.error("Please provide the Wait Time less than 900");
			testCaseExecutionResult.setMessage("Please provide the Wait Time less than 900");
			return testCaseExecutionResult;
		}
		TimeWatcher timeWatcher = new TimeWatcher(iWaitTimeInSeconds);
		timeWatcher.startTimeWatcher();
		String sFinalStatus=null;
		try
		{
			while(!timeWatcher.isTimeUp(userName))	
			{
				try {
					sFinalStatus = KeywordUtilitiesHTML5.verifyColumnValues(webDriver, elementTableHeader, colNumbers, colValues, sStartRow,sGridName);
					if (!sFinalStatus.equals(PASS_STEP_STATUS))
						break;
					else{
						if (sRefreshButton.startsWith(OBJECT_SPECIFIER)) {
							sRefreshButton = sRefreshButton.substring(OBJECT_SPECIFIER.length(), sRefreshButton.length());
						}
						WebElement elementButton=KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, sRefreshButton,"1", userName);

						if (elementButton==null) {
							logger.error("Refresh Button not found");
							testCaseExecutionResult.setMessage("Refresh Button not found");
							return testCaseExecutionResult;
						}
						else {
							WebDriverWait wait = new WebDriverWait(webDriver, 10);
							wait.until(ExpectedConditions.visibilityOf(elementButton));
							elementButton.click();
							Thread.sleep(4000);
						}
					}
				}catch(Exception e){logger.error("Exception::",e);}
			}
		}
		catch(Exception e){logger.error("Exception::",e);}
		finally
		{
			timeWatcher.cancel();
		}
		if (sFinalStatus.trim().equalsIgnoreCase(PASS_STEP_STATUS))
		{
			logger.error("The column value did not disappear within specifid time");
			testCaseExecutionResult.setMessage("The column value did not disappear within specifid time");
			return testCaseExecutionResult;
		} 
		else
		{
			if(sFinalStatus.contains("ROW_ERR")){
				testCaseExecutionResult.setStatus(PASS);
				return testCaseExecutionResult;
			}
			else
				if(sFinalStatus.contains("INVALID_STRT_ROW")){
					sFinalStatus=ERROR_INVALID_ROW_NUMBER_PASSED;
				}
			logger.error(sFinalStatus);
			testCaseExecutionResult.setMessage(sFinalStatus);
			return testCaseExecutionResult;
		}
	}

	@Override

	/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters
	 *            - sTableHeader -sColumnName-sStartRow-colValues-sColHeaderStrtRowNum
	 *              sWaitTimeInSeconds-0sRefreshButton
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */

	public TestcaseExecutionResultVO validateKeyword(String... listOfParameters)
	{
		if (listOfParameters != null)
		{
			sTableHeader = listOfParameters[0];
			sColumnName = listOfParameters[1];
			sStartRow = listOfParameters[2];
			colValues = listOfParameters[3];
			sColHeaderStrtRowNum=listOfParameters[4];
			sWaitTimeInSeconds = listOfParameters[5];
			sRefreshButton=listOfParameters[6];

		} else
		{
			// Insufficient Parameters
			logger.error(ERROR_PARAMETERS_LIST);
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setTestData(sTableHeader +DELIMITER+sColumnName+DELIMITER+ sStartRow +DELIMITER+colValues +DELIMITER+sColHeaderStrtRowNum +DELIMITER+sWaitTimeInSeconds +DELIMITER+sRefreshButton);

		if (KeywordUtilities.isEmptyString(sTableHeader))
		{
			logger.error(ERROR_TABLE_LOCATOR_NOT_PASSED);
			testCaseExecutionResult.setMessage(ERROR_TABLE_LOCATOR_NOT_PASSED);
			return testCaseExecutionResult;
		}
		if (KeywordUtilities.isEmptyString(sColumnName))
		{
			logger.error(ERROR_TABLE_COLS_NOT_PASSED);
			testCaseExecutionResult.setMessage(ERROR_TABLE_COLS_NOT_PASSED);
			return testCaseExecutionResult;
		}
		if (KeywordUtilities.isEmptyString(colValues))
		{
			logger.error(ERROR_SEARCH_VALUE_NOT_FOUND);
			testCaseExecutionResult.setMessage(ERROR_SEARCH_VALUE_NOT_FOUND);
			return testCaseExecutionResult;
		}
		if (KeywordUtilities.isEmptyString(sWaitTimeInSeconds))
		{
			logger.error("Wait Time not passed");
			testCaseExecutionResult.setMessage("Wait Time not passed");
			return testCaseExecutionResult;
		}
		if (KeywordUtilities.isEmptyString(sRefreshButton))
		{
			logger.error("Locator for Refresh button not passed");
			testCaseExecutionResult.setMessage("Locator for Refresh button not passed");
			return testCaseExecutionResult;
		}
		if (!KeywordUtilities.isValidPositiveNumbericValue(sWaitTimeInSeconds))
		{
			logger.error("Invalid value for Wait Time");
			testCaseExecutionResult.setMessage("Invalid value for Wait Time");
			return testCaseExecutionResult;
		}
		if (!KeywordUtilities.isEmptyString(sStartRow) && !KeywordUtilities.isValidPositiveNumbericValue(sStartRow))
		{
			logger.error("Start Row number must be numeric value");
			testCaseExecutionResult.setMessage("Start Row number must be numeric value");
			return testCaseExecutionResult;
		}
		// check for numeric instance value
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}

	@Override

	/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... listOfParameters)
	{
		if (webDriver == null)
		{
			// Browser not instantiated
			logger.error(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}

		testCaseExecutionResult.setObject(sTableHeader);

		if (sTableHeader.startsWith(OBJECT_SPECIFIER))
		{
			sTableHeader = sTableHeader.substring(OBJECT_SPECIFIER.length(),sTableHeader.length());

			//sgid is there but xpath is not there so let prepare it
			if(sTableHeader.toLowerCase().contains("sgid=") && !sTableHeader.toUpperCase().contains("XPATH="))
			{
				sTableHeader="xpath=//table[@'"+sTableHeader+"']";
			}

			if (sTableHeader.toUpperCase().contains("XPATH="))
			{
				sTableHeader = KeywordUtilities.formXpath(sTableHeader);
				if (!KeywordUtilities.waitForElementPresent(configurationMap,webDriver,sTableHeader, userName))
				{
					logger.error(ERROR_TABLE_NOT_FOUND_XPATH);
					testCaseExecutionResult.setMessage(ERROR_TABLE_NOT_FOUND_XPATH);
					testCaseExecutionResult.setValid(false);
					return testCaseExecutionResult;
				}			
			}			
		}
		testCaseExecutionResult.setObject(sTableHeader);
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}
}
