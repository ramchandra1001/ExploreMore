package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.EMPTY_STRING;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;

/**
 * @author Ashish Joshi
 * Created for Script_1499 Under SAFAL 8.0.0, patch release 1
 * @creation date 30 Oct 2012
 *This Keyword will verify Dialog Text/Message and Title from the Alert/Confirmation Dialog
 */
public class VerifyDialogTextHTML5 extends AbstractKeyword{
	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();

	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
	/**
	 * Text/Message of the Dialog, Mandatory Parameter
	 */	
	private String sExpectedDialogText = null;
	/**
	 * Dialog Box Locator (Optional Parameter)
	 */
	private String sDialogLocator=null;
	/**
	 * Title of the Dialog (Optional Parameter), if not given, This keyword will not Verify it. 
	 * It will only verify the Dialog  Text 
	 */
	private String sExpectedTitleText =null;
	private String sActualDialogText = null;
	private String sActualTitleText=null;
	/**
	 *This is web element
	 */
	private WebElement dialogBox = null;  
	private WebElement titleWindow=null;
	private WebElement modalContent=null;



	@Override
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO executeScript(String... listOfParameters) throws UnhandledAlertException {

		sActualTitleText=EMPTY_STRING;
		try {
			try {
				titleWindow = dialogBox.findElement(By.xpath("(//span[contains(@ng-bind,'Title')])[position()=last()]"));
			} catch (Exception e) {
				titleWindow=null;
			}
			if(titleWindow==null)
			{
				logger.error("Unable to get the Title Element");
				testCaseExecutionResult.setMessage("Unable to get the Title Element");
				testCaseExecutionResult.setObjectError(true); 
				return testCaseExecutionResult;
			}

			sActualTitleText=titleWindow.getText();
			if(!EMPTY_STRING.equals(sExpectedTitleText))
			{
				if(!sExpectedTitleText.equals(sActualTitleText))
				{
					logger.error("Dialog Title Not Matched, Expected: "+sExpectedTitleText +", Actual: "+ sActualTitleText);
					testCaseExecutionResult.setMessage("Dialog Title Not Matched, Expected: "+sExpectedTitleText +", Actual: "+ sActualTitleText);
					return testCaseExecutionResult;
				}
			}
		} catch (Exception e) {
			logger.error("Unable to get Dialog Box Title");
			testCaseExecutionResult.setMessage("Unable to get Dialog Box Title");
		}


		sActualDialogText=EMPTY_STRING;

		try {


			sActualDialogText=modalContent.getText();

			if(sExpectedDialogText.equals(sActualDialogText))
			{
				testCaseExecutionResult.setStatus(PASS);
			}
			else
			{
				logger.error("Dialog Text Not Matched, Expected: "+sExpectedDialogText +", Actual: "+ sActualDialogText);
				testCaseExecutionResult.setMessage("Dialog Text Not Matched, Expected: "+sExpectedDialogText +", Actual: "+ sActualDialogText);
				return testCaseExecutionResult;
			}

		} catch (Exception e) {
			logger.error("Unable to get Dialog Box Text");
			testCaseExecutionResult.setMessage("Unable to get Dialog Box Text");
		}
		return testCaseExecutionResult;
	}


	@Override

	/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters 
	 *              - sExpectedDialogText -sExpectedTitleText-sDialogLocator
	 * 
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateKeyword(String... listOfParameters) {
		if (listOfParameters != null) 
		{
			sExpectedDialogText = listOfParameters[0];
			sExpectedTitleText=listOfParameters[1];
			sDialogLocator=listOfParameters[2];

		} else {
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}	
		testCaseExecutionResult.setTestData(sExpectedDialogText+DELIMITER+ sExpectedTitleText+DELIMITER+ sDialogLocator);
		if(EMPTY_STRING.equals(sExpectedDialogText))
		{
			logger.error ("Expected Dialog Text Not Passed.");
			testCaseExecutionResult.setMessage("Expected Dialog Text Not Passed.");
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setValid(true);
		//SAF-2663 should check expected result value
		testCaseExecutionResult.setExpectedResultFlag(true);
		return testCaseExecutionResult;				
	}

	@Override

	/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... listOfParameters) {
		if (webDriver == null) {
			logger.error(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}

		testCaseExecutionResult.setExpectedResultFlag(true);

		if(EMPTY_STRING.equals(sDialogLocator))
		{
			sDialogLocator="xpath=(//*[@data-role='window'])[position()=last()]";
		}
		else
		{
			if (sDialogLocator.startsWith(OBJECT_SPECIFIER)) {

				sDialogLocator = sDialogLocator.substring(OBJECT_SPECIFIER.length(), sDialogLocator.length());
			} 
		}


		dialogBox = KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, sDialogLocator,"", userName);


		if(dialogBox==null)
		{
			logger.error("Dialog Box not Found");
			testCaseExecutionResult.setMessage("Dialog Box not Found");
			testCaseExecutionResult.setObjectError(true);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}
		else
		{
			testCaseExecutionResult.setValid(true);
			testCaseExecutionResult.setObject(sDialogLocator);

			try {
				modalContent = dialogBox.findElement(By.xpath("(//*[contains(@class,'confirm-dialog')])[position()=last()]"));
			} catch (Exception e) {
				modalContent=null;
			}

			if(modalContent==null)
			{
				logger.error("Unable to get the Dialog Message Element");
				testCaseExecutionResult.setMessage("Unable to get the Dialog Message Element");
				testCaseExecutionResult.setObjectError(true);
				testCaseExecutionResult.setValid(false);
				return testCaseExecutionResult;
			}
		}
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}

}
