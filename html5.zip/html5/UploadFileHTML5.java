package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.EMPTY_STRING;
import static com.sungard.ktt.view.config.KTTGuiConstants.FAIL;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS;

import java.io.File;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.Keyword;
import com.sungard.ktt.business.keywords.KeywordFactoryImpl;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;

/**
 * @author Ashish Joshi
 * Created for Script_1499 Under SAFAL 8.0.0, patch release 1
 * @creation date 30 Oct 2012
 * Parameters:
 *			sLocator = 	listOfParameters[0]; (Optional ,Locator of DatePicker Object, default: xpath=//span[@class='k-icon k-i-calendar'] )
 *			Value = 	listOfParameters[1]; (Mandatory ,Day to select from the DatePicker Control)
 */
/**
 * @author Ashish.Joshi
 *This Keyword will upload the File under Kendo Upload Control.
 */
public class UploadFileHTML5 extends AbstractKeyword{
	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();
	/**
	 * This is web element
	 */
	private WebElement oFileUpload = null; 
	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
	/**
	 *The Upload field locator
	 */
	private String sFileToUpload = null;
	/**
	 * File Name with path
	 */
	private String sLocator = null;
	/**
	 * Instance of the Object Locator, Default BLANK=1
	 */
	private String sLocator_Instance = null;
	@Override
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO executeScript(String... listOfParameters) {
		if (webDriver instanceof InternetExplorerDriver || webDriver instanceof EdgeDriver ){
			Keyword clickLink_Modal = KeywordFactoryImpl.getInstance().get("ClickLinkModal", "false");
			String[] params_clickLink_Modal = new String[8]; 
			params_clickLink_Modal[0] = OBJECT_SPECIFIER+sLocator;
			params_clickLink_Modal[1] = EMPTY_STRING; 
			params_clickLink_Modal[2] = EMPTY_STRING;
			params_clickLink_Modal[3] = EMPTY_STRING;
			params_clickLink_Modal[4] = EMPTY_STRING;
			params_clickLink_Modal[5] = EMPTY_STRING;
			params_clickLink_Modal[6] = EMPTY_STRING;//sModal_Flag
			params_clickLink_Modal[7] = EMPTY_STRING;
			
			TestcaseExecutionResultVO TestcaseExecutionResultCLM;
			try{
				TestcaseExecutionResultCLM = clickLink_Modal.execute(
							scriptName, this.webDriver, configurationMap,workBookMap,userName,
							params_clickLink_Modal);
					if (TestcaseExecutionResultCLM.getStatus() != PASS) 
					{							
						testCaseExecutionResult.setStatus(FAIL);
						return testCaseExecutionResult;
					}
			}
			catch(Exception e)
			{
				testCaseExecutionResult.setMessage("Error while clicking object");		
				testCaseExecutionResult.setStatus(FAIL);
				return testCaseExecutionResult;
			}
			
			
			
			
			Keyword runMacroWithParam = KeywordFactoryImpl.getInstance().get("RunMacroWithParam", "false"); 
			runMacroWithParam.setIpAddress(ipAddress);
			//RunMacroWithParam runMacroWithParam = new RunMacroWithParam();
			String[] params_1 = new String[8]; 
			params_1[0] = "Upload_File";
			params_1[1] = sFileToUpload; 
			params_1[2] = EMPTY_STRING;
			params_1[3] = EMPTY_STRING;
			params_1[4] = EMPTY_STRING;
			params_1[5] = EMPTY_STRING;
			params_1[6] = EMPTY_STRING;//sModal_Flag
			params_1[7] = EMPTY_STRING;//Excel_Kill_Flag
			
			if(webDriver instanceof EdgeDriver)
			{
				params_1[7] = "Open";
			}
			
			TestcaseExecutionResultVO TestcaseExecutionResultRMWP1;
			try{
					TestcaseExecutionResultRMWP1 = runMacroWithParam.execute(
							scriptName, this.webDriver, configurationMap,workBookMap,userName,
							params_1);
					if (TestcaseExecutionResultRMWP1.getStatus() != PASS) 
					{							
						testCaseExecutionResult.setStatus(FAIL);
						return testCaseExecutionResult;
					}
			}
			catch(Exception e)
			{
				logger.error("Error while uploading dialog");
				testCaseExecutionResult.setMessage("Error while uploading dialog");		
				testCaseExecutionResult.setStatus(FAIL);
				return testCaseExecutionResult;
			}
			
			testCaseExecutionResult.setStatus(PASS);
			
		}else{
			try {
					//oFileUpload.sendKeys(Keys.ENTER);
					//((JavascriptExecutor)webDriver).executeScript("arguments[0].click();",oFileUpload);
					oFileUpload.sendKeys(sFileToUpload);			
				testCaseExecutionResult.setStatus(PASS);
			} catch (Exception ex) {
				try {
					WebElement eletosendKey=null;
					List <WebElement> LWeb=oFileUpload.findElements(By.tagName("input"));
					int j=0;
					for(WebElement e1 : LWeb)
					{
						j=j+1;
						if(j==LWeb.size())
						{
							eletosendKey=e1;
							break;
						}
					}
					if(eletosendKey!=null)
					{eletosendKey.sendKeys(sFileToUpload);
					testCaseExecutionResult.setStatus(PASS);}
				} catch (Exception e1) {
					logger.error("Unable to set the value '"+sFileToUpload+"' to upload file box: "+ sLocator);
					testCaseExecutionResult.setMessage("Unable to set the value '"+sFileToUpload+"' to upload file box: "+ sLocator);
					testCaseExecutionResult.setStatus(0);
				}
	
			}
			
		}
		return testCaseExecutionResult;
	}


	@Override

	/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters listOfParameters[0]
	 *              (Mandatory) - sLocator -sFileToUpload-sLocator_Instance
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateKeyword(String... listOfParameters) {
		if (listOfParameters != null) 
		{
			sLocator=listOfParameters[0];
			sFileToUpload = listOfParameters[1];
			sLocator_Instance=listOfParameters[2];

		} else {
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}	

		testCaseExecutionResult.setTestData(sLocator+DELIMITER+sFileToUpload+DELIMITER+sLocator_Instance+DELIMITER+sLocator_Instance);
		if(KeywordUtilities.isEmptyString(sLocator))
		{
			logger.error("Upload File Locator not passed");
			testCaseExecutionResult.setMessage("Upload File Locator not passed");
			return testCaseExecutionResult;
		}

		if(KeywordUtilities.isEmptyString(sFileToUpload))
		{
			logger.error("File name with path not passed");
			testCaseExecutionResult.setMessage("File name with path not passed");
			return testCaseExecutionResult;
		}

		File file=new File(sFileToUpload);

		if(!file.exists())
		{
			logger.error("File name with path not passed");
			testCaseExecutionResult.setMessage("File Not Found: "+sFileToUpload);
			return testCaseExecutionResult; 
		}

		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;				
	}

	@Override
	/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... listOfParameters) {
		if(EMPTY_STRING.equals(sLocator_Instance))
		{
			sLocator_Instance="1";
		}

		if (sLocator.startsWith(OBJECT_SPECIFIER)) {
			sLocator = sLocator.substring(OBJECT_SPECIFIER.length(), sLocator.length());}

		if (webDriver == null) {
			logger.error(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}

		testCaseExecutionResult.setExpectedResultFlag(true);

		oFileUpload =KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, sLocator,sLocator_Instance, userName);
		if(oFileUpload==null)
		{
			logger.error("NumericText Box object not Found");
			testCaseExecutionResult.setMessage("NumericText Box object not Found");
			testCaseExecutionResult.setObjectError(true); 
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult; 
		}


		testCaseExecutionResult.setValid(true);
		testCaseExecutionResult.setObject(sLocator);
		return testCaseExecutionResult;
	}

}
