package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.EMPTY_STRING;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_WAIT_VARIABLE;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.util.TimeWatcher;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;
import com.sungard.ktt.view.config.KTTGuiConstants;
import com.sungard.ktt.view.config.KTTGuiConstants.ScriptStatus;
import com.sungard.ktt.web.util.SAFALUserSession;

/**
 * @author Dnyaneshwar.Daphal
 * This Keyword selects the specified item in a HTML5 dropdown list. 
 */
public class SelectListValueHTML5 extends AbstractKeyword{

	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();
	/**
	 * This is web element
	 */
	private WebElement listObjectElement;
	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
	/**
	 * To find drop down
	 */
	private String sList =  null;
	private String sInstance = null;
	/**
	 * Value to be selected
	 */
	private String svalueToSelect =null;
	private String sContainsFlag=null;
	private String searchforfilter=null;
	private String sObjectTypeFlagCOMBOORLIST=null;

	@Override
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO executeScript(String... params) {
	try {
		
		String sListName = "kendoDropDownList";
		
		if(sObjectTypeFlagCOMBOORLIST!=null && EMPTY_STRING.equals(sObjectTypeFlagCOMBOORLIST))
		{
			sObjectTypeFlagCOMBOORLIST="DROPDOWNLIST";
		}
		
		if(sObjectTypeFlagCOMBOORLIST!=null && sObjectTypeFlagCOMBOORLIST.toUpperCase().equals("DROPDOWNLIST"))
		{
			sListName= "kendoDropDownList";
		}
		else if (sObjectTypeFlagCOMBOORLIST!=null && sObjectTypeFlagCOMBOORLIST.toUpperCase().equals("COMBOLIST"))
		{
			sListName= "kendoComboBox";
		}

		if(sContainsFlag!=null && EMPTY_STRING.equals(sContainsFlag))
		{
			sContainsFlag="FALSE";
		}
		
		if((sContainsFlag!=null) && (sContainsFlag.toUpperCase().equals("TRUE") || sContainsFlag.toUpperCase().equals("YES") ||sContainsFlag.toUpperCase().equals("Y")))
		{
			sContainsFlag="TRUE";
		}
		
		String sfinalStatus="FAIL";
		String mySelector=EMPTY_STRING;
		
		
		int toWait_ObjWait=KTTGuiConstants.DEFAULT_OBJECT_WAIT_TIME;
		try{
		String val = configurationMap.get(OBJECT_WAIT_VARIABLE);
		if(val!=null)
		{
			toWait_ObjWait =Integer.parseInt(val); 
		}
		}catch(Exception e){logger.error("Exception::",e);}
		
		
		if(sContainsFlag!=null && sContainsFlag.equalsIgnoreCase("TRUE"))
		{
			mySelector=
					"f(arguments[0]);																								" +
					"function f(ELE)																						" + 
					"{																									" +
					"	var svalueToSelect = \""+svalueToSelect+ "\";													" +
					"	var listName = \""+sListName+ "\";																" + 
					"	var Result='FAIL';"
					+ " var allOptionsTxt='';																				" +
					"	try																								" +
					"	{																								" +
					"		var mObj = ELE;													" +
					"		var mkobj = $(mObj);																		" +
					"		var listDataObject = mkobj.data(listName);			"+
					
					(searchforfilter.equalsIgnoreCase("Y")?"listDataObject.search(svalueToSelect);":"")+
					"		var allItems = listDataObject.items();	"+
					"		var got = 0;																				" +
					
					//rakesh to open options
					"						try { listDataObject.open();  } catch(ee){} 						" +
					"						try { listDataObject.trigger('open');  } catch(ee){} 						" +
					
					///end
										
					
					
					"		for(dsd=0;dsd<allItems.length;dsd++)														" +
					"		{																							" +
					"			if(svalueToSelect.length==1)															" +
					"			{" +
					/*--------------------------SAF-1801, Ability to enter a single value on Drop Down Controller -------*/
					"					var txt='';" +
					"					if(allItems[dsd].innerText)" +
					"					{" +
					"						{try{txt=allItems[dsd].innerText;}catch(e1){txt='';}}" +
					"					}" +
					"					else" +
					"					{" +
					"						{try{txt=allItems[dsd].textContent;}catch(e1){txt='';}}" +
					"					}"
					+ "					allOptionsTxt=allOptionsTxt+';'+txt;" +
					"					if(txt.indexOf(svalueToSelect) > -1)								" +
					"					{																				" +
					"						try{allItems[dsd].click();}catch(e2){}"+
					"						listDataObject.select(dsd);													" +
					"						try { listDataObject.trigger('change');  } catch(ee){} 						" +
					"						got=1;																		" +	
					"						break;																		" +
					"					}																				" +
					"			}" +
					"			else																					" +
					"			{																						" +
					"					var txt='';" +
					"					if(allItems[dsd].innerText)" +
					"					{" +
					"						{try{txt=allItems[dsd].innerText;}catch(e1){txt='';}}" +
					"					}" +
					"					else" +
					"					{" +
					"						{try{txt=allItems[dsd].textContent;}catch(e1){txt='';}}" +
					"					}"+
					"					allOptionsTxt=allOptionsTxt+';'+txt;"
					+ "					if(txt.indexOf(svalueToSelect) > -1)										" +
					"					{																				" +
					"						try{allItems[dsd].click();}catch(e2){}"+
					//"						listDataObject.select(dsd);													" +
					"						try { listDataObject.trigger('change');  } catch(ee){} 						" +
					"						got=1;																		" +	
					"						break;																		" +
					"					}																				" +
					"			}																					    " +
					"		}																							" +
					"		if(got==1)																					" +
					"		{																							" +
					"           Result='PASS' ; "+
					"		}																							" +
					"		else																						" +
					"		{																							" +
					"            Result='FAIL, Value not found in List, Found Options: '+allOptionsTxt; "+
					"		}																							" +
					"	}																								" +
					"	catch(e)																						" +
					"	{																								" +
					"		Result='FAIL'+ e.description;																" +
					"	}																								" +
					"	return Result;																					" +
					"}" ;		
		}
		else
		{
			mySelector=
					"f(arguments[0]);																								" +
					"function f(ELE)																						" + 
					"{																									" +
					"	var svalueToSelect = \""+svalueToSelect+ "\";													" +
					"	var listName = \""+sListName+ "\";																" + 
					"	var Result='FAIL';	"
					+ "	var allOptionsTxt='';																		" +
					"	try																								" +
					"	{																								" +
					"		var mObj = ELE;													" +
					"		var mkobj = $(mObj);																		" +
					"		var listDataObject = mkobj.data(listName);			"+
					(searchforfilter.equalsIgnoreCase("Y")?"listDataObject.search(svalueToSelect);":"")+
					"		var allItems = listDataObject.items();	"+
					"		var got = 0;																				" +
					// rakesh to open options
					"						try { listDataObject.open();  } catch(ee){} 						" +
					"						try { listDataObject.trigger('open');  } catch(ee){} 						" +
					
					///end
					"						try { listDataObject.refresh();  } catch(ee){} 						" +
					"		for(dsd=0;dsd<allItems.length;dsd++)														" +
					"		{																							" +
					"			if(svalueToSelect.length==1)															" +
					"			{" +
					/*--------------------------SAF-1801, Ability to enter a single value on Drop Down Controller -------*/
					"					var txt='';" +
					"					if(allItems[dsd].innerText)" +
					"					{" +
					"						{try{txt=allItems[dsd].innerText;}catch(e1){txt='';}}" +
					"					}" +
					"					else" +
					"					{" +
					"						{try{txt=allItems[dsd].textContent;}catch(e1){txt='';}}" +
					"					}"
					+ "					allOptionsTxt=allOptionsTxt+';'+txt;" +
					"					if(txt.indexOf(svalueToSelect) == 0)								" +
					"					{																				" +
					"						try{allItems[dsd].click();}catch(e2){}"+
					
					//"						listDataObject.select(dsd);													" +
					"						try { listDataObject.trigger('change');  } catch(ee){} 						" +
					"						got=1;																		" +	
					"						break;																		" +
					"					}																				" +
					"			}" +
					"			else																					" +
					"			{																						" +
					"					var txt='';" +
					//"						try { listDataObject.refresh();  } catch(ee){} 						" +
					
					"					if(allItems[dsd].innerText)" +
					"					{" +
					"						{try{txt=allItems[dsd].innerText;}catch(e1){txt='';}}" +
					"					}" +
					"					else" +
					"					{" +
					"						{try{txt=allItems[dsd].textContent;}catch(e1){txt='';}}" +
					"					}"
					+ "					allOptionsTxt=allOptionsTxt+';'+txt;"+
					"					if(txt.indexOf(svalueToSelect) == 0 && trim(svalueToSelect)==  trim(txt))										" +
					"					{																				" +
					"						try{allItems[dsd].click();}catch(e2){}"+
					//"						listDataObject.select(dsd);													" +
					"						try { listDataObject.trigger('change');  } catch(ee){} 						" +
					"						got=1;																		" +	
					"						break;																		" +
					"					}																				" +
					"			}																					    " +
					"		}																							" +
				//// Rakesh- to close options
				//
				//	"						try { listDataObject.close();  } catch(ee){} 								" +
					"						try { listDataObject.trigger('close');  } catch(ee){} 						" +
				
				/// end					
					
					"		if(got==1)																					" +
					"		{																							" +
					"           Result='PASS' ; "+
					"		}																							" +
					"		else																						" +
					"		{																							" +
					"            Result='FAIL, Value not found in List, Found Options: '+allOptionsTxt; "+
					"		}																							" +
					"	}																								" +
					"	catch(e)																						" +
					"	{																								" +
					"		Result='FAIL'+ e.description;																" +
					"	}																								" +
					"	return Result;																					" +
					"}" +
					"function trim(s){return s.replace(/^\\s*/,\"\").replace(/\\s*$/, \"\");}";
		}
		//SAF-2640 , Added timewatcher for dropdown options loading
			sfinalStatus="FAIL";
			TimeWatcher timeWatcher = new TimeWatcher(toWait_ObjWait);
			timeWatcher.startTimeWatcher();
			while(!timeWatcher.isTimeUp(userName))
			{
				sfinalStatus="FAIL";
				if(SAFALUserSession.getSciptStatus(userName) == ScriptStatus.TO_BE_STOPPED)
				{		
					break;
				}
				try {
				sfinalStatus =((JavascriptExecutor)webDriver).executeScript("return "+mySelector ,listObjectElement).toString();
				} catch (Exception e) {
					sfinalStatus="FAIL";
				}
				
				if(sfinalStatus.equalsIgnoreCase("PASS"))
				{
					break;
				}
			}
			timeWatcher.cancel();
			//SAF-2640 , Added timewatcher for dropdown options loading
			
		if(sfinalStatus.equalsIgnoreCase("PASS"))
		{
			testCaseExecutionResult.setStatus(1);
			return testCaseExecutionResult;
		}
		else
		{
			logger.error(sfinalStatus.replaceAll("FAIL", ""));
			testCaseExecutionResult.setMessage(sfinalStatus.replaceAll("FAIL", ""));
			return testCaseExecutionResult;
		}
		} catch (Exception e) {
			logger.error("Exception::"+e.getCause().toString());
			testCaseExecutionResult.setMessage(e.getCause().toString());
			return testCaseExecutionResult;
		}

	}
	/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters
	 *            - link name -
	 * 
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	
	@Override
	public TestcaseExecutionResultVO validateKeyword(String... params) {
		if(params!=null){
			sList=params[0];
			svalueToSelect=params[1];
			sInstance=params[2];
			sContainsFlag = params[3];
			sObjectTypeFlagCOMBOORLIST = params[4];
			searchforfilter= params[5];
		}
		else{
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setTestData(params[0]+DELIMITER+params[1] +DELIMITER+params[2]);
		if(EMPTY_STRING.equals(sList))
		{
			logger.error("list box locator not given");
			testCaseExecutionResult.setMessage("list box locator not given");
			return testCaseExecutionResult;
		}
		
		if(searchforfilter.equalsIgnoreCase("y")||searchforfilter.equalsIgnoreCase("yes")||searchforfilter.equalsIgnoreCase("True"))
		{
			searchforfilter= "Y";
		}else{
			searchforfilter= "N";
		}

	//SAF-2481 - By Ashish
		/*if(EMPTY_STRING.equals(svalueToSelect))
		{
			logger.error("value to select not given");
			testCaseExecutionResult.setMessage("value to select not given");
			return testCaseExecutionResult;
		}*/
		//SAF-2481 - By Ashish

		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}

	@Override

	/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... params) {

		if (webDriver == null) {
			logger.error(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}
		if (sList.startsWith(OBJECT_SPECIFIER)) {

			sList = sList.substring(OBJECT_SPECIFIER.length(), sList.length());
		} 

		listObjectElement=KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, sList,sInstance, userName);

		if (listObjectElement==null) {
			logger.error("List box not found");
			testCaseExecutionResult.setMessage("List box not found");
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setObject(sList);
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}}
