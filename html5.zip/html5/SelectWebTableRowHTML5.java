package com.sungard.ktt.business.keywords.html5;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_INVALID_ROW_NUMBER_PASSED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_SEARCH_VALUE_NOT_FOUND;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_TABLE_COLS_NOT_PASSED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_TABLE_LOCATOR_NOT_PASSED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_TABLE_ROW_NOT_FOUND;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.EMPTY_STRING;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS_STEP_STATUS;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;
import com.sungard.ktt.view.config.KTTGuiConstants;
/**
 * @update Lance.Ingram
 * @update Gyaneshwar.Nandanwar on 25-Oct-2013
 */
public class SelectWebTableRowHTML5 extends AbstractKeyword 
{
	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();
	/**
	 * This is webelement
	 */
	private WebElement elementTable, elementTableHeader;

	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
	/**
	 * To find Table- refer Data grid locator
	 */
	private String sTableHeader = null;
	/**
	 * column name or column number (This is mandatory when Row number is not provided)
	 */
	private String sColumnName = null;
	/**
	 * Column value (This is mandatory when Row number is not provided)
	 */
	private String sColValues = null;
	/**
	 * Row number to select, (This is mandatory when column name and column value are blank)
	 */
	private String sRowNumbersToSelect = null;
	/**
	 * Header row number if header has multiple rows, by default it will take first row 
	 */
	private String sColHeaderStrtRowNum=null;
	/**
	 * After selecting the specified row, it will store the row number in an Env variable.
	 */
	private String sVariableName=null;
	
	private String wetableInvestOne=null;

	public static final String KENDO_GRID_NAME="KendoGridName";
	public static final String DEFAULT_KENDO_GRID_NAME="kendoGrid";


	@Override
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */

	public TestcaseExecutionResultVO executeScript(String... listOfParameters)
	{
		String sGridName=DEFAULT_KENDO_GRID_NAME;
		try {
			sGridName =configurationMap.get(KENDO_GRID_NAME);
		} catch (Exception e3) {
			sGridName=DEFAULT_KENDO_GRID_NAME;
		}

		if(sGridName==null)
		{
			sGridName=DEFAULT_KENDO_GRID_NAME;
		}
		if (KeywordUtilities.isEmptyString(sVariableName))
		{
			sVariableName="RowNumber";
		}
		if (KeywordUtilities.isEmptyString(sColHeaderStrtRowNum))
		{
			sColHeaderStrtRowNum="0";
		}
		
		/*try {
			elementTable=KeywordUtilities.getWebElement(webDriver, sTableHeader);
		} catch (Exception e) {
			testCaseExecutionResult.setMessage("Unable TO Find Element: "+ sTableHeader);
		}*/
		String numCols[] = sColumnName.trim().split("\\|");


		int iColFlag=1;
		try {
			Integer.parseInt(numCols[0]);
		} catch (NumberFormatException e3) {
			iColFlag=0;
		}
		
		String RowNumbers=EMPTY_STRING;
		if(wetableInvestOne.equalsIgnoreCase("Y")||wetableInvestOne.equalsIgnoreCase("Yes")||wetableInvestOne.equalsIgnoreCase("True")){
			
			if (KeywordUtilities.isEmptyString(sRowNumbersToSelect)) {
					if(iColFlag == 0){
						logger.error("Define column index");
						testCaseExecutionResult.setMessage("Define column index");
						return testCaseExecutionResult;				
					}
					
					String[] splitColumnNumbers = sColumnName.split("\\|");
					String colNumbers="";
					for (int i=0;i<splitColumnNumbers.length;i++){
						int colNum = Integer.parseInt(splitColumnNumbers[i]);
						colNum--;
						sColumnName=Integer.toString(colNum);
						if (i==0)
							colNumbers=sColumnName;
						else
							colNumbers=colNumbers+"|"+sColumnName;
					}
					
					
					
					String getExpectedRowNo = "var rtbl = arguments[0];"+
					"try{"+
					"var colnum =\""+colNumbers+"\";"+
					"var rws=rtbl.rows;"+
					"var colnums =colnum.split(\"|\");"+
					"var rowValue=\""+sColValues+"\";"+
					"var found = 'FAIL';"+
					
					"var rowNo = '-1';"+
					"for(i=1;i<rws.length;i++){"+
					"        var rowData='';"+
					"   for(j=0;j<colnums.length;j++){"+
					"        var s=colnums[j]; "+
					"         if(j==0){"+
					"             rowData=trim(rws[i].cells[s].innerText); "+
					"            }else{"+
					" 				rowData=rowData+\"|\"+trim(rws[i].cells[s].innerText);"+
					"         }	"+
					"          "+
					"     }"+
					//"         	alert(rowData);"+					
				
					" if(rowData.toUpperCase() ==rowValue.toUpperCase()){"+
					"      found ='PASS';"+
					"         rowNo=i;"+
					"        break;"+
					"       "+					
					" 	}"+
					"}"+
					"if(found =='PASS'){"+
					"      return rowNo+'';  "+
					"   }"+
					"else{"+
					"    return 'FAIL'; "+
					"}"+
					"}catch(e99){ return 'FAIL';}"+					
					"function trim(s){return s.replace(/^\\s*/,\"\").replace(/\\s*$/, \"\");}";		
					
					try{
						String temp = ((JavascriptExecutor)webDriver).executeScript(getExpectedRowNo,elementTable).toString();
						RowNumbers=temp;
						//System.out.println(temp);
					}catch(Exception e1){
						logger.error("Exception::",e1);
					}					
			}else{
					RowNumbers=sRowNumbersToSelect; 
			}
			
			String SelectRow = "var rtbl = arguments[0];"+
					"try{"+
					"	var rownum =\""+RowNumbers+"\";"+
					"	var rws=rtbl.rows;"+					
					"		rws[rownum].click();"  +
					"    	return 'PASS';"+
					"}"+
					"catch(e99){"+
					"	return 'FAIL';"+
					"}";
			String sfinalStatus ="";
			try{
				sfinalStatus = ((JavascriptExecutor)webDriver).executeScript(SelectRow,elementTable).toString();
			}catch(Exception e){
				logger.error("Exception::",e);
				sfinalStatus ="Error";
			}
			if (sfinalStatus.trim().equalsIgnoreCase(PASS_STEP_STATUS))
			{
				testCaseExecutionResult.setStatus(PASS);
				return testCaseExecutionResult;
			} else
			{
				logger.error(sfinalStatus);
				testCaseExecutionResult.setMessage(sfinalStatus);
				return testCaseExecutionResult;
			}	
			
			
			
			
			
		}
		
		
		
		
		/*try {
			elementTableHeader=KeywordUtilitiesHTML5.kendoDataControl(webDriver, elementTable,"grid");
		} catch (Exception e) {
			logger.error("Unable TO Find Column Header Element:");
			testCaseExecutionResult.setMessage("Unable TO Find Column Header Element:");
			return testCaseExecutionResult;
		}*/

		
		if (KeywordUtilities.isEmptyString(sRowNumbersToSelect)) {
			if (iColFlag==0) {	
				sColumnName= KeywordUtilitiesHTML5.returnColumnNumber(webDriver,elementTableHeader, sColumnName,sColHeaderStrtRowNum,sGridName );
				if (sColumnName.contains("FAIL")) {
					logger.error("FAIL!, Require Column headers not found. Found columns for given Table are:"+sColumnName);
					testCaseExecutionResult.setMessage("FAIL!, Require Column headers not found. Found columns for given Table are:"+sColumnName);
					return testCaseExecutionResult;
				}
				iColFlag=1;
			}

			/// add for test	
			String[] splitColumnNumbers = sColumnName.split("\\|");
			String colNumbers="";
			for (int i=0;i<splitColumnNumbers.length;i++){
				int colNum = Integer.parseInt(splitColumnNumbers[i]);
				colNum--;
				sColumnName=Integer.toString(colNum);
				if (i==0)
					colNumbers=sColumnName;
				else
					colNumbers=colNumbers+"|"+sColumnName;
			}

			/// End for test for test

			RowNumbers = KeywordUtilitiesHTML5.returnRowNumbers(webDriver, elementTableHeader, colNumbers, sColValues, sGridName);
			if (RowNumbers.contains("ROW_ERR")) {
				logger.error(ERROR_TABLE_ROW_NOT_FOUND);
				testCaseExecutionResult.setMessage(ERROR_TABLE_ROW_NOT_FOUND);
				return testCaseExecutionResult;
			}
			configurationMap.put(sVariableName,RowNumbers);
			testCaseExecutionResult.setConfigUpdate(true);
		}
		else
			RowNumbers=sRowNumbersToSelect;
		//The below code is for getting the current selected frame and set document object at the top level
		//------------------------------------------------------------------------------------------------------
		//String sFrameValue =configurationMap.get(FRAME_NAME_ENV);
		//try {
			//webDriver.switchTo().defaultContent();
			/*Keyword selectFrame = KeywordFactoryImpl.getInstance().get("SelectFrame", "false");
			String[] listOfParametersFrame = new String[3]; 
			listOfParametersFrame[0]="DEFAULT CONTENT";
			listOfParametersFrame[1]="1";
			listOfParametersFrame[2]="TRUE";			
			selectFrame.execute(null, webDriver,configurationMap,null, userName, listOfParametersFrame);*/
			//} catch (Exception e2) {}
		//------------------------------------------------------------------------------------------------------
		String SelectWebTableRow=
				"	  return selectWebtableRow(arguments[0]);																						"+
						"	  function selectWebtableRow(HTML5_Table_obj)																			"+
						"	  {																							            				"+
						"		try																												"+
						"		{" +
						"	   	var rowNumber=\""+RowNumbers+"\";																					"+			
						"		var HTML5_Table_Kendo=$(HTML5_Table_obj).data('kendoGrid');"+			
						" 		var TableData = HTML5_Table_Kendo.tbody;	"+
						"		 var childSize=0;"+
						"		 try{"+
						"				childSize=TableData.children().size();" + 
						"			}" +
						"		  catch(e){"
						+ "				childSize=TableData.children().length;"+
						"		 }"+
						"       if(childSize<rowNumber)																					"+
						"		{																										"+
						"			return \""+ERROR_INVALID_ROW_NUMBER_PASSED+"\";														"+
						"		}"+
						"		var SplitedRowNumber=rowNumber.split(\"|\");"+
						"		for (var i=0;i<SplitedRowNumber.length;i++)"+
						"		{"+
						"			rowNumber=SplitedRowNumber[i]-1;"+
						"			row = TableData.find('tr:eq('+rowNumber+')');"+
						"			HTML5_Table_Kendo.select(row);																						"+

			"					}"+
			"					}catch(error1)																					"+
			"					{																								"+
			"						return (error1.description);																"+
			"					}																								"+
			"				return 'PASS';"+
			"				}";


		String sfinalStatus=KTTGuiConstants.EMPTY_STRING;
		try{			
			sfinalStatus = (String)((JavascriptExecutor)webDriver).executeScript(SelectWebTableRow.toString(), elementTableHeader);
		} catch (Exception e) {
			logger.error("Exception::"+e.getCause().toString());
			testCaseExecutionResult.setMessage(e.getCause().toString());
			return testCaseExecutionResult;

		}

		if (sfinalStatus.trim().equalsIgnoreCase(PASS_STEP_STATUS))
		{
			testCaseExecutionResult.setStatus(PASS);
			return testCaseExecutionResult;
		} else
		{
			logger.error(sfinalStatus);
			testCaseExecutionResult.setMessage(sfinalStatus);
			return testCaseExecutionResult;
		}
	}

	@Override

	/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters 
	 *             -sTableHeader-sColumnName -sColValues-sRowNumbersToSelect
	 *              sColHeaderStrtRowNum -sVariableName
	 * 
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */



	public TestcaseExecutionResultVO validateKeyword(String... listOfParameters)
	{
		// check for required parameter count
		if (listOfParameters != null)
		{
			sTableHeader = listOfParameters[0];
			sColumnName = listOfParameters[1];
			sColValues = listOfParameters[2];
			sRowNumbersToSelect = listOfParameters[3];
			sColHeaderStrtRowNum = listOfParameters[4];
			sVariableName = listOfParameters[5];
			wetableInvestOne = listOfParameters[6];
		} else
		{
			// Insufficient Parameters
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setTestData(sTableHeader+DELIMITER+sColumnName	+DELIMITER + sColValues+DELIMITER+sRowNumbersToSelect 
				+DELIMITER+sColHeaderStrtRowNum +DELIMITER+ sVariableName);

		if (KeywordUtilities.isEmptyString(sTableHeader))
		{
			logger.error(ERROR_TABLE_LOCATOR_NOT_PASSED);
			testCaseExecutionResult.setMessage(ERROR_TABLE_LOCATOR_NOT_PASSED);
			return testCaseExecutionResult;
		}
		if (KeywordUtilities.isEmptyString(sRowNumbersToSelect)){
			if (KeywordUtilities.isEmptyString(sColumnName))
			{
				logger.error(ERROR_TABLE_COLS_NOT_PASSED);
				testCaseExecutionResult.setMessage(ERROR_TABLE_COLS_NOT_PASSED);
				return testCaseExecutionResult;
			}
			if (KeywordUtilities.isEmptyString(sColValues))
			{
				logger.error(ERROR_SEARCH_VALUE_NOT_FOUND);
				testCaseExecutionResult.setMessage(ERROR_SEARCH_VALUE_NOT_FOUND);
				return testCaseExecutionResult;
			}
		}
		if (!KeywordUtilities.isEmptyString(sRowNumbersToSelect) && !KeywordUtilities.isValidPositiveNumbericValue(sRowNumbersToSelect))
		{
			logger.error("Row number should be numeric");
			testCaseExecutionResult.setMessage("Row number should be numeric");
			return testCaseExecutionResult;
		}
		// check for numeric instance value
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;

	}

	@Override

	/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... listOfParameters)
	{
		//String sTableHeader =listOfParameters[0];

		if (webDriver == null)
		{
			// Browser not instantiated
			logger.error(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}

		//testcaseExecutionRes.setObject(sTableHeader);

		if (sTableHeader.startsWith(OBJECT_SPECIFIER))
		{
			sTableHeader = sTableHeader.substring(OBJECT_SPECIFIER.length(),sTableHeader.length());
		}

		elementTable=KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap,webDriver, sTableHeader, "", userName);

		if (elementTable==null) {

			logger.error ("Table not found");
			testCaseExecutionResult.setMessage("Table not found");
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}

		if(!wetableInvestOne.equalsIgnoreCase("Y")||!wetableInvestOne.equalsIgnoreCase("Yes")||!wetableInvestOne.equalsIgnoreCase("True")){
			try {
				elementTableHeader=KeywordUtilitiesHTML5.kendoDataControl(webDriver, elementTable,"grid");
			} catch (Exception e) {
				logger.error("Unable TO Find Column Header Element:");
				testCaseExecutionResult.setMessage("Unable TO Find Column Header Element:");
				return testCaseExecutionResult;
			}
		}

		testCaseExecutionResult.setObject(sTableHeader);
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;

	}
}
