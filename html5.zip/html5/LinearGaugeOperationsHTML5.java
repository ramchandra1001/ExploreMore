package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;

/**
 * @author Dnyaneshwar.Daphal
 *
 */
public class LinearGaugeOperationsHTML5 extends AbstractKeyword {
	TestcaseExecutionResultVO testCaseExecutionResult =  new TestcaseExecutionResultVO();

	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());

	/**
	 * The Linear Gauge locator
	 */

	private String sDivlocator ;
	/**
	 * SET or GET (Default SET)
	 */
	private String sOperation ;
	/**
	 * Value to Set to Linear Gauge, 
	 * Blank in case of GET operation
	 */
	private String sValue ;
	/**
	 * Default LinearGaugeValue, 
	 * Blank in case of SET operation
	 */
	private String sEnvVariable;
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */

	public TestcaseExecutionResultVO executeScript(String... params) 
	{

		String sLinearGuageNameInKendo = "kendoLinearGauge";

		if (sDivlocator.startsWith(OBJECT_SPECIFIER)) {

			sDivlocator = sDivlocator.substring(OBJECT_SPECIFIER.length(), sDivlocator.length());
		} 

		WebElement divElement=KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, sDivlocator,"", userName);

		if (divElement==null) 
		{
			logger.error("Linear Gauge object not found");
			testCaseExecutionResult.setMessage("Linear Gauge object not found");
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}

		String sfinalStatus="FAIL";


		if(sOperation==null || "".equals(sOperation))
		{
			sOperation = "SET";
		}
		sOperation=sOperation.toUpperCase();

		try {
			if(sOperation.equals("SET"))
			{

				String mySelector=
						"f(arguments[0]);																								" +
								"function f(ELE)																						" + 
								"{																									" +
								"	var svalueToSet = \""+sValue+ "\";																" +
								"	var sLinearGuageNameInKendo = \""+sLinearGuageNameInKendo+ "\";									" + 
								"	var Result='FAIL';																				" +
								"	try																								" +
								"	{																								" +
								"		var mkobj = $(ELE);																		" +
								"		var LinearGuageObject = mkobj.data(sLinearGuageNameInKendo);								" +
								"		LinearGuageObject.value(svalueToSet);														" +								
								"		return \"PASS\";	   																    	" +
								"	}																								" +
								"	catch(e)																						" +
								"	{																								" +
								"		Result='FAIL'+ e.description;																" +
								"	}																								" +
								"	return Result;																					" +
								"}" ;

				sfinalStatus="FAIL";

				try {
					sfinalStatus =((JavascriptExecutor)webDriver).executeScript("return "+mySelector,divElement).toString();
				} catch (Exception e) {

					sfinalStatus="FAIL";
				}

				if(sfinalStatus.equalsIgnoreCase("PASS"))
				{
					testCaseExecutionResult.setStatus(1);
					return testCaseExecutionResult;
				}
				else
				{
					logger.error(sfinalStatus.replaceAll("FAIL", ""));
					testCaseExecutionResult.setMessage(sfinalStatus.replaceAll("FAIL", ""));
					return testCaseExecutionResult;
				}

			}
			else 
			{

				String mySelector=
						"f(arguments[0]);																								" +
								"function f(ELE)																						" + 
								"{																									" +
								"	var svalueToSet = \""+sValue+ "\";																" +
								"	var sLinearGuageNameInKendo = \""+sLinearGuageNameInKendo+ "\";									" + 
								"	var Result='FAIL';																				" +
								"	try																								" +
								"	{																								" +
								"		var mkobj = $(ELE);																		" +
								"		var LinearGuageObject = mkobj.data(sLinearGuageNameInKendo);								" +
								"		return LinearGuageObject.value();	   																    	" +
								"	}																								" +
								"	catch(e)																						" +
								"	{																								" +
								"		Result='FAIL'+ e.description;																" +
								"	}																								" +
								"	return Result;																					" +
								"}" ;

				sfinalStatus="FAIL";

				try {
					sfinalStatus =((JavascriptExecutor)webDriver).executeScript("return "+mySelector,divElement).toString();
				} catch (Exception e) {

					sfinalStatus="FAIL";
				}

				if(sfinalStatus.contains("FAIL"))
				{
					logger.error(sfinalStatus);
					testCaseExecutionResult.setMessage(sfinalStatus);
				}
				else
				{

					if(sEnvVariable.isEmpty())
					{
						sEnvVariable = "LinearGuageValue";
					}

					configurationMap.put(sEnvVariable, sfinalStatus);
					testCaseExecutionResult.setConfigUpdate(true);
					testCaseExecutionResult.setStatus(1);
				}

				return testCaseExecutionResult;

			}
		} 
		catch (Exception e1)
		{
			logger.error("Exception::"+e1.getCause().toString());
			testCaseExecutionResult.setMessage(e1.getCause().toString());
			return testCaseExecutionResult;
		}
	}

	@Override


	/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters
	 *            - link name -
	 * 
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateKeyword(String... params) {

		if(params!=null)
		{

			sDivlocator =  params[0];
			sOperation =  params[1];
			sValue =  params[2];
			sEnvVariable =  params[3];
		}
		else
		{
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}
		if(sDivlocator.isEmpty())
		{
			logger.error("Locator not provided");
			testCaseExecutionResult.setMessage("Locator not provided");
			return testCaseExecutionResult;
		}


		if(sOperation==null || "".equals(sOperation))
		{
			sOperation = "SET";
		}
		sOperation=sOperation.toUpperCase();

		if(sOperation.equals("SET"))
		{
			testCaseExecutionResult.setTestData("Operation : "+sOperation+" sValue : "+sValue);	
		}

		else if(sOperation.equals("GET"))
		{
			testCaseExecutionResult.setTestData("Operation : "+sOperation+" sEnvVariable : "+sEnvVariable);	
		}
		else
		{
			logger.error("Invalid operation provided in Param2 i.e."+sOperation);
			testCaseExecutionResult.setMessage("Invalid operation provided in Param2 i.e."+sOperation);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}

	@Override

	/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... params) {

		if (webDriver == null) {
			logger.error ("ERROR_BROWSER_NOT_INSTANTIATED");
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}

}
