package com.sungard.ktt.business.keywords.html5;


import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_FILE_PATH_DOESNOT_EXIST;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_FILE_PATH_NOT_PASSED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_TABLE_NOT_FOUND;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_TABLE_PARA_NOT_PASSED;
import static com.sungard.ktt.business.keywords.ErrorMessages.FILE_NAME_NOT_PASSED;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.EMPTY_STRING;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Vector;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;
import com.sungard.ktt.view.config.KTTGuiConstants;

/**
 *  @author Gyaneshwar.Nandanwar on 06-Nov-2013
 *  This keyword copies the web table data to Excel sheet.
 */
public class CopyWebTableDataToExcelHTML5 extends AbstractKeyword {


	TestcaseExecutionResultVO testCaseExecutionResult  = new TestcaseExecutionResultVO();
	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
	/**
	 * This is web element object
	 */
	private WebElement elementTableId, elementTableHTML5;
	/**
	 * To find Table - refer Data grid locator
	 */
	private String sTableId=null;
	/**
	 * Specify the path of the folder in which the Excel sheet is to be created
	 */
	private String sFilePath=null;
	/**
	 * Sheet Name, if not provided then it will take default value as- ExportedDataSheet
	 */
	private String sSheetName=null;
	/**
	 * Boolean value, when we want to append the new data to existing file. Default value is - N
	 */
	private String sAppendFlag=null;
	/**
	 *File Name to store the table data 
	 */
	private String sFileName = null;
	/**
	 *Speciify the column names which need to be skipped from copying,
	 * separatd by � ; (semicolon)
	 */
	private String skipCols = null;
	/* below three parameters used in  execute script*/
	private  String sFrameName = null;
	private  String sHeaderRowNum = null;
	private  String sFrameArr[] = null;

	@Override
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */

	public TestcaseExecutionResultVO executeScript(String... listOfParameters) {

		if (KeywordUtilities.isEmptyString(sSheetName))
		{
			sSheetName = "ExportedDataSheet";
		}		
		if (KeywordUtilities.isEmptyString(sAppendFlag))
		{
			sAppendFlag = "N";
		}
		try {
			String sTemp1="";
			if (sFilePath.startsWith("%")){
				int ilength= sFilePath.indexOf("%", 1);
				sTemp1=sFilePath.substring(1, ilength);			
				String sTemp2=System.getenv(sTemp1);
				sFilePath=sFilePath.replace("%"+sTemp1+"%", sTemp2);
			}
		} catch (Exception E){
			logger.error(ERROR_FILE_PATH_DOESNOT_EXIST);
			testCaseExecutionResult.setMessage(ERROR_FILE_PATH_DOESNOT_EXIST);
			return testCaseExecutionResult;
		}

		try{webDriver.switchTo().defaultContent();}catch(Exception e){logger.error("Exception::",e);}
		sFrameName=configurationMap.get("FrameName");

		if (sFrameName != null && !sFrameName.isEmpty()) 
		{
			sFrameArr = sFrameName.split(";");
			try {
				webDriver.switchTo().defaultContent();
			} catch (Exception e) {
					logger.error("Exception::", e);
			}	
			try 
			{
				for (int Count = 0; Count < sFrameArr.length; Count++) 
				{
					webDriver.switchTo().frame(sFrameArr[Count]);
				}
			} 
			catch (Exception err) 
			{
				logger.error("Frame not Selected::",err);
			}
		}		
		try {
			elementTableId=KeywordUtilities.getWebElement(webDriver, sTableId);
			elementTableHTML5 = KeywordUtilitiesHTML5.kendoDataControl(webDriver, elementTableId,"grid");
		} catch (Exception e) {
			logger.error("Unable TO Find Element: "+sTableId);
			testCaseExecutionResult.setMessage("Unable TO Find Element: "+sTableId);
		}
		int iHeaderRowNumber=0;
		try{
			iHeaderRowNumber=Integer.parseInt(sHeaderRowNum);
		}
		catch (Exception e) {
			iHeaderRowNumber=0;
		}		
		try 
		{
			String sWebTableDataCapture=		
					"		return CaptureTableData(arguments[0],arguments[1]);															"+
							"		function CaptureTableData(TableObj, HTML5_Table_obj)														"+
							"		{																											"+
							"		 var iHeader=\""+iHeaderRowNumber+"\";																		"+
							"		 var HTML5_Table_Kendo=$(HTML5_Table_obj).data('kendoGrid');												"+
							" 		 var TableHeader = HTML5_Table_Kendo.thead;																	"+
							"		 var HeaderColumnRow=TableHeader.find('tr:eq(\""+iHeaderRowNumber+"\")');									"+	
							"		 var TableHeaderText='';																					"+
							"		 var childSize=0;"+
							"		 try{"+
							"				childSize=HeaderColumnRow.children().size();" + 
							"			}" +
							"		  catch(e){"
							+ "				childSize=HeaderColumnRow.children().length;"+
							"		 }"+
							"		 for (var a=0;a<childSize;a++)														"+
							"		 {																											"+
							"			var HeaderText = HeaderColumnRow.find('th:eq('+a+')').text();											"+	
							" 			if (HeaderText=='')																						"+
							"				HeaderText='<EMPTY>';																				"+
							"			if (a==0)																								"+
							"		    {																										"+
							"			 	TableHeaderText=HeaderText;																			"+
							"			}																										"+
							"			else																									"+
							"			{																										"+
							"			 	TableHeaderText=TableHeaderText+\"@#@\"+HeaderText;													"+
							"			}																										"+
							"		 }																											"+
							"		 var RetStringArr = new Array();																			"+
							"		 var rtbl=TableObj;																							"+
							"			for (i=0;i<rtbl.rows.length;i++)																		"+
							"				{																									"+
							"					strCellData = \"\";																				"+
							"					CellValue = \"\";																				"+
							"					var rowdata=rtbl.rows.item(i).cells;															"+
							"					for (j=0;j<rowdata.length;j++)																	"+
							"						{																							"+
							"						if (rowdata[j].innerText=='')																"+
							"							CellValue='<EMPTY>';																	"+
							"						else																						"+
							"							CellValue=rowdata[j].innerText;															"+
							"							if (j==0)																				"+
							"								{																					"+
							"									strCellData=CellValue;															"+
							"								}																					"+
							"							else																					"+
							"								{																					"+
							"									strCellData=strCellData+\"@#@\"+CellValue;										"+
							"								}																					"+
							"						}																							"+
							"					RetStringArr[i]=strCellData;																	"+
							"				}																									"+
							"			for (k=0;k<RetStringArr.length;k++)																		"+
							"				{																									"+
							"					if (k==0)																						"+
							"						{																							"+
							"							strRetString=RetStringArr[k];															"+
							"						}																							"+
							"					else																							"+
							"						{																							"+
							"							strRetString = strRetString+\"%#%\"+RetStringArr[k];									"+
							"						}																							"+
							"				}																									"+
							"			return (TableHeaderText+\"%#%\"+strRetString);															"+
							"	}";

			try {
				
				
				String sgetBrowser=EMPTY_STRING;
				
				//SAF-2665 Now sgetBrowser returns "INTERNET EXPLORER" instead of "MSIE".Hence adding logic to handle this.
				try
				{
					Capabilities caps = ((RemoteWebDriver) this.webDriver).getCapabilities();
					sgetBrowser = caps.getBrowserName();

				}catch(Exception e){						
					sgetBrowser=EMPTY_STRING;}


				String finalStatusArr[];
				String finalStatus=KTTGuiConstants.EMPTY_STRING;
				try{
					if(sgetBrowser.toUpperCase().contains(KTTGuiConstants.INTERNET_EXPLORER_STRING)) 
					{
						finalStatus = (String)((JavascriptExecutor)webDriver).executeScript(sWebTableDataCapture.toString(), elementTableId, elementTableHTML5);
					}
					else
					{
						sWebTableDataCapture=sWebTableDataCapture.replaceAll("innerText", "textContent");
						finalStatus = (String)((JavascriptExecutor)webDriver).executeScript(sWebTableDataCapture.toString(), elementTableId,elementTableHTML5);
					}
				} catch (Exception e) {
					logger.error("Exception"+e.getCause().toString());
					testCaseExecutionResult.setMessage(e.getCause().toString());
					return testCaseExecutionResult;
				}			
				finalStatusArr = finalStatus.split("%#%");
				Vector<Integer> skipCol=new Vector<Integer>();

				if(!KeywordUtilities.isEmptyString(skipCols))
				{
					try {
						String skipColsArr[]=skipCols.split(KTTGuiConstants.SEMICOLON);						
						for (int skipColsNum= 0;skipColsNum<skipColsArr.length;skipColsNum++ )
						{
							for (int RowNum=0;RowNum<finalStatusArr.length;RowNum++)
							{
								String[] ArrColumnData;
								ArrColumnData = finalStatusArr[RowNum].split("@#@");

								for (int ColNum=0;ColNum<ArrColumnData.length;ColNum++)
								{			
									if(ArrColumnData[ColNum].trim().equalsIgnoreCase(skipColsArr[skipColsNum]))
									{
										skipCol.add(ColNum);
									}
								}
							}
						}
					} catch (Exception e) {		
						logger.error("Skip Column should be seperated by ; ");
						testCaseExecutionResult.setMessage("Skip Column should be seperated by ; ");
						return testCaseExecutionResult;
					}
				}				
				File file = new File(sFilePath);
				if (file.isDirectory()) {
					if (KeywordUtilities.isEmptyString(sFileName)){
						logger.error(FILE_NAME_NOT_PASSED);
						testCaseExecutionResult.setMessage(FILE_NAME_NOT_PASSED);
						return testCaseExecutionResult;
					}
					else {
						if (sFilePath.endsWith(File.separator)){
							sFilePath = sFilePath+sFileName;
						}
						else {
							sFilePath = sFilePath+ File.separator +sFileName;
						}						
					}
				}
				else {
					if (!(sFilePath.toUpperCase().endsWith(".XLS"))){
						logger.error(ERROR_FILE_PATH_DOESNOT_EXIST);
						testCaseExecutionResult.setMessage(ERROR_FILE_PATH_DOESNOT_EXIST);
						return testCaseExecutionResult;
					}
				}
				file = new File(sFilePath);
				if (!file.exists()) {
					HSSFWorkbook wb = new HSSFWorkbook();
					FileOutputStream fileOut;
					try {
						fileOut = new FileOutputStream(file);
						wb.write(fileOut);
						fileOut.close();
					} catch (FileNotFoundException e) {
						logger.error("FileNotFoundException::", e);
					} catch (IOException e) {
						logger.error("IOException::", e);
					}
				}
				try{
					HSSFWorkbook resultWorkBook = new HSSFWorkbook(new FileInputStream(sFilePath));
					HSSFSheet resultSheet = resultWorkBook.getSheet(sSheetName);
					if (resultSheet == null)
					{
						resultSheet = resultWorkBook.createSheet(sSheetName);
					}
					else
					{

						if (!sAppendFlag.equalsIgnoreCase("Y"))
						{
							int iSheetNumber = resultWorkBook.getSheetIndex(resultSheet);
							resultWorkBook.removeSheetAt(iSheetNumber);
							resultSheet = resultWorkBook.createSheet(sSheetName);

						}
					}

					FileOutputStream resultFileOut = new FileOutputStream(sFilePath);
					resultWorkBook.write(resultFileOut);
					resultFileOut.close();

				}
				catch (Exception eFile)
				{
					if (eFile.getMessage().indexOf(("The system cannot find the file specified")) >= 0)
					{
						HSSFWorkbook resultWorkBook = new HSSFWorkbook();
						resultWorkBook.createSheet(sSheetName);
						FileOutputStream resultFileOut = new FileOutputStream(sFilePath);
						resultWorkBook.write(resultFileOut);
						resultFileOut.close();
					}
				}

				HSSFWorkbook resultWorkBook = new HSSFWorkbook(new FileInputStream(sFilePath));
				HSSFSheet resultSheet = resultWorkBook.getSheet(sSheetName);
				int FirstRowNum = 0;
				if (sAppendFlag.equalsIgnoreCase("Y"))
				{
					FirstRowNum = resultSheet.getLastRowNum()+ 1;
				}
				HSSFRow resultRow = resultSheet.createRow((short) FirstRowNum);
				for (int RowNum=0;RowNum<finalStatusArr.length;RowNum++)
				{
					resultRow = resultSheet.createRow((short) FirstRowNum+RowNum);
					String[] ArrColumnData;
					ArrColumnData = finalStatusArr[RowNum].split("@#@");
					for (int ColNum=0, newColNo = 0;ColNum<ArrColumnData.length;ColNum++)
					{
						if(!skipCol.contains(ColNum))
							resultRow.createCell(newColNo++).setCellValue(ArrColumnData[ColNum]);
					}
				}

				try
				{
					FileOutputStream resultFileOut = new FileOutputStream(sFilePath);
					resultWorkBook.write(resultFileOut);
					resultFileOut.close();

				}
				catch (Exception err)
				{
					logger.error("Exception::"+err.getCause().toString());
					testCaseExecutionResult.setMessage(err.getCause().toString());
					return testCaseExecutionResult;
				}

				testCaseExecutionResult.setStatus(PASS);
				testCaseExecutionResult.setValid(true);
				return testCaseExecutionResult;

			} 
			catch (Exception e) 
			{
				logger.error("Exception::"+e.getCause().toString());
				testCaseExecutionResult.setMessage(e.getCause().toString());
				return testCaseExecutionResult;
			}
		}
		catch (Exception e1)
		{
			logger.error("Exception::"+e1.getCause().toString());
			testCaseExecutionResult.setMessage(e1.getCause().toString());
			return testCaseExecutionResult;
		}		
	}
	@Override

/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters
	 *            - sTableId -sFilePath -sSheetName-sAppendFlag -sFileName-skipCols
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */

	public TestcaseExecutionResultVO validateKeyword( String... listOfParameters) {


		// check for required parameter 
		if (listOfParameters != null) {
			sTableId=listOfParameters[0];
			sFilePath = listOfParameters[1];
			sSheetName = listOfParameters[2];
			sAppendFlag = listOfParameters[3];
			sFileName = listOfParameters[4];
			skipCols = listOfParameters[5]; 
		} else {
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setTestData(sTableId+DELIMITER+sFilePath+DELIMITER+ sSheetName +DELIMITER+ sAppendFlag +DELIMITER+ sFileName +DELIMITER+skipCols);

		if (KeywordUtilities.isEmptyString(sTableId))
		{
			logger.error (ERROR_TABLE_PARA_NOT_PASSED);
			testCaseExecutionResult.setMessage(ERROR_TABLE_PARA_NOT_PASSED);
			return testCaseExecutionResult;
		}

		if (KeywordUtilities.isEmptyString(sFilePath))
		{
			logger.error (ERROR_FILE_PATH_NOT_PASSED);
			testCaseExecutionResult.setMessage(ERROR_FILE_PATH_NOT_PASSED);
			return testCaseExecutionResult;
		}

		if (KeywordUtilities.isEmptyString(sFileName)){
			logger.error (FILE_NAME_NOT_PASSED);
			testCaseExecutionResult.setMessage(FILE_NAME_NOT_PASSED);
			return testCaseExecutionResult;
		}

		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;

	}
	@Override


/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(	String... listOfParameters){	

		if (webDriver == null) {
			logger.error(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);	
			return testCaseExecutionResult;
		}

		if (sTableId != null && sTableId.startsWith(OBJECT_SPECIFIER)) {
			sTableId = sTableId.substring(OBJECT_SPECIFIER.length(),sTableId.length());

			if(!KeywordUtilities.waitForElementPresent(configurationMap,webDriver,sTableId, userName))
			{
				logger.error(ERROR_TABLE_NOT_FOUND);
				testCaseExecutionResult.setMessage(ERROR_TABLE_NOT_FOUND);
				testCaseExecutionResult.setValid(false);
				return testCaseExecutionResult;
			}

			/*			
			if(sTableId.toLowerCase().contains("sgid=") && !sTableId.toUpperCase().contains("XPATH="))
			{
				sTableId="xpath=//table[@'"+sTableId+"']";
			}


			if(sTableId.toUpperCase().startsWith("XPATH="))
			{
				sTableId=KeywordUtilities.formXpath(sTableId);
				if(isValidationRequired() && !KeywordUtilities.waitForElementPresent(configurationMap,webDriver,sTableId))
				{
					testcaseExecutionRes.setMessage(ERROR_TABLE_NOT_FOUND_XPATH);
					return testcaseExecutionRes;
				}
			}*/
		}
		testCaseExecutionResult.setObject(sTableId);
		testCaseExecutionResult.setValid(true);		
		return testCaseExecutionResult;
	}
}

