package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.EMPTY_STRING;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;
/**
 * This Keyword to verify the available values in list builder
 */
public class VerifyListBuilderValuesHTML5 extends AbstractKeyword{

	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());

	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();
	/**
	 * This is web element object
	 */
	private WebElement listBuilderElement=null;;
	private WebElement expectedListBox = null;	
	/**
	 * Values should be available in listbuilder box
	 */
	private String valueToverify = null;
	/**
	 * To find in left or right box of list builder
	 */
	private String ListBuilder =  "";
	/**
	 * Optional listbuilder locator for  left or right box
	 */
	private String listBox="";

	@Override
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO executeScript(String... params) {
		try{

			//String operationToPerform = params[1];								
			String []valuesToverify = valueToverify.split(";");				
			
			expectedListBox = listBuilderElement;
			
			boolean isIEDriver = false;			
			if(webDriver instanceof  InternetExplorerDriver){
				isIEDriver = true;
			}

			String NotAvailableOptionText = "";
			for(String valu :valuesToverify)
			{
				String script = "var b = arguments[0].getElementsByTagName(\"li\");" +
				"var eleList=\""+valu+"\";"+
				"for (var i=0; i<b.length; i++){" +
				"    if( b[i].innerText.toUpperCase()== eleList.toUpperCase()){" +
				"           return 'PASS';" +
				"     }" +
				" }" +				
				" return 'FAIL'; ";	
				
				if(!isIEDriver)
				{
					script = script.replaceAll("innerText", "textContent");
				}
				
				boolean found = false;
			
				String text ="";
				try{
					text = (String)(((JavascriptExecutor)webDriver).executeScript(script,expectedListBox));
				}catch(Exception e){logger.error("Exception::",e);}
				if(text.equalsIgnoreCase("pass")){
					found = true;
				}				
				
				if (!found)
				{
					NotAvailableOptionText = NotAvailableOptionText+valu+",";
				}							
			}

			

			if (!NotAvailableOptionText.isEmpty())
			{
				NotAvailableOptionText = NotAvailableOptionText.substring(0, NotAvailableOptionText.length()-1);
				logger.error("List Option "+ NotAvailableOptionText +" not found  in list box");
				testCaseExecutionResult.setMessage("List Option "+ NotAvailableOptionText +" not found  in list box");					
				return testCaseExecutionResult;
			}


		}catch(Exception e){
			logger.error("Error while verifing value from Listbuilder");
			testCaseExecutionResult.setMessage("Error while verifing value from Listbuilder");
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setStatus(PASS);
		return testCaseExecutionResult;
	}

/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters
	 *             valueToverify -listBox-ListBuilder
	 * 
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */

	public TestcaseExecutionResultVO validateKeyword(String... params) {
		if (params != null) 
		{
			valueToverify= params[0];
			listBox = params[1];
			ListBuilder=params[2];
		}
		else{
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setTestData(valueToverify+DELIMITER+listBox+DELIMITER+ListBuilder);
		if (EMPTY_STRING.equalsIgnoreCase(listBox) )
		{
			logger.error("parameters not correct : Param 2 (List Box Position)");
			testCaseExecutionResult.setMessage("parameters not correct : Param 2 (List Box Position)");
			return testCaseExecutionResult;
		}  

		if (EMPTY_STRING.equalsIgnoreCase(valueToverify) )
		{
			logger.error("parameters not correct : Param 1 (Value to verify)");
			testCaseExecutionResult.setMessage("parameters not correct : Param 1 (Value to verify)");
			return testCaseExecutionResult;
		}  

		if (!((listBox.equalsIgnoreCase("Right")||  listBox.equalsIgnoreCase("Left"))))
		{
			logger.error("parameters not correct : Param 2 (List Box Position should be Right or Left)");
			testCaseExecutionResult.setMessage("parameters not correct : Param 2 (List Box Position should be Right or Left)");
			return testCaseExecutionResult;
		} 

		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}


	/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... params) {		

		if (webDriver == null) {
			logger.error(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setObjectError(true);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}

		if (EMPTY_STRING.equalsIgnoreCase(ListBuilder)){
			if(listBox.equalsIgnoreCase("Left")){
				ListBuilder = "xpath=(//div[@class='sg-list-builder-left' or @class='fis-list-builder-left'])[position()=1]";
			}else if (listBox.equalsIgnoreCase("Right")){
				ListBuilder = "xpath=(//div[@class='sg-list-builder-right' or @class='fis-list-builder-right'])[position()=1]";
			}else{
				logger.error("correct operation not provided");
				testCaseExecutionResult.setMessage("correct operation not provided");
				return testCaseExecutionResult;
			}

		}
		else{		
			if (ListBuilder.startsWith(OBJECT_SPECIFIER)) {	
				ListBuilder = ListBuilder.substring(OBJECT_SPECIFIER.length(), ListBuilder.length());
			} }	

		listBuilderElement=KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, ListBuilder,"", userName);
		testCaseExecutionResult.setExpectedResultFlag(true);
		if (listBuilderElement==null){
			logger.error("List box not found");
			testCaseExecutionResult.setMessage("List box not found");
			testCaseExecutionResult.setObjectError(true);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}	

		testCaseExecutionResult.setObject(valueToverify);
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}		



}
