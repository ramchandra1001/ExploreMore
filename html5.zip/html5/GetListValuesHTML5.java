package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.EMPTY_STRING;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.business.keywords.hybrid.DataSheetUtility;
import com.sungard.ktt.exception.AutomationException;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;

/**
 * @author Dnyaneshwar.Daphal
 *This Keyword will get values from a drop down box
 */
public class GetListValuesHTML5 extends AbstractKeyword{
	
	
	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();
	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
	/**
	 * This is web element object
	 */
	private WebElement listObjectElement;
	/**
	 * To find drop down
	 */
	private String sList =  null;
	/**
	 *Enviroment variable to store value[optional] default value is - GetListValuesHTML5_Captured
	 */
	private String sEnvVariable = null;
	
	@Override
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO executeScript(String... params) {

		if(sEnvVariable.isEmpty())
		{
			sEnvVariable ="GetListValuesHTML5_Captured";
		}
		
		if(sEnvVariable.toUpperCase().startsWith("#ENV#")){
			sEnvVariable = sEnvVariable.substring(5, sEnvVariable.length())	;
			if(sEnvVariable.toUpperCase().endsWith("#ENV#")){
				sEnvVariable = sEnvVariable.substring(0, sEnvVariable.length()-5)	;
			}	
		}

		String sListName = "kendoDropDownList";

		//The below code is for getting the current selected frame and set document object at the top level
		//------------------------------------------------------------------------------------------------------
		try {webDriver.switchTo().defaultContent();} catch (Exception e2) {logger.error("Exception::", e2);}
		//------------------------------------------------------------------------------------------------------

		String sfinalStatus="FAIL";

		String sgetBrowser=EMPTY_STRING;
		try {
			sgetBrowser = ((JavascriptExecutor)webDriver).executeScript("return navigator.userAgent").toString();
		} catch (Exception e1) {
			sgetBrowser=EMPTY_STRING;
		}

		String mySelector=
			"f(arguments[0]);																								" +
			"function f(ELE)																						" + 
			"{																									" +
			"	var svalueToSelect = \"\";													" +
			"	var listName = \""+sListName+ "\";																" + 
			"	try																								" +
			"	{																								" +
			"		var mObj = ELE;													" +
			"		var mkobj = $(mObj);																		" +
			"		var listDataObject = mkobj.data(listName);													" +
			"		var allItems = listDataObject.items();														" +
			"		for(dsd=0;dsd<allItems.length;dsd++)														" +
			"		{																							" +
			"			if(dsd==0)" +
			"			{" +
			"				svalueToSelect = allItems[dsd].innerText; " +
			"			}" +
			"			else" +
			"			{" +
			"				svalueToSelect = svalueToSelect+\";\"+allItems[dsd].innerText; " +
			"			}" +
					
			"		}																							" +
			"	}																								" +
			"	catch(e)																						" +
			"	{																								" +
			"		svalueToSelect='FAIL'+ e.description;																" +
			"	}																								" +
			"	return svalueToSelect;																					" +
			"}" ;

		sfinalStatus="FAIL";

		if(sgetBrowser.contains("Firefox")) 
		{
			mySelector=mySelector.replaceAll("innerText", "textContent");
		}

		try {
			sfinalStatus =((JavascriptExecutor)webDriver).executeScript("return "+mySelector,listObjectElement).toString();
		} catch (Exception e) {

			sfinalStatus="FAIL";
		}
		
		if(sfinalStatus.contains("FAIL"))
		{
			logger.error(sfinalStatus.replaceAll("FAIL", ""));
			testCaseExecutionResult.setMessage(sfinalStatus.replaceAll("FAIL", ""));
			return testCaseExecutionResult;
		}
		else
		{
			/*configurationMap.put(sEnvVariable, sfinalStatus);
			testCaseExecutionResult.setConfigUpdate(true);
			testCaseExecutionResult.setStatus(1);
			return testCaseExecutionResult;*/
			String sWorkSheet=params[9];
			String sColumnName = params[10];
			String sRow = params[11];
			if(KeywordUtilities.isEmptyString(sWorkSheet)){
				configurationMap.put(sEnvVariable, sfinalStatus);
				testCaseExecutionResult.setConfigUpdate(true);
			}else {
				if(sEnvVariable.toUpperCase().startsWith("#COL#")){
					sColumnName = sEnvVariable.substring(5, sEnvVariable.length())	;
					if(sColumnName.toUpperCase().endsWith("#COL#")){
						sColumnName = sColumnName.substring(0, sColumnName.length()-5)	;
					}				
					try{
						DataSheetUtility.setValueFromGlobalMap(workBookMap, sWorkSheet, sColumnName, sRow, sfinalStatus);
						testCaseExecutionResult.setWorkBookMap(workBookMap);
						testCaseExecutionResult.setTestDataUpdate(true);
					}catch (AutomationException e){
						logger.error("Automation Exception::"+e.getCause().toString());
						testCaseExecutionResult.setMessage(e.getCause().toString());
						return testCaseExecutionResult;
					}
				}else{
					configurationMap.put(sEnvVariable, sfinalStatus);
					testCaseExecutionResult.setConfigUpdate(true);						
				}
				
			}
			testCaseExecutionResult.setStatus(1);
			return testCaseExecutionResult;
			
		}

	}

	@Override

/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters
	 *            - sList -sEnvVariable
	 * 
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateKeyword(String... params) {

		if(params!=null)
		{
			sList=params[0];
			sEnvVariable=params[1];
		}
		else
		{
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setTestData(params[0]+DELIMITER+params[1]);
		if("".equals(params[0]))
		{
			logger.error("list box locator not given");
			testCaseExecutionResult.setMessage("list box locator not given");
			return testCaseExecutionResult;
		}
		
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}

	@Override

/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... params) {

		if (webDriver == null) {
			logger.error(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}

		if (sList.startsWith(OBJECT_SPECIFIER)) {
			sList = sList.substring(OBJECT_SPECIFIER.length(), sList.length());
		} 

		listObjectElement=KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, sList,"", userName);

		if (listObjectElement==null) {
			logger.error("List box not found");
			testCaseExecutionResult.setMessage("List box not found");
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setObject(sList);
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}}
