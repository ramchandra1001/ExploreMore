package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.view.config.KTTGuiConstants.EMPTY_STRING;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS_STEP_STATUS;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;
/**
 * @ author  Gyaneshwar.Nandanwar on 18-Nov-2013
 * This keyword selects the specified node of a tree view element.
 */
public class SelectTreeViewItemHTML5 extends AbstractKeyword 
{
	TestcaseExecutionResultVO testcaseExecutionRes = new TestcaseExecutionResultVO();
	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	private Logger logger = Logger.getLogger(SelectTreeViewItemHTML5.class.getName());	
	/**
	 * This is web element object
	 */
	private WebElement elementTreeView, kendoElementTreeView;
	/**
	 * Locator -To find Treeview
	 */
	private String sTreeViewLocator = null;
	/**
	 * Name of the tree view items to select, 
	 * separated by pipe (|)
	 */
	private String sTreeViewItems = null;	

	@Override
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO executeScript(String... listOfParameters)
	{
		try {
			elementTreeView=KeywordUtilities.getWebElement(webDriver, sTreeViewLocator);
		} catch (Exception e) {
			logger.error("Unable to find Locator: "+ sTreeViewLocator);
			testcaseExecutionRes.setMessage("Unable to find Locator: "+ sTreeViewLocator);
		}		

		try {
			kendoElementTreeView=KeywordUtilitiesHTML5.kendoDataControlBackward(webDriver, elementTreeView, "treeview");
		} catch (Exception e) {
			logger.error("Unable to find kendo Treeview Locator");
			testcaseExecutionRes.setMessage("Unable to find kendo Treeview Locator");
			return testcaseExecutionRes;
		}

		String getTreeViewItemToSelect =
				"	  return kendoDataControl(arguments[0]);																			"+			
						"	  function kendoDataControl(TreeView_Obj)																			"+
						"	  {																							            			"+
						"		try																												"+
						"		{																												"+		
						" 		var treeview=$(TreeView_Obj).data('kendoTreeView');																"+
						"	   	var treeviewItems=\""+sTreeViewItems+"\";																		"+
						"		var SplitedtTeeviewItem=treeviewItems.split('|');																"+
						"		var SplitedtTeeviewItemLength=SplitedtTeeviewItem.length;														"+
						"		var LastChildItem= SplitedtTeeviewItem[SplitedtTeeviewItemLength-1];											"+
						"		var childItems=treeview.findByText(LastChildItem);																"+
						"		var str='';																										"+
						"		var newItemArr = new Array();																					"+
						"		for (var k=0;k<childItems.length;k++)																			"+		
						"		{																												"+
						"			for (var l=0;l<10;l++)																						"+		
						"			{																											"+
						"				if(l==0)																								"+
						"				{																										"+
						"					var newItem=childItems[k];																			"+
						"					str = treeview.text(newItem);																		"+
						"				}																										"+
						"				else																									"+
						"				{																										"+		
						"					newItem=treeview.parent(newItem);																	"+		
						"					if (newItem.length==0)																				"+
						"					{																									"+
						"						break;																							"+
						"					}																									"+
						"					str = str+'|'+treeview.text(newItem);																"+
						"				}																										"+	
						"			newItemArr[l]=newItem;																						"+
						"			}																											"+
						"			var strArr=str.split('|');																					"+
						"			strArr.reverse();																							"+
						"			for (var m=0;m<strArr.length;m++)																			"+
						"			{																											"+
						"				if (m==0)																								"+
						"					str1=strArr[m];																						"+
						"				else																									"+
						"					str1=str1+'|'+strArr[m]																				"+
						"			}																											"+
						"			if (str1.indexOf(treeviewItems)!=-1)																		"+
						"			{																											"+
						"				newItemArr.reverse();																					"+
						"				for (var n=0;n<newItemArr.length-1;n++)																	"+
						"				{																										"+
						"					treeview.expand(newItemArr[n]);																		"+
						"				}																										"+
						"				var item_obj=null;"+
						"				if ($($(newItemArr[newItemArr.length-1]).find('div').find('span.k-checkbox-wrapper')[0]).length)				"+		
						"					 item_obj=$(newItemArr[newItemArr.length-1]).find('div').find('span.k-checkbox-wrapper').find('input[type=checkbox]')[0];"+
						"				else{																									"+
						
						"						 item_obj=$(newItemArr[newItemArr.length-1]).find('div').find('span.k-in').find('span.sg-tree-node')[0];"+
						"						if(!item_obj){"+
						
						"								 item_obj=$(newItemArr[newItemArr.length-1]).find('div').find('span.k-in').find('span.fis-tree-node')[0];"+
						"						}"+
						"					"+
						"				}"+
						"				item_obj.click();																						"+
						"				return \""+PASS_STEP_STATUS+"\";																		"+
						"			}																											"+
						"	}																													"+
						"		}catch(error)																									"+
						"		{																												"+
						"			return (error.description);																					"+			
						"		}																												"+
						"	  }";
		String WtreeViewItem =EMPTY_STRING;	
		try{
			WtreeViewItem = (String)((JavascriptExecutor)webDriver).executeScript(getTreeViewItemToSelect.toString(), kendoElementTreeView);			
		}catch(Exception e){
			logger.error(e.getCause().toString());
			WtreeViewItem=EMPTY_STRING;
		}
		if (WtreeViewItem==null){
			WtreeViewItem=EMPTY_STRING;
		}
		if (WtreeViewItem.equals(PASS_STEP_STATUS))
		{
			testcaseExecutionRes.setStatus(PASS);
			return testcaseExecutionRes;
		} else
		{
			logger.error("Treeview item not found.");
			testcaseExecutionRes.setMessage("Treeview item not found.");
			return testcaseExecutionRes;
		}		
	}

	@Override

	/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters listOfParameters[0]
	 *              (Mandatory) - sTreeViewLocator -sTreeViewItems 
	 * 
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateKeyword(String... listOfParameters)
	{
		if (listOfParameters != null)
		{
			sTreeViewLocator = listOfParameters[0];
			sTreeViewItems = listOfParameters[1];

		} else
		{
			// Insufficient Parameters
			logger.error ("Insufficient Parameters!");
			testcaseExecutionRes.setMessage(ERROR_PARAMETERS_LIST);
			return testcaseExecutionRes;
		}


		testcaseExecutionRes.setTestData("TreeView items : " + sTreeViewItems  +"sTreeViewItems :" +sTreeViewItems);

		if (KeywordUtilities.isEmptyString(sTreeViewLocator))
		{
			logger.error("Treeview locator not passed");
			testcaseExecutionRes.setMessage("Treeview locator not passed");
			return testcaseExecutionRes;
		}
		if (KeywordUtilities.isEmptyString(sTreeViewItems))
		{
			logger.error("Treeview Item to select not passed");
			testcaseExecutionRes.setMessage("Treeview Item to select not passed");
			return testcaseExecutionRes;
		}

		testcaseExecutionRes.setValid(true);
		return testcaseExecutionRes;

	}

	@Override

	/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... listOfParameters)
	{
		if (webDriver == null)
		{
			// Browser not instantiated
			logger.error(ERROR_BROWSER_NOT_INSTANTIATED);
			testcaseExecutionRes.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testcaseExecutionRes.setValid(false);
			return testcaseExecutionRes;
		}

		if (sTreeViewLocator.startsWith(OBJECT_SPECIFIER))
		{
			sTreeViewLocator = sTreeViewLocator.substring(OBJECT_SPECIFIER.length(),sTreeViewLocator.length());

			//sgid is there but xpath is not there so let prepare it
			if(sTreeViewLocator.toLowerCase().contains("sgid=") && !sTreeViewLocator.toUpperCase().contains("XPATH="))
			{
				sTreeViewLocator="xpath=//div[@'"+sTreeViewLocator+"']";
			}


			sTreeViewLocator = KeywordUtilities.formXpath(sTreeViewLocator);
			if (!KeywordUtilities.waitForElementPresent(configurationMap,webDriver,sTreeViewLocator, userName))
			{
				logger.error("Treeview Locator not found");
				testcaseExecutionRes.setMessage("Treeview Locator not found");
				testcaseExecutionRes.setValid(false);
				return testcaseExecutionRes;
			}			

		}
		testcaseExecutionRes.setObject(sTreeViewLocator);
		testcaseExecutionRes.setValid(true);
		return testcaseExecutionRes;
	}
}
