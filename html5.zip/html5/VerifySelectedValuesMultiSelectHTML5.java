
package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.EMPTY_STRING;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;
/**
 * This Keyword will verify selected values in multiselect control
 */
public class VerifySelectedValuesMultiSelectHTML5 extends AbstractKeyword {
	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();
	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
	/**
	 * This is web element
	 */
	private WebElement listObjectElement;
	/**
	 * Multiselect Object Locator
	 */
	private String sList =  null;	

	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO executeScript(String... params) {

		try{
			boolean checkForEmptyValue = false;
			String []SvalueToSelect = params[1].split(";");
			if (params[1].equalsIgnoreCase("EMPTY") || SvalueToSelect[0].equalsIgnoreCase("EMPTY"))
			{
				checkForEmptyValue = true;
			}
			List <WebElement> optionElements = new ArrayList <WebElement>();
			List <String> requiredOptionText = new ArrayList <String>();
			String val ="";		
			String sfinalStatus="FAIL";                       
			//String sFrameValue1 = configurationMap.get(FRAME_NAME_ENV);       


			String mySelector=
					"f(arguments[0]);                                                                                                                         " +
							"function f(ELE)                                                                                                                          " + 
							"{                                                                                                                                            " +
							"     var sMultiList = ELE;                                                                                                             " +
							"     var Result='FAIL';                                                                                                                        " +
							"     try                                                                                                                                             " +
							"     {                                                                                                                                               " +
							"           var mkobj = $(sMultiList); " +
							"           var avilableData = mkobj.data('kendoMultiSelect').value();" +
							"              Result= avilableData;"+
							"     }                                                                                                                                               " +
							"     catch(e1)                                                                                                                                  " +
							"     {                                                                                                                                               " +
							"           Result='FAIL'+ e1.description;                                                                                           " +
							"     }                                                                                                                                               " +
							"     return Result;                                                                                                                            " +
							"}" ;

			String [] selectValueArry =null;

			try {
				sfinalStatus =((JavascriptExecutor)webDriver).executeScript("return "+mySelector,listObjectElement).toString();                  
				Thread.sleep(2000);
			} catch (Exception e2) {
				sfinalStatus="FAIL";
				logger.error("Error while setting value");
				testCaseExecutionResult.setMessage("Error while setting value");
				return testCaseExecutionResult;
			}	

			if (!sfinalStatus.contains("FAIL"))
			{
				sfinalStatus = sfinalStatus.substring(1, sfinalStatus.length()-1);
				if(checkForEmptyValue)
				{
					if(EMPTY_STRING.equalsIgnoreCase(sfinalStatus)){
						testCaseExecutionResult.setStatus(PASS);	            
						return testCaseExecutionResult;
					}else
					{
						logger.error("MultiSelect is not empty");
						testCaseExecutionResult.setMessage("MultiSelect is not empty");
						return testCaseExecutionResult;
					}
				}
				if (!EMPTY_STRING.equalsIgnoreCase(sfinalStatus))
				{
					selectValueArry = sfinalStatus.split(",");
				}
			}else{
				logger.error("Error While getting selected value");
				testCaseExecutionResult.setMessage("Error While getting selected value");
				return testCaseExecutionResult;
			}

			if (listObjectElement != null)
			{
				optionElements = listObjectElement.findElements(By.tagName("OPTION"));
			}
			else
			{
				logger.error("list object not found");
				testCaseExecutionResult.setMessage("list object not found");
				return testCaseExecutionResult;
			}

			if (selectValueArry != null)
			{
				for (String valueToSelect :selectValueArry)
				{
					for(WebElement option :optionElements)
					{
						String text = "";
						try{
							text =((JavascriptExecutor)webDriver).executeScript(" var a= '';try{a=arguments[0].value;}catch(e1){}return a; ",option).toString();
						}catch (Exception e1)
						{
							logger.error("Exception::",e1);
						}

						if(valueToSelect.trim().equalsIgnoreCase(text.trim()))
						{							
							val =option.getAttribute("text");
							requiredOptionText.add(val);
							break;
						}
					}					
				}
				if (requiredOptionText.size()<=0)
				{
					logger.error("Error getting selected value" );
					testCaseExecutionResult.setMessage("Error getting selected value");
					return testCaseExecutionResult;
				}
			}
			else
			{
				logger.error("No value found in List" );
				testCaseExecutionResult.setMessage("No value found in List");
				return testCaseExecutionResult;
			}

			String valueNotFound ="";
			for(String selVal :SvalueToSelect)
			{
				if(!requiredOptionText.contains(selVal))
				{
					valueNotFound = valueNotFound + selVal +",";
				}
			}

			if(!EMPTY_STRING.equalsIgnoreCase(valueNotFound)){
				logger.error("values " +valueNotFound+" not selected" );
				testCaseExecutionResult.setMessage("values " +valueNotFound+" not selected" );
				return testCaseExecutionResult;
			}

			testCaseExecutionResult.setStatus(PASS);	            
			return testCaseExecutionResult;
		}catch(Exception e1)
		{
			logger.error("Exception::",e1);
			testCaseExecutionResult.setMessage(e1.toString() );
			return testCaseExecutionResult;
		}
		//return testCaseExecutionResult;
	}


	/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters
	 *            - sList-
	 * 
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */

	public TestcaseExecutionResultVO validateKeyword(String... params) {
		if(params!=null){

			sList=params[0];
		}
		else{
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setTestData(params[0]+DELIMITER+params[1]);
		if("".equals(params[0]))
		{
			logger.error("list box locator not given");
			testCaseExecutionResult.setMessage("list box locator not given");
			return testCaseExecutionResult;
		}

		/*if("".equals(params[1]))
		{
			logger.error("options not given");
			testCaseExecutionResult.setMessage("options not given");
			return testCaseExecutionResult;
		}*/

		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}

	/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... params) {
		if (webDriver == null) {
			logger.error(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}	

		if (sList.startsWith(OBJECT_SPECIFIER)) {	
			sList = sList.substring(OBJECT_SPECIFIER.length(), sList.length());
		}			
		listObjectElement=KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, sList,"", userName);
		if (listObjectElement==null){
			logger.error("List box not found");
			testCaseExecutionResult.setObjectError(true);
			testCaseExecutionResult.setMessage("List box not found");
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}

		testCaseExecutionResult.setExpectedResultFlag(true);
		testCaseExecutionResult.setObject(sList);
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}

}
