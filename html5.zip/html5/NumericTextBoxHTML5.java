package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.EMPTY_STRING;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;

/**
 * @author Ashish Joshi
 * Created for Script_1499 Under SAFAL 8.0.0, patch release 1
 * @creation date 30 Oct 2012
 * Parameters:
 *			sLocator = 	listOfParameters[0]; (Optional ,Locator of DatePicker Object, default: xpath=//span[@class='k-icon k-i-calendar'] )
 *			Value = 	listOfParameters[1]; (Mandatory ,Day to select from the DatePicker Control)
 */
/**Following screen shot shows a Numeric Text Box Control to be automated.
 * @author Ashish.Joshi
 *This Keyword will set value to Numeric Text box control.
 */

public class NumericTextBoxHTML5 extends AbstractKeyword{


	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();	
	/**
	 * This is a webelement
	 */
	WebElement numericTextBox = null;  
	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
	/**
	 * Value to Enter
	 */
	String sValueToEnter = null;
	/**
	 * The Button field locator 
	 */
	String sLocator = null;
	/**
	 * Instance of the Object Locator, Default BLANK=1
	 */
	String sLocator_Instance = null;

	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */

	@Override
	public TestcaseExecutionResultVO executeScript(String... listOfParameters) {
		String mySelector=
				"f(arguments[0]);                                                                                                                         " +
						"function f(ELE)                                                                                                                          " + 
						"{                                                                                                                                            " +
						"     var sNTBLocator = ELE;                                                                                                             " +
						"     var svalueToSelect = \""+sValueToEnter+ "\";                                                                           " +
						"     var Result='FAIL';                                                                                                                        " +
						"     try                                                                                                                                             " +
						"     {                                                                                                                                               " +
						"			var numerictextbox=$(sNTBLocator).data('kendoNumericTextBox');" +
						
						"             numerictextbox.focus();"+
						"			numerictextbox.value(svalueToSelect);" +
						//"			alert(numerictextbox.value());" +
						"			numerictextbox.trigger('spin');" +
						"			numerictextbox.trigger('change');" +
						"			Result= 'PASS';" +
						"     }                                                                                                                                               " +
						"     catch(e)                                                                                                                                  " +
						"     {                                                                                                                                               " +
						"           Result='FAIL '+ e.description;                                                                                           " +
						"     }                                                                                                                                               " +
						"     return Result;                                                                                                                            " +
						"}" ;

		String sfinalStatus="FAIL";

		try 
		{
			//numericTextBox.sendKeys(Keys.BACK_SPACE);
			sfinalStatus =((JavascriptExecutor)webDriver).executeScript("return "+mySelector,numericTextBox).toString();                  
		} catch (Exception e1) 
		{
			logger.error("Error while setting the value");
			testCaseExecutionResult.setMessage("Error while setting the value");
			testCaseExecutionResult.setStatus(0);
			return testCaseExecutionResult;
		}
		
		if(sfinalStatus.equalsIgnoreCase("PASS"))
		{
			testCaseExecutionResult.setStatus(PASS);
		}
		else
		{
			logger.error("Unable to set the value '"+sValueToEnter+"' in the Numeric Text Box. "+ sLocator);
			testCaseExecutionResult.setMessage("Unable to set the value '"+sValueToEnter+"' in the Numeric Text Box. "+ sLocator);
		}
		return testCaseExecutionResult;
	}


	@Override

/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters 
	 *              (Mandatory) - sLocator -sValueToEnter-sLocator_Instance
	 * 
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */

	public TestcaseExecutionResultVO validateKeyword(String... listOfParameters) {
		if (listOfParameters != null) 
		{
			sLocator=listOfParameters[0];
			sValueToEnter = listOfParameters[1];
			sLocator_Instance=listOfParameters[2];

		} else {
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}	

		testCaseExecutionResult.setTestData(sLocator+DELIMITER+sValueToEnter+DELIMITER+sLocator_Instance);

		if(KeywordUtilities.isEmptyString(sLocator))
		{
			logger.error("Numeric Text Box Locator not passed");
			testCaseExecutionResult.setMessage("Numeric Text Box Locator not passed");
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;				
	}

	@Override
	/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... listOfParameters) {
		if(EMPTY_STRING.equals(sLocator_Instance))
		{
			sLocator_Instance="1";
		}

		if (sLocator.startsWith(OBJECT_SPECIFIER)) {
			sLocator = sLocator.substring(OBJECT_SPECIFIER.length(), sLocator.length());}

		if (webDriver == null) {
			logger.error(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}

		testCaseExecutionResult.setExpectedResultFlag(true);
		numericTextBox =KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, sLocator,sLocator_Instance, userName);
		if(numericTextBox==null)
		{
			logger.error("NumericText Box object not Found");
			testCaseExecutionResult.setMessage("NumericText Box object not Found");
			testCaseExecutionResult.setValid(false);
			testCaseExecutionResult.setObjectError(true); 
			return testCaseExecutionResult; 
		}


		testCaseExecutionResult.setValid(true);
		testCaseExecutionResult.setObject(sLocator);
		return testCaseExecutionResult;
	}

}
