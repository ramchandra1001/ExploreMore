package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.EMPTY_STRING;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.util.TimeWatcher;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;
import com.sungard.ktt.view.config.KTTGuiConstants.ScriptStatus;
import com.sungard.ktt.web.util.SAFALUserSession;
/**
 * @author Dnyaneshwar.Daphal
 *This Keyword will verify value is available for drop down options
 */
public class VerifyListValuesHTML5 extends AbstractKeyword{
	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();
	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
	/**
	 * This is web element object
	 */
	private WebElement listObjectElement;
	/**
	 * To find drop down
	 */
	private String sList =  null;
	/**
	 * Value to be selected
	 */
	private String sValuestoVerify = null;
	
	private String timeout = null;
	   
	/*@Override
	public TestcaseExecutionResultVO executeScript(String... params) {

		TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();

		String sValuestoVerify = params[1];

		String sListName = "kendoDropDownList";

		String myId="DSDID"+(int)(Math.random()*200);

		String orgID="";
		try
		{
			orgID = listObjectElement.getAttribute("id");
		}
		catch (Exception e2){orgID=KTTGuiConstants.EMPTY_STRING;}

		try {
			((JavascriptExecutor)webDriver).executeScript("arguments[0].id=arguments[1]", listObjectElement,myId);
		} catch (Exception e) {
			testCaseExecutionResult.setMessage("Not able to assign id. SelectWebTableRow");
			return testCaseExecutionResult;
		}

		//The below code is for getting the current selected frame and set document object at the top level
		//------------------------------------------------------------------------------------------------------
		String sFrameValue =configurationMap.get(FRAME_NAME_ENV);
		try {webDriver.switchTo().defaultContent();} catch (Exception e2) {}
		//------------------------------------------------------------------------------------------------------

		String sfinalStatus="FAIL";

		String sgetBrowser=EMPTY_STRING;
		try {
			//sgetBrowser = webDriver.getEval("navigator.userAgent");
			sgetBrowser = ((JavascriptExecutor)webDriver).executeScript("return navigator.userAgent").toString();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			sgetBrowser=EMPTY_STRING;
		}


		String mySelector=
			"f();																								" +
			"function f()																						" + 
			"{																									" +
			KeywordUtilities.getDocumentObject(sFrameValue)													  + 
			"	var sListLocator = \""+ myId+ "\";																" +
			"	var svalueToSelect = \""+sValuestoVerify+ "\";													" +
			"      var SplitedData=svalueToSelect.split(\";\");																						"+
			"	var currentValue = \"\";	" +
			"	var listName = \""+sListName+ "\";																" + 
			"	var Result='FAIL';																				" +
			"	try																								" +
			"	{																								" +
			"		var mObj = fd.getElementById(sListLocator);													" +
			"		var mkobj = $(mObj);																		" +
			"		var listDataObject = mkobj.data(listName);													" +
			"		var allItems = listDataObject.items();														" +
			"		for(dsd1=0;dsd1<SplitedData.length;dsd1++)														" +
			"		{	" +
			"			currentValue = SplitedData[dsd1];" +
			"			for(dsd=0;dsd<allItems.length;dsd++)														" +
			"			{																							" +
			"				if(allItems[dsd].innerText.indexOf(currentValue)==0)							" +
			"				{	" +
			"					break;" +
			"				}	" +
			"			}	" +
			"			if(dsd==allItems.length)		" +
			"			{" +
			"				return 'FAIL '+currentValue+' Value not found in List';" +
			"			}																						" +
			"		}" +
			"		if(dsd1==SplitedData.length)																					" +
			"		{																							" +
			"			   		return \"PASS\";																    " +
			"		}																							" +
			"		else																						" +
			"		{																							" +
			"				return \"FAIL Value not found in List\"; 										" +
			"		}																							" +
			"	}																								" +
			"	catch(e)																						" +
			"	{																								" +
			"		Result='FAIL'+ e.description;																" +
			"	}																								" +
			"	return Result;																					" +
			"}" ;

		sfinalStatus="FAIL";

		if(sgetBrowser.contains("Firefox")) 
		{
			mySelector=mySelector.replaceAll("innerText", "textContent");
		}

		try {
			sfinalStatus =((JavascriptExecutor)webDriver).executeScript("return "+mySelector).toString();
		} catch (Exception e) {

			sfinalStatus="FAIL";
		}
		try
		{
			((JavascriptExecutor)webDriver).executeScript("arguments[0].id=arguments[1]", listObjectElement,orgID);
		}catch (Exception e1){

		}

		if(sfinalStatus.equalsIgnoreCase("PASS"))
		{
			testCaseExecutionResult.setStatus(1);
			return testCaseExecutionResult;
		}
		else
		{
			testCaseExecutionResult.setMessage(sfinalStatus.replaceAll("FAIL", ""));
			return testCaseExecutionResult;
		}

	}
*/
	
	@Override
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO executeScript(String... params) {
		
		String sListName = "kendoDropDownList";
		if(timeout.equalsIgnoreCase("")){
			timeout = configurationMap.get("ObjectWaitTime");
		}
		int timeOut = 120;
		try{timeOut = Integer.parseInt(timeout);}catch(Exception e){logger.error("Exception::",e);}
		
				
		//The below code is for getting the current selected frame and set document object at the top level
		
		//------------------------------------------------------------------------------------------------------
			
		String sfinalStatus= "FAIL";		
		String mySelector=
				"f(arguments[0]);																					" +
				"function f(ELE)																					" + 
				"{																									" +
				"	var svalueToSelect = \""+sValuestoVerify+ "\";													" +
				"   var SplitedData=svalueToSelect.split(\";\");													" +
				"	var currentValue = \"\";	                                                                    " +
				"	var listName = \""+sListName+ "\";																" + 
				"	var Result='FAIL';																				" +
				"	try																								" +
				"	{																								" +
				"		var mObj = ELE;													                            " +
				"		var mkobj = $(mObj);																		" +
				"		var listDataObject = mkobj.data(listName);													" +
				"		var allItems = listDataObject.items();														" +
				"		for(dsd1=0;dsd1<SplitedData.length;dsd1++)													" +
				"		{	                                                                                        " +
				"			currentValue = SplitedData[dsd1];                                                       " +
				"			for(dsd=0;dsd<allItems.length;dsd++)													" +
				"			{																						" +
				"				if(allItems[dsd].innerText.indexOf(currentValue)==0)							    " +
				"				{	                                                                                " +
				"					break;                                                                          " +
				"				}	                                                                                " +
				"			}	                                                                                    " +
				"			if(dsd==allItems.length)                                                        		" +
				"			{                                                                                       " +
				"				return 'FAIL '+currentValue+' Value not found in List';" +
				"			}																						" +
				"		}" +
				"		if(dsd1==SplitedData.length)																					" +
				"		{																							" +
				"			   		return \"PASS\";																    " +
				"		}																							" +
				"		else																						" +
				"		{																							" +
				"				return \"FAIL Value not found in List\"; 										" +
				"		}																							" +
				"	}																								" +
				"	catch(e)																						" +
				"	{																								" +
				"		Result='FAIL'+ e.description;																" +
				"	}																								" +
				"	return Result;																					" +
				"}" ;
		

//		String mySelector=
//			"f();																								" +
//			"function f()																						" + 
//			"{																									" +
//			KeywordUtilities.getDocumentObject(sFrameValue)													  + 
//			"	var sListLocator = \""+ myId+ "\";																" +
//			"	var svalueToSelect = \""+sValuestoVerify+ "\";													" +
//			"      var SplitedData=svalueToSelect.split(\";\");																						"+
//			"	var currentValue = \"\";	" +
//			"	var listName = \""+sListName+ "\";																" + 
//			"	var Result='FAIL';																				" +
//			"	try																								" +
//			"	{																								" +
//			"		var mObj = fd.getElementById(sListLocator);													" +
//			"		var mkobj = $(mObj);																		" +
//			"		var listDataObject = mkobj.data(listName);													" +
//			"		var allItems = listDataObject.items();														" +
//			"		for(dsd1=0;dsd1<SplitedData.length;dsd1++)														" +
//			"		{	" +
//			"			currentValue = SplitedData[dsd1];" +
//			"			for(dsd=0;dsd<allItems.length;dsd++)														" +
//			"			{																							" +
//			"				if(allItems[dsd].innerText.indexOf(currentValue)==0)							" +
//			"				{	" +
//			"					break;" +
//			"				}	" +
//			"			}	" +
//			"			if(dsd==allItems.length)		" +
//			"			{" +
//			"				return 'FAIL '+currentValue+' Value not found in List';" +
//			"			}																						" +
//			"		}" +
//			"		if(dsd1==SplitedData.length)																					" +
//			"		{																							" +
//			"			   		return \"PASS\";																    " +
//			"		}																							" +
//			"		else																						" +
//			"		{																							" +
//			"				return \"FAIL Value not found in List\"; 										" +
//			"		}																							" +
//			"	}																								" +
//			"	catch(e)																						" +
//			"	{																								" +
//			"		Result='FAIL'+ e.description;																" +
//			"	}																								" +
//			"	return Result;																					" +
//			"}" ;
		
		

		sfinalStatus="FAIL";
		String sgetBrowser=configurationMap.get("SAFAL_BROWSER_NAME");
		if(sgetBrowser==null){
			sgetBrowser=EMPTY_STRING;
		}
			
		if(sgetBrowser.contains("Firefox")){
			mySelector=mySelector.replaceAll("innerText", "textContent");
		}
		
		
		
		TimeWatcher timeWatcher = new TimeWatcher(timeOut);
		timeWatcher.startTimeWatcher();
		while(!timeWatcher.isTimeUp(userName))
		{
			sfinalStatus="FAIL";
			if(SAFALUserSession.getSciptStatus(userName) == ScriptStatus.TO_BE_STOPPED){		
				break;
			}
			
			try {
				sfinalStatus =((JavascriptExecutor)webDriver).executeScript("return "+mySelector,listObjectElement).toString();
			}catch (Exception e){
				sfinalStatus= "FAIL";
			}			
			if(sfinalStatus.equalsIgnoreCase("PASS"))
			{
				break;
			}
		}
		timeWatcher.cancel();
		
		if(sfinalStatus.equalsIgnoreCase("PASS")){
				testCaseExecutionResult.setStatus(1);
				return testCaseExecutionResult;	
		}else{
				logger.error(sfinalStatus.replaceAll("FAIL", ""));
				testCaseExecutionResult.setMessage(sfinalStatus.replaceAll("FAIL", ""));
				return testCaseExecutionResult;
		}

	}
	
	@Override

/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters
	 *             -sList -sValuestoVerify
	 * 
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */

	public TestcaseExecutionResultVO validateKeyword(String... params) {
		
		if(params!=null)
		{
			sList=params[0];
			sValuestoVerify=params[1];
			timeout=params[2];
		}
		else{
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setTestData(params[0]+DELIMITER+params[1]);
		if("".equals(params[0]))
		{
			logger.error("list box locator not given");
			testCaseExecutionResult.setMessage("list box locator not given");
			return testCaseExecutionResult;
		}
		
		if("".equals(params[1]))
		{
			logger.error("value to verify not given");
			testCaseExecutionResult.setMessage("value to verify not given");
			return testCaseExecutionResult;
		}
	
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}

	@Override
	/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... params) {

		if (webDriver == null) {
			logger.error(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}
		if (sList.startsWith(OBJECT_SPECIFIER)) {

			sList = sList.substring(OBJECT_SPECIFIER.length(), sList.length());
		} 
		listObjectElement=KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, sList,"", userName);

		if (listObjectElement==null) {
			testCaseExecutionResult.setObjectError(true);
			logger.error("List box not found");
			testCaseExecutionResult.setMessage("List box not found");
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}

		testCaseExecutionResult.setExpectedResultFlag(true);
		testCaseExecutionResult.setObject(sList);
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}}
