package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.EMPTY_STRING;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_WAIT_VARIABLE;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;
/**
 * This Keyword will select multiple values in multiselect control
 */
public class SelectValuesMultiSelectHTML5 extends AbstractKeyword {
	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();
	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());	
	/**
	 * This is webelement
	 */
	private WebElement listObjectElement=null;
	/**
	 * Multiselect Object Locator
	 */
	private String svalueToSelect = null;
	/**
	 * Value to be selected
	 */
	private String valueNotClearPerviousSelection = null;
	private String CheckForContainsinselectUsingSearch = null;
	
	private String listBoxLoctor = null;
	private String selectUsingSearch = null;

	@Override
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */

	public TestcaseExecutionResultVO executeScript(String... params) {
		
		if(selectUsingSearch.equalsIgnoreCase("Y")){
			
			if(CheckForContainsinselectUsingSearch.equalsIgnoreCase("y")||CheckForContainsinselectUsingSearch.equalsIgnoreCase("yes")||CheckForContainsinselectUsingSearch.equalsIgnoreCase("true"))
			{
				CheckForContainsinselectUsingSearch = "Y";
			}else{
				CheckForContainsinselectUsingSearch = "N";
			}
			
			String []SvalueToSelect = svalueToSelect.split(";");	
			List<String>valueNotFound=new ArrayList<String>();
			
			for(String value:SvalueToSelect){
			
				String sfinalStatus="FAIL";	                        
				String mySelector=
						"f(arguments[0]);                                                                                                                         " +
								"function f(ELE)                                                                                                                          " + 
								"{                                                                                                                                            " +
								"     var sMultiList = ELE;                                                                                                             " +
								"     var Result='FAIL';   " +
								"     var valueString =\""+ value+"\";"+
								"     try                                                                                                                                             " +
								"     {                                                                                                                                               " +
								"          var mkobj = $(sMultiList); " +
								"          var b= mkobj.data('kendoMultiSelect');"+
								"          b.search(valueString);b.open(); b.refresh();"+
								"          Result= 'PASS';"+
								"     }                                                                                                                                               " +
								"     catch(e1)                                                                                                                                  " +
								"     {                                                                                                                                               " +
								"           Result='FAIL'+ e1.description;                                                                                           " +
								"     }                                                                                                                                               " +
								"     return Result;                                                                                                                            " +
								"}" ;
	
				sfinalStatus="FAIL";
	
				try {
					sfinalStatus =((JavascriptExecutor)webDriver).executeScript("var a= "+mySelector+ "return a;",listObjectElement).toString();
				} catch (Exception e1) {
					sfinalStatus="FAIL";
					logger.error("Error while getting option: "+value);
					
				}	
				
				
				int toWait_ObjWait=120;
				try{
					String val = configurationMap.get(OBJECT_WAIT_VARIABLE);
					if(val!=null)
					{
						toWait_ObjWait =Integer.parseInt(val); 
					}
				}catch(Exception e){logger.debug("Failed to get 2OBJECT_WAIT_VARIABLE",e);}
				
				KeywordUtilities.waitForPageToLoad(webDriver, toWait_ObjWait, userName);
				
				
				sfinalStatus="FAIL";	                        
				mySelector=
						"f(arguments[0]);                                                                                                                         " +
								"function f(ELE)                                                                                                                          " + 
								"{                                                                                                                                            " +
								"     var sMultiList = ELE;                                                                                                             " +
								"     var Result='FAIL';   " +
								"     var valueString =\""+ value+"\";"+
								"     var CheckForContains =\""+ CheckForContainsinselectUsingSearch+"\";"+
								"     try                                                                                                                                             " +
								"     {                                                                                                                                               " +
								"          var mkobj = $(sMultiList); " +
								"          var b= mkobj.data('kendoMultiSelect');"+
								"          Result= 'FAIL';"+
								"          var d =  b.items();"+
								//"           alert(d.length);"+
								" 			for(i=0;i<d.length;i++){"+
								"            if(CheckForContains !='Y'){"+
								"        		if(d[i].innerText==valueString){$(d[i]).click(); Result= 'PASS';  break;}"+
								"            }else{"+
								//"              alert(d[i].innerText.includes(valueString));"+
								"              if(d[i].innerText.includes(valueString)){$(d[i]).click(); Result= 'PASS';  break;}"+
								"            }"+
								"          }"+
								"         "+
								"     }                                                                                                                                               " +
								"     catch(e1)                                                                                                                                  " +
								"     {                                                                                                                                               " +
								"           Result='FAIL'+ e1.description;                                                                                           " +
								"     }                                                                                                                                               " +
								"     return Result;                                                                                                                            " +
								"}" ;
	
				sfinalStatus="FAIL";
				
				try {
					sfinalStatus =((JavascriptExecutor)webDriver).executeScript("var a= "+mySelector+ "return a;",listObjectElement).toString();
				} catch (Exception e1) {
					sfinalStatus="FAIL";
					logger.error("Error not able to click option: "+value);
				}	
				
				if(sfinalStatus.contains("FAIL")){
					valueNotFound.add(value);
					continue;
				}
			
			}
			
			if(valueNotFound.size()>0){
				String expectedValues="";
				for(String valuenotavailable:valueNotFound){
					expectedValues = expectedValues + valuenotavailable + " ";
					}
				testCaseExecutionResult.setMessage("values not found: "+expectedValues);
					
			}else{
				testCaseExecutionResult.setStatus(1);
			}
		
		return testCaseExecutionResult;
		
		}else{
		try{
			String []SvalueToSelect = svalueToSelect.split(";");	
			//String HTMl5 = "Y";
			if(EMPTY_STRING.equalsIgnoreCase(valueNotClearPerviousSelection)||(!(valueNotClearPerviousSelection.equalsIgnoreCase("Y")||valueNotClearPerviousSelection.equalsIgnoreCase("Yes")||valueNotClearPerviousSelection.equalsIgnoreCase("TRUE"))) )
			{
				valueNotClearPerviousSelection = "N";
			}
			String valueString = "";
			String valueNotAvaliable ="";

			List <WebElement> optionElements = new ArrayList <WebElement>();
			List <String> requiredOptionValue = new ArrayList <String>();

			//////////////////
			if(!svalueToSelect.equalsIgnoreCase("EMPTY"))
			{
				if (listObjectElement != null)
				{
					optionElements = listObjectElement.findElements(By.tagName("OPTION"));
				}
				else
				{
					logger.error("list object not found");
					testCaseExecutionResult.setMessage("list object not found");
					return testCaseExecutionResult;
				}

				//System.out.println(optionElements.size());
				String val ="";
				if (optionElements.size()!=0)
				{
					for (String valueToSelect :SvalueToSelect)
					{
						boolean found = false;
						for(WebElement option :optionElements)
						{
							String text = option.getAttribute("text");
							if(valueToSelect.equalsIgnoreCase(text))
							{							
								found = true;
								val =option.getAttribute("value");
								requiredOptionValue.add(val);
								break;
							}
						}
						if(!found)
						{
							valueNotAvaliable = valueNotAvaliable + valueToSelect+ ",";	
						}
					}
				}
				else{
					logger.error("error while getting options");
					testCaseExecutionResult.setMessage("error while getting options");
					return testCaseExecutionResult;
				}	





				if((valueNotClearPerviousSelection.equalsIgnoreCase("Y")||valueNotClearPerviousSelection.equalsIgnoreCase("Yes")||valueNotClearPerviousSelection.equalsIgnoreCase("TRUE")))
				{
					String sfinalStatus_Empty="FAIL";	 
					String mySelector_Empty=
							"f(arguments[0]);                                                                                                                         " +
									"function f(ELE)                                                                                                                          " + 
									"{                                                                                                                                            " +
									"     var sMultiList = ELE;                                                                                                             " +
									"     var Result='FAIL';                                                                                                                        " +
									"     try                                                                                                                                             " +
									"     {                                                                                                                                               " +
									"           var mkobj = $(sMultiList); " +
									"           var selVal=  mkobj.data('kendoMultiSelect').value();" +
									"           Result= selVal;"+
									"     }                                                                                                                                               " +
									"     catch(e1)                                                                                                                                  " +
									"     {                                                                                                                                               " +
									"           Result='FAIL'+ e1.description;                                                                                           " +
									"     }                                                                                                                                               " +
									"     return Result;                                                                                                                            " +
									"}" ;

					sfinalStatus_Empty="FAIL";

					try {
						sfinalStatus_Empty =((JavascriptExecutor)webDriver).executeScript("return "+mySelector_Empty,listObjectElement).toString();                  
						Thread.sleep(2000);
					} catch (Exception e1) {
						sfinalStatus_Empty="FAIL";
						logger.error("Error while getting selected value from control");
						testCaseExecutionResult.setMessage("Error while getting selected value from control");
						return testCaseExecutionResult;
					}

					if(!sfinalStatus_Empty.toUpperCase().contains("FAIL"))
					{
						sfinalStatus_Empty =  sfinalStatus_Empty.substring(1, sfinalStatus_Empty.length()-1);
						String[] selectedValue = sfinalStatus_Empty.split(", ");
						for(String selVal :selectedValue){
							try{
								if(!requiredOptionValue.contains(selVal))
								{
									requiredOptionValue.add(selVal);
								}
							}catch(Exception e){logger.error("Exception::",e);}
						}
					}else{
						logger.error("Error while getting selected value from control");
						testCaseExecutionResult.setMessage("Error while getting selected value from control");
						return testCaseExecutionResult;

					}
				}


				for(int i= 0; i < requiredOptionValue.size(); i++)
				{
					if(i == requiredOptionValue.size()-1)
					{					valueString = valueString + "'"+ requiredOptionValue.get(i) + "' ";

					}else{
						valueString = valueString + "'"+ requiredOptionValue.get(i)+ "', ";					
					}
				}

			}else
			{
				valueString ="";
			}

			String sfinalStatus="FAIL";	                        
			String mySelector=
					"f(arguments[0]);                                                                                                                         " +
							"function f(ELE)                                                                                                                          " + 
							"{                                                                                                                                            " +
							"     var sMultiList = ELE;                                                                                                             " +
							"     var Result='FAIL';   " +
							"     var valueString =\""+ valueString+"\";"+
							"     try                                                                                                                                             " +
							"     {                                                                                                                                               " +
							"          var mkobj = $(sMultiList); " +
							//"          mkobj.data('kendoMultiSelect').dataSource.filter({}); "+
							//"          mkobj.data('kendoMultiSelect').value(\"\");" +
							"          mkobj.data('kendoMultiSelect').refresh();"+
							"          mkobj.data('kendoMultiSelect').value(["+valueString+"]);" +
							"			 mkobj.data('kendoMultiSelect').trigger('change');	" +
							"          Result= 'PASS';"+
							"     }                                                                                                                                               " +
							"     catch(e1)                                                                                                                                  " +
							"     {                                                                                                                                               " +
							"           Result='FAIL'+ e1.description;                                                                                           " +
							"     }                                                                                                                                               " +
							"     return Result;                                                                                                                            " +
							"}" ;

			sfinalStatus="FAIL";

			try {
				sfinalStatus =((JavascriptExecutor)webDriver).executeScript("var a= "+mySelector+ "return a;",listObjectElement).toString();
				//sfinalStatus =((JavascriptExecutor)webDriver).executeScript("var a= "+mySelector,listObjectElement).toString();                  
				Thread.sleep(2000);
			} catch (Exception e1) {
				sfinalStatus="FAIL";
				logger.error("Error while setting value");
				testCaseExecutionResult.setMessage("Error while setting value");
				return testCaseExecutionResult;
			}		            
			if (!EMPTY_STRING.equalsIgnoreCase(valueNotAvaliable))
			{
				logger.error("List Option "+ valueNotAvaliable +" not found  in list box");
				testCaseExecutionResult.setMessage("List Option "+ valueNotAvaliable +" not found  in list box");					
				return testCaseExecutionResult;
			}           
			if (sfinalStatus.toUpperCase().contains("FAIL"))
			{
				logger.error(sfinalStatus);
				testCaseExecutionResult.setMessage(sfinalStatus);
				return testCaseExecutionResult;
			}
			else{
				testCaseExecutionResult.setStatus(PASS);	            
				return testCaseExecutionResult;
			}
		} catch(Exception e){
			logger.error("Exception::",e);
			testCaseExecutionResult.setMessage(e.toString());return testCaseExecutionResult;}
		}
	}

	/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters listOfParameters[0]
	 *              (Mandatory) - svalueToSelect -valueNotClearPerviousSelection
	 * 
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */

	public TestcaseExecutionResultVO validateKeyword(String... params) {
		if(params!=null){
			listBoxLoctor=params[0];
			svalueToSelect=params[1];
			valueNotClearPerviousSelection=params[2];
			selectUsingSearch = params[3];
			CheckForContainsinselectUsingSearch = params[4];
		}
		else{
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setTestData(params[0]+DELIMITER+params[1]);
		if("".equals(params[0]))
		{
			logger.error("list box locator not given");
			testCaseExecutionResult.setMessage("list box locator not given");
			return testCaseExecutionResult;
		}
		if("".equals(params[1]))
		{
			logger.error("options not given");
			testCaseExecutionResult.setMessage("options not given");
			return testCaseExecutionResult;
		}
		if(selectUsingSearch.equalsIgnoreCase("Y")||selectUsingSearch.equalsIgnoreCase("Yes")||selectUsingSearch.equalsIgnoreCase("true")){
			selectUsingSearch = "Y";
		}else{
			selectUsingSearch = "N";
		}
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}

	/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... params) {	
		if (webDriver == null) {
			logger.error(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}	
				if (listBoxLoctor.startsWith(OBJECT_SPECIFIER)) {	
					listBoxLoctor = listBoxLoctor.substring(OBJECT_SPECIFIER.length(), listBoxLoctor.length());
		}
		listObjectElement=KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, listBoxLoctor,"", userName);
		if (listObjectElement==null){
			logger.error("List box not found");
			testCaseExecutionResult.setMessage("List box not found");
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}	
		testCaseExecutionResult.setObject(listBoxLoctor);
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}

}
