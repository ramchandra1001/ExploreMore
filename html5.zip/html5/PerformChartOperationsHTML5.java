package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;


/**
 * @author Ashish Joshi
 *This Keyword will get value from Kendo Chart UI control.
 */
public class PerformChartOperationsHTML5 extends AbstractKeyword {
	TestcaseExecutionResultVO testCaseExecutionResult =  new TestcaseExecutionResultVO();
	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
	/**
	 * This is Webelement
	 */
	private WebElement divElement=null;
	/**
	 * Name of the Chart/Chart Type  (Mandatory Parameter)
	 */
	private String sChartType =  null;
	/**
	 * Chart Locator (Mandatory Parameter)
	 */
	private String sChartlocator =  null;
	/**
	 * GET (Default GET), SET
	 */
	private String sOperation =  null;
	/**
	 * Name of The Category (Mandatory Parameter)
	 */
	private String sCategoryNameNo=null;
	/**
	 * Value to Set to Chart Control,Blank in case of GET operation
	 */
	private String sDataToUpdate =  null;
	/**
	 * Name of the Chart Stack,  
	 * Only mandatory in case of STACK_BAR, for  other types it�s not require
	 */
	private String sSeriesStackNameNo=null;
	/**
	 * Name of the Series (NA for PIE chart)
	 */
	private String sSeriesNameNo=null;
	/**
	 * Name of the Environment Variable to Store the Chart Value
	 */
	private String sEnvVariable =  null;
	private String sChartNameInKendo = "kendoChart";

	private String sChartOperationString = null;

	String chartTechnology  = "kendo";

	@Override
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO executeScript(String... params) 
	{	
		
		String sfinalStatus="FAIL";


		sOperation=sOperation.toUpperCase();

		try {
			if(chartTechnology.equals("kendo")) {
				getChartOperationString();
			}
			else if (chartTechnology.equals("fusion")){
				sOperation="GET";
				if(!getFusionChartOperationString()){
					return testCaseExecutionResult;
				}
			}

			sfinalStatus="FAIL";

			try {
				if(chartTechnology.equals("kendo")) {
					sfinalStatus =((JavascriptExecutor)webDriver).executeScript("return "+sChartOperationString,divElement).toString();
				}
				else if(chartTechnology.equals("fusion")){
					sfinalStatus =((JavascriptExecutor)webDriver).executeScript("return "+sChartOperationString,sChartlocator).toString();
				}
			} catch (Exception e) {

				sfinalStatus="FAIL";
			}

			if(sfinalStatus.equalsIgnoreCase("PASS"))
			{
				testCaseExecutionResult.setStatus(1);
				return testCaseExecutionResult;
			}
			else
			{
				if(sfinalStatus.toUpperCase().startsWith("SAFAL_FAIL_SCENARIO"))
				{
					sfinalStatus=sfinalStatus.replace("SAFAL_FAIL_SCENARIO:", "");
					sfinalStatus="FAIL, "+sfinalStatus;
					logger.error(sfinalStatus);
					testCaseExecutionResult.setMessage(sfinalStatus);
				}
				else
				{
					if(sEnvVariable.isEmpty())
					{
						sEnvVariable = sChartType+"_ChartNameValue";
					}
					configurationMap.put(sEnvVariable, sfinalStatus);
					testCaseExecutionResult.setConfigUpdate(true);
					testCaseExecutionResult.setStatus(1);
				}
				return testCaseExecutionResult;
			}
		} 
		catch (Exception e1)
		{
			logger.error("Exception::"+e1.getCause().toString());
			testCaseExecutionResult.setMessage(e1.getCause().toString());
			return testCaseExecutionResult;
		}
	}

	@Override

	/**
	 * This method validates the keywordsChartType 
	 *sChartlocator =  params[1];
	 *sOperation =  params[2];
	 *sCategoryNameNo=params[3];
	 *sDataToUpdate =  params[4];
	 *sSeriesStackNameNo=params[5];//only in case of BAR and Line Chart
	 *sSeriesNameNo=params[6];//only in case of BAR and Line Chart
	 *sEnvVariable =  params[7];*/
	public TestcaseExecutionResultVO validateKeyword(String... params) {
		if(params!=null){
			sChartType =  params[0];
			sChartlocator =  params[1];
			sOperation =  params[2];
			sCategoryNameNo=params[3];
			sDataToUpdate =  params[4];
			sSeriesStackNameNo=params[5];//only in case of BAR and Line Chart
			sSeriesNameNo=params[6];//only in case of BAR and Line Chart
			sEnvVariable =  params[7];
		}else{
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}

		chartTechnology  = configurationMap.get("CHART_TECHNOLOGY");
		if(chartTechnology == null || chartTechnology.isEmpty()){
			chartTechnology = "kendo";
		}
		
		if(sChartType.isEmpty())
		{
			logger.error("Chart type is not provided");
			testCaseExecutionResult.setMessage("Chart type is not provided");
			return testCaseExecutionResult;
		}

		if(sChartlocator.isEmpty())
		{
			logger.error("Chart Locator not provided");
			testCaseExecutionResult.setMessage("Chart Locator not provided");
			return testCaseExecutionResult;
		}

		if(sCategoryNameNo.isEmpty())
		{
			logger.error("Category not provided");
			testCaseExecutionResult.setMessage("Category not provided");
			return testCaseExecutionResult;
		}

		if((sChartType.toUpperCase().equals("LINE") || sChartType.toUpperCase().equals("BAR") || sChartType.toUpperCase().equals("STACK_BAR")) && "".equals(sSeriesNameNo) && !chartTechnology.equalsIgnoreCase("fusion"))
		{
			logger.error("Series Name or Number not Provided.");
			testCaseExecutionResult.setMessage("Series Name or Number not Provided.");
			return testCaseExecutionResult;
		}

		if(sOperation==null || "".equals(sOperation))
		{
			sOperation = "GET";
		}
		sOperation=sOperation.toUpperCase();

		if(sOperation.equals("SET"))
		{
			testCaseExecutionResult.setTestData("Operation : "+sOperation+" sValue : "+sDataToUpdate);	
		}
		else if(sOperation.equals("GET"))
		{
			testCaseExecutionResult.setTestData("Operation : "+sOperation+" sEnvVariable : "+sEnvVariable);	
		}
		else
		{
			logger.error("Invalid operation provided in Param2 i.e."+sOperation);
			testCaseExecutionResult.setMessage("Invalid operation provided in Param2 i.e."+sOperation);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}

	@Override
	/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... params) {
		if (webDriver == null) {
			logger.error ("ERROR_BROWSER_NOT_INSTANTIATED");
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}
		
		if (sChartlocator.startsWith(OBJECT_SPECIFIER)) {

			sChartlocator = sChartlocator.substring(OBJECT_SPECIFIER.length(), sChartlocator.length());
		} 

		
		
		if(chartTechnology.equalsIgnoreCase("kendo")) {
			divElement = KeywordUtilities.waitForElementPresentInstance(configurationMap, webDriver, sChartlocator, "",
					userName);

			if (divElement == null) {
				logger.error("Chart object not found");
				testCaseExecutionResult.setMessage("Chart object not found");
				testCaseExecutionResult.setValid(false);
				return testCaseExecutionResult;
			}
		}
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}

	
	
	public boolean getFusionChartOperationString(){
		logger.info("Inside executeScript getFusionChartOperationString method ");
		if(sChartType.equalsIgnoreCase("COLUMN") || sChartType.equalsIgnoreCase("BAR") || sChartType.equalsIgnoreCase("PIE")|| sChartType.equalsIgnoreCase("DONUT"))
		{

			sChartOperationString=
					"f(arguments[0]);																					" +
							"function f(ELE)																					" + 
							"{																									" +
							"		var label = \""+sCategoryNameNo+"\";"+
							"		var chartObj = null;"+
							"		try{"+
							"			chartObj = FusionCharts.getObjectReference(\""+sChartlocator+"\"); "+
							"		}	catch(e){"+
							"			return \"SAFAL_FAIL_SCENARIO:Chart with locator "+sChartlocator +" not found;\" " +
							"		}"+
							"		if(\""+sOperation+ "\".toUpperCase()=='GET') {" +
							
							"			var cdata = chartObj.getChartData(\"json\");"+
							"			for(cnt=0;cnt < cdata.data.length; cnt ++) {"+
							"				if(label.indexOf(cdata.data[cnt].label)!=-1){"+
							"					return cdata.data[cnt].value;"+
							"				}"+
							"			}"+
							"			return \"SAFAL_FAIL_SCENARIO:No such label found.\";"+
							"		}"+
							/*"		if(\""+sOperation+ "\".toUpperCase()=='SET') {" +
							"			var labelValue = \""+sDataToUpdate+"\";"+
							"			var cdata = chartObj.getChartData(\"json\");"+
							"			for(cnt=0;cnt < cdata.data.length; cnt ++) {"+
							"				if(label.indexOf(cdata.data[cnt].label)!=-1){"+
							"					cdata.data[cnt].value = labelValue;"+
							"					chartObj.setChartData(cdata);"+
							"					return \"PASS\";"+
							"				}"+
							"			}"+
							"			return \"SAFAL_FAIL_SCENARIO:No such label found.\";"+
							
							"		}"+*/
							"}";

			return true;
		}
		else{
			logger.error("Invalid chart type provided");
			testCaseExecutionResult.setMessage("Invalid chart type provided");
			return false;
		}
		
	}
	
	
	public void getChartOperationString()
	{
		logger.info("Inside executeScript getChartOperationString method ");
		if(sChartType.equalsIgnoreCase("BAR") || sChartType.equalsIgnoreCase("LINE")|| sChartType.equalsIgnoreCase("STACK_BAR")|| sChartType.equalsIgnoreCase("COLUMN"))
		{

			sChartOperationString=
					"f(arguments[0]);																					" +
							"function f(ELE)																					" + 
							"{																									" +
							"	var Result='SAFAL_FAIL_SCENARIO';																				" +
							"	try																								" +
							"	{																								" +
							"		var mkobj = $(ELE);																			" +
							"		var chart = mkobj.data(\""+sChartNameInKendo+"\");" +
							"		var series = chart.options.series;" +
							"		var allStackNames='';" +
							"		var seriesNameIndex=-1;" +
							"		var seriesStackIndex=-1;" +
							"		var seriesStackFlag=false;" +
							"		for(var i=0;i<series.length;i++)" +
							"		{" +
							//"			allStackNames=allStackNames+';'+series[i].name;" +
							"				if(series[i].name==\""+sSeriesNameNo+"\")" +
							"				{" +
							"					seriesNameIndex=i;" +
							"					if(\""+sSeriesStackNameNo+"\".length != 0)" +
							"					{" +
							"							seriesStackFlag=true;"+
							"							if(series[i].stack==\""+sSeriesStackNameNo+"\")" +
							"							{" +
							"								seriesStackIndex=i;" +
							"								break;" +
							"							}	" +
							"					}"+
							"					else" +
							"					{" +
							"						break;" +
							"					}	" +
							"				}" +
							"		}" +
							"		if (seriesStackFlag==true && seriesStackIndex==-1)" +
							"		{" +
							"			return 'SAFAL_FAIL_SCENARIO:Require Series stack \""+sSeriesStackNameNo+ "\" not found in the Chart';" +
							"		}" +
							"		if(seriesNameIndex==-1)" +
							"		{" +
							"			return 'SAFAL_FAIL_SCENARIO:Require Series name \""+sSeriesNameNo+ "\" not found in the Chart';" +
							"		}" +
							"		var Catagories = chart.options.categoryAxis.categories;" +
							"		var catagoriesNameIndex=-1;" +
							"		for(var i=0;i<Catagories.length;i++)" +
							"		{" +
							"				if(Catagories[i]==\""+sCategoryNameNo+ "\")" +
							"				{" +
							"					catagoriesNameIndex=i;" +
							"					break;" +
							"				}	" +
							"		}" +
							"		if(catagoriesNameIndex==-1)" +
							"		{" +
							"			return 'SAFAL_FAIL_SCENARIO:Require Catagory \""+sCategoryNameNo+ "\" not found in the Chart';" +
							"		}" +
							"		if(\""+sOperation+ "\".toUpperCase()=='SET')" +
							"		{" +
							"			if(seriesStackFlag==true && seriesStackIndex==-1)" +
							"			{" +
							"				series[seriesNameIndex,seriesStackIndex].data[catagoriesNameIndex]= \""+sDataToUpdate+ "\";" +
							"			}" +
							"			else" +
							"			{" +
							"				series[seriesNameIndex].data[catagoriesNameIndex] = \""+sDataToUpdate+ "\";" +
							"			}" +
							"			chart.redraw();" +
							"			chart.refresh();"+
							"			Result= \"PASS\";	 " +
							"		}" +
							"		else" +
							"		{" +
							"			if(seriesStackFlag==true && seriesStackIndex==-1)" +
							"			{" +
							"				Result= (series[seriesNameIndex,seriesStackIndex].data[catagoriesNameIndex]);" +
							"			}" +
							"			else" +
							"			{" +
							"				Result= (series[seriesNameIndex].data[catagoriesNameIndex]);" +
							"			}" +
							"		}"+
							"	}																								" +
							"	catch(e)																						" +
							"	{																								" +
							"		Result='SAFAL_FAIL_SCENARIO:'+ e.description;																" +
							"	}																								" +
							"	return Result;																					" +
							"}" ;
		}
		else if(sChartType.equalsIgnoreCase("PIE"))
		{
			sChartOperationString=
					"f(arguments[0]);																					" +
							"function f(ELE)																					" + 
							"{																									" +
							"	var Result='SAFAL_FAIL_SCENARIO';																				" +
							"	try																								" +
							"	{																								" +
							"		var mkobj = $(ELE);																			" +
							"		var chart = mkobj.data(\""+sChartNameInKendo+"\");" +
							"		var series = chart.options.series[0].data;" +
							"		var seriesNameIndex=-1;" +
							"		for(var i=0;i<series.length;i++)" +
							"		{" +
							"			if(series[i].category==\""+sCategoryNameNo+"\")" +
							"			{" +
							"				seriesNameIndex=i;" +
							"				break;" +
							"			}	" +
							"		}" +
							"		if(seriesNameIndex==-1)" +
							"		{" +
							"			return 'SAFAL_FAIL_SCENARIO:Require Category \""+sCategoryNameNo+ "\" not found in the Chart';" +
							"		}" +
							"		if(\""+sOperation+ "\".toUpperCase()=='SET')" +
							"		{" +
							"			series[seriesNameIndex].value = \""+sDataToUpdate+ "\";" +
							"			chart.redraw();" +
							"			chart.refresh();" +
							"			Result= \"PASS\";	 " +
							"		}" +
							"		else" +
							"		{" +
							"			Result= (series[seriesNameIndex].value);" +
							"		}"+
							"	}																								" +
							"	catch(e)																						" +
							"	{																								" +
							"		Result='SAFAL_FAIL_SCENARIO:'+ e.description;																" +
							"	}																								" +
							"	return Result;																					" +
							"}" ;
		}

		else if(sChartType.equalsIgnoreCase("DONUT"))
		{
			sChartOperationString=
					"f(arguments[0]);																					" +
							"function f(ELE)																					" + 
							"{																									" +
							"	var Result='SAFAL_FAIL_SCENARIO';																				" +
							"	try																								" +
							"	{																								" +
							"		var mkobj = $(ELE);																			" +
							"		var chart = mkobj.data(\""+sChartNameInKendo+"\");" +
							"		var series = chart.options.series;" +
							"		var allStackNames='';" +
							"		var allCategoriesName='';" +
							"		var seriesNameIndex=-1;" +
							"		var catagoriesNameIndex=-1;" +
							"		for(var i=0;i<series.length;i++)" +
							"		{" +
							"			allStackNames=allStackNames+';'+series[i].name;" +
							"				if(series[i].name==\""+sSeriesNameNo+"\")" +
							"				{" +
							"					seriesNameIndex=i;" +
							"					var catagoriesData=series[seriesNameIndex].data;" +
							"					for(var j=0;j<catagoriesData.length;j++)" +
							"					{" +
							"							allCategoriesName=allCategoriesName+';'+catagoriesData[j].category;" +
							"							if(catagoriesData[j].category==\""+sCategoryNameNo+"\")" +
							"							{" +
							"								catagoriesNameIndex=j;" +
							"								break;" +
							"							}" +
							"					}" +
							"				}"+
							"		}" +
							//"		return allStackNames + ':'+seriesNameIndex;"+
							//"		return allCategoriesName + ':'+catagoriesNameIndex;"+
							"		if(seriesNameIndex==-1)" +
							"		{" +
							"			return 'SAFAL_FAIL_SCENARIO:Require Series name \""+sSeriesNameNo+ "\" not found in the Chart';" +
							"		}" +
							"		if(catagoriesNameIndex==-1)" +
							"		{" +
							"			return 'SAFAL_FAIL_SCENARIO:Require Catagory \""+sCategoryNameNo+ "\" not found in the Chart';" +
							"		}" +
							"		if(\""+sOperation+ "\".toUpperCase()=='SET')" +
							"		{" +
							"			series[seriesNameIndex].data[catagoriesNameIndex].value = \""+sDataToUpdate+ "\";" +
							"			chart.redraw();" +
							"			chart.refresh();"+
							"			Result= \"PASS\";	 " +
							"		}" +
							"		else" +
							"		{" +
							"				Result= (series[seriesNameIndex].data[catagoriesNameIndex].value);" +
							"		}"+
							"	}																								" +
							"	catch(e)																						" +
							"	{																								" +
							"		Result='SAFAL_FAIL_SCENARIO:'+ e.description;																" +
							"	}																								" +
							"	return Result;																					" +
							"}" ;
		}



	}

}
