package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.EMPTY_STRING;
import static com.sungard.ktt.view.config.KTTGuiConstants.FAIL;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;
/*This kwyqord will work with date picker control to set dates*/
public class DatePickerHTML5 extends AbstractKeyword{ 

	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();	
	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
	/**
	 * This is web element object
	 */
	private WebElement calCont_Obj;
	/**
	 * This is web element object
	 */
	private WebElement calObj;

	/**
	 *(optional) Day Default 1 
	 */
	private String sDay = null;
	/**
	 * (optional ) Month Default JAN
	 */
	private String sMonth = null;
	/**
	 * (optional ) Year Default 2013
	 */
	private String sYear = null;
	/**
	 * Locator for Datepicker expander 
	 */
	private String sLocator = null;
	/**
	 * optional ) Locator for Calendar Container Locator
	 */
	private String calContainer = null;		
	
	private String datePicker_Bootstrap = null;
	
	private String controlType = null;
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO executeScript(String... listOfParameters) {

		if (controlType != null && controlType.equalsIgnoreCase("material")) {
			if(sDay!=null && !sDay.isEmpty() && sMonth!=null && !sMonth.isEmpty() && sYear!=null && !sYear.isEmpty()) {
				try {
					setDateForAngularMaterialControl(sDay, sMonth, sYear);
				}
				catch(Exception e) {
					logger.error("Error occured:",e);
					testCaseExecutionResult.setMessage("Error Occured:"+e.getMessage());	
					return testCaseExecutionResult;
				}
			}
			else {
				testCaseExecutionResult.setMessage("Day, Month and Year required");			
			}
		} else {

			try {
				if (EMPTY_STRING.equals(sDay)) {
					sDay = "1";
				}
				if (EMPTY_STRING.equals(sMonth)) {
					sMonth = "JAN";
				}
				if (EMPTY_STRING.equals(sYear)) {
					sYear = "2013";
				}

				if (!datePicker_Bootstrap.equalsIgnoreCase("N")) {
					WebElement getYearBtn = null;
					WebElement monthBtn = null;
					WebElement moveNext = null;
					WebElement moveBack = null;
					WebElement expectedBtn = null;
					WebElement dayBtn = null;
					int year = -1,day = -1;//, mon = -1, day = -1;
					try {
						year = Integer.parseInt(sYear);
					} catch (Exception e) {
						logger.error("Error while geting year");
						testCaseExecutionResult.setMessage("year is not correct");
						testCaseExecutionResult.setStatus(0);
						return testCaseExecutionResult;
					}
					try {
						day = Integer.parseInt(sDay);
					} catch (Exception e) {
						logger.error("Error while geting Day");
						testCaseExecutionResult.setMessage("Enter day is not correct");
						testCaseExecutionResult.setStatus(0);
						return testCaseExecutionResult;
					}

					String yearBtnID = calContainer
							+ "//table[@role='grid']/thead//button[@class='fis-rwd-calendar-middle']";
					getYearBtn = KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap, webDriver,
							yearBtnID, "1", userName);
					if (getYearBtn == null) {
						logger.error("Error getting  year button");
						testCaseExecutionResult.setMessage("Error getting  year button");
						testCaseExecutionResult.setStatus(0);
						return testCaseExecutionResult;
					}
					try {
						((JavascriptExecutor) webDriver)
								.executeScript("arguments[0].click(); return 'pass';", getYearBtn).toString();
						Thread.sleep(1000);
					} catch (Exception e) {
						logger.error("Error while clicking on year button");
						testCaseExecutionResult.setMessage("Error while clicking on year button");
						testCaseExecutionResult.setStatus(0);
						return testCaseExecutionResult;

					}
					String yearBtnID_Change = calContainer
							+ "//table[@role='grid']/thead//button[@class='fis-rwd-calendar-midle btn-default btn-sm']";
					getYearBtn = KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap, webDriver,
							yearBtnID_Change, "1", userName);
					if (getYearBtn == null) {
						logger.error("Error getting  year button");
						testCaseExecutionResult.setMessage("Error getting  year button");
						testCaseExecutionResult.setStatus(0);
						return testCaseExecutionResult;
					}
					String moveBackID = calContainer
							+ "//table[@role='grid']/thead//button[contains(@class,'fis-rwd-calendar-pull-left')]";
					String moveNextID = calContainer
							+ "//table[@role='grid']/thead//button[contains(@class,'fis-rwd-calendar-pull-right')]";

					String yearUI = getYearBtn.getText();
					int year_UI = -1;
					try {
						year_UI = Integer.parseInt(yearUI);
					} catch (Exception e) {
						logger.error("Error while geting year");
						testCaseExecutionResult.setMessage("year is not correct");
						testCaseExecutionResult.setStatus(0);
						return testCaseExecutionResult;
					}
					moveNext = KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap, webDriver,
							moveNextID, "1", userName);
					if (moveNext == null) {
						logger.error("Error getting  move right btn");
						testCaseExecutionResult.setMessage("Error getting  move right btn");
						testCaseExecutionResult.setStatus(0);
						return testCaseExecutionResult;
					}
					moveBack = KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap, webDriver,
							moveBackID, "1", userName);
					if (moveBack == null) {
						logger.error("Error getting  move left btn");
						testCaseExecutionResult.setMessage("Error getting  move left btn");
						testCaseExecutionResult.setStatus(0);
						return testCaseExecutionResult;
					}

					if (year_UI > year) {
						expectedBtn = moveBack;
					} else {
						expectedBtn = moveNext;
					}
					int diff = year_UI - year;
					if (diff < 0) {
						diff = diff * -1;
					}
					for (int i = 0; i < diff; i++) {
						try {
							((JavascriptExecutor) webDriver)
									.executeScript("arguments[0].click(); return 'pass';", expectedBtn).toString();
							Thread.sleep(500);
						} catch (Exception e) {
							logger.error("Error while clicking on navigation button");
							testCaseExecutionResult.setMessage("Error while clicking on navigation button");
							testCaseExecutionResult.setStatus(0);
							return testCaseExecutionResult;

						}

					}

					String monthBtnID = calContainer + "//table[@role='grid']/tbody//tr//td//button/span[text()='"
							+ sMonth + "']";
					monthBtn = KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap, webDriver,
							monthBtnID, "1", userName);
					if (monthBtn == null) {
						logger.error("Error getting  month  btn");
						testCaseExecutionResult.setMessage("Error getting  month  btn");
						testCaseExecutionResult.setStatus(0);
						return testCaseExecutionResult;
					}
					try {
						((JavascriptExecutor) webDriver).executeScript("arguments[0].click(); return 'pass';", monthBtn)
								.toString();
						Thread.sleep(500);
					} catch (Exception e) {
						logger.error("Error while clicking on month button");
						testCaseExecutionResult.setMessage("Error while clicking on month button");
						testCaseExecutionResult.setStatus(0);
						return testCaseExecutionResult;
					}

					String dayBtnID = calContainer
							+ "//table[@role='grid']/tbody//tr//td[@aria-disabled='false']/button[not (@class='fis-rwd-calendar-cell fis-rwd-calendar-cell-disabled')]/span[text()='"
							+ sDay + "']";
					dayBtn = KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap, webDriver,
							dayBtnID, "1", userName);
					if (dayBtn == null) {
						logger.error("Error getting  day  btn");
						testCaseExecutionResult.setMessage("Error getting  day  btn/Date not selectable");
						testCaseExecutionResult.setStatus(0);
						return testCaseExecutionResult;
					}
					try {
						((JavascriptExecutor) webDriver).executeScript("arguments[0].click(); return 'pass';", dayBtn)
								.toString();
						Thread.sleep(500);
					} catch (Exception e) {
						logger.error("Error while clicking on day button");
						testCaseExecutionResult.setMessage("Error while clicking on day button");
						testCaseExecutionResult.setStatus(0);
						return testCaseExecutionResult;
					}
					testCaseExecutionResult.setStatus(PASS);
					return testCaseExecutionResult;

				}

				/*
				 * if(EMPTY_STRING.equals(calContainer)){
				 * calContainer="xpath=//div[@class='k-widget k-calendar']"; } else
				 * if(calContainer.startsWith(OBJECT_SPECIFIER)){ calContainer =
				 * calContainer.substring(OBJECT_SPECIFIER.length(), calContainer.length()); }
				 */

				////////////////////////////////////////////////////////////////
				String svalueToSelect = sYear + ", " + sMonth + ", " + sDay;

				/*
				 * try { calCont_Obj =
				 * KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap,
				 * webDriver, sLocator,"1"); } catch (Exception e4) { e4.printStackTrace();
				 * TestcaseExecutionResultVO.
				 * setMessage("Error while finding calender button icon");
				 * TestcaseExecutionResultVO.setStatus(0); return TestcaseExecutionResultVO;}
				 */

				try {
					((JavascriptExecutor) webDriver).executeScript("arguments[0].click(); return 'pass';", calCont_Obj)
							.toString();
					Thread.sleep(3000);
				} catch (Exception e) {
					logger.error("Error while getting calender icon");
					testCaseExecutionResult.setMessage("Error while getting calender icon");
					testCaseExecutionResult.setStatus(0);
					return testCaseExecutionResult;

				}

				String mySelector = "f(arguments[0]);                                                                                                                         "
						+ "function f(ELE)                                                                                                                          "
						+ "{                                                                                                                                            "
						+ "     var sCalLocator = ELE;                                                                                                             "
						+ "     var svalueToSelect = \"" + svalueToSelect
						+ "\";                                                                           "
						+ "     var Result='FAIL';                                                                                                                        "
						+ "     try                                                                                                                                             "
						+ "     {                                                                                                                                               "
						+ "           var mkobj = $(sCalLocator); "
						+ "           mkobj.data('kendoCalendar').value(new Date(svalueToSelect));"
						+ "			  mkobj.data('kendoCalendar').trigger('change');	" + "           Result= 'PASS';"
						+ "     }                                                                                                                                               "
						+ "     catch(e)                                                                                                                                  "
						+ "     {                                                                                                                                               "
						+ "           Result='FAIL'+ e.description;                                                                                           "
						+ "     }                                                                                                                                               "
						+ "     return Result;                                                                                                                            "
						+ "}";

				try {
					((JavascriptExecutor) webDriver).executeScript("return " + mySelector, calObj).toString();
					Thread.sleep(5000);
				} catch (Exception e1) {
					logger.error("Error while setting value");
					testCaseExecutionResult.setMessage("Error while setting value");
					testCaseExecutionResult.setStatus(0);
					return testCaseExecutionResult;
				}
			} catch (Exception e) {
				logger.error("Error while setting value");
				testCaseExecutionResult.setMessage("Error while setting value");
				testCaseExecutionResult.setStatus(0);
				return testCaseExecutionResult;
			}
			testCaseExecutionResult.setStatus(PASS);
			return testCaseExecutionResult;
		}
		return testCaseExecutionResult;
	}

	//==============================================================================================================================================

	/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters
	 *            - sLocator-sDay -sMonth-sYear-calContainer
	 * 
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */

	@Override
	public TestcaseExecutionResultVO validateKeyword(String... listOfParameters) {

		if (listOfParameters != null) 
		{
			sLocator=listOfParameters[0];
			sDay = listOfParameters[1];
			sMonth=listOfParameters[2];
			sYear=listOfParameters[3];
			calContainer=listOfParameters[4];
			datePicker_Bootstrap=listOfParameters[5];
			controlType=listOfParameters[6];
			
		} else{
			logger.error(ERROR_PARAMETERS_LIST);
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setTestData(sLocator+DELIMITER+sDay+DELIMITER+sMonth+DELIMITER+sYear+DELIMITER+calContainer);
		if (controlType != null && !controlType.equalsIgnoreCase("material") && EMPTY_STRING.equals(sLocator) ){
			logger.error("Calender button not found");
			testCaseExecutionResult.setMessage("Calender button not found");
			return testCaseExecutionResult;
		}
		if (EMPTY_STRING.equals(datePicker_Bootstrap)||datePicker_Bootstrap.equalsIgnoreCase("n")||datePicker_Bootstrap.equalsIgnoreCase("no")||datePicker_Bootstrap.equalsIgnoreCase("false") ){
			datePicker_Bootstrap ="N";
		}else{
			datePicker_Bootstrap="Y";
		}
		
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;				
	}



	@Override

/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... listOfParameters) {

		if (webDriver == null) {
			logger.error ("ERROR_BROWSER_NOT_INSTANTIATED");
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}

		if(!EMPTY_STRING .equalsIgnoreCase(sLocator) ){
			sLocator = sLocator.substring(OBJECT_SPECIFIER.length(), sLocator.length()); 
		}
		
		

		if (controlType != null && !controlType.equalsIgnoreCase("material")) {
			try {
				calCont_Obj = KeywordUtilities.waitForElementPresentInstance(configurationMap, webDriver, sLocator, "",
						userName);
			} catch (Exception e) {

				logger.error("Error while finding calender button icon");
				testCaseExecutionResult.setMessage("Error while finding calender button icon");
				testCaseExecutionResult.setStatus(0);
				return testCaseExecutionResult;
			}

			// ASK

			if (calCont_Obj == null) {
				logger.error("calender button icon not found");
				testCaseExecutionResult.setMessage("calender button icon not found");
				testCaseExecutionResult.setValid(false);
				return testCaseExecutionResult;
			}

			if (datePicker_Bootstrap.equalsIgnoreCase("N")) {
				if (EMPTY_STRING.equals(calContainer)) {
					calContainer = "xpath=//div[@class='k-widget k-calendar']";
				} else if (calContainer.startsWith(OBJECT_SPECIFIER)) {
					calContainer = calContainer.substring(OBJECT_SPECIFIER.length(), calContainer.length());
				}
			} else {
				if (EMPTY_STRING.equals(calContainer)) {
					calContainer = "xpath=//ul[contains(@class,'uib-datepicker-popup') and @template-url='uib/template/datepicker/popup.html'  and @role='button']";
				} else if (calContainer.startsWith(OBJECT_SPECIFIER)) {
					calContainer = calContainer.substring(OBJECT_SPECIFIER.length(), calContainer.length());
				}
			}

			try {
				((JavascriptExecutor) webDriver).executeScript("arguments[0].click();", calCont_Obj);
			} catch (Exception e) {
				try {
					calCont_Obj.click();
				} catch (Exception e1) {
					testCaseExecutionResult.setMessage("Error while getting calender object");
					testCaseExecutionResult.setStatus(0);
					testCaseExecutionResult.setValid(false);
					return testCaseExecutionResult;

				}
			}

			try {
				calObj = KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap, webDriver,
						calContainer, "1", userName);
				// calObj = KeywordUtilities.getWebElement(webDriver, calContainer);
			} catch (Exception e4) {

				logger.error("Error while getting calender object");
				testCaseExecutionResult.setMessage("Error while getting calender object");
				testCaseExecutionResult.setStatus(0);
				return testCaseExecutionResult;
			}

			if (calObj == null) {
				logger.error("Error while getting calender object");
				testCaseExecutionResult.setMessage("Error while getting calender object");
				testCaseExecutionResult.setStatus(0);
				testCaseExecutionResult.setValid(false);
				return testCaseExecutionResult;
			}
		}

		testCaseExecutionResult.setObject(sLocator);
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;

	}

	private  void setDateForAngularMaterialControl(String sDay, String sMonth, String sYear) throws InterruptedException {
		
		String yearAndMonthButtonLocator = "@xpath=//button[@aria-label=\"Choose month and year\"]";
		WebElement yearAndMonthButton =KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap,webDriver, yearAndMonthButtonLocator,"", userName);
				
		
		if(yearAndMonthButton!=null) {
		
			String sActualYear = yearAndMonthButton.getText().trim().split(" ")[1];
			int iActualYear = Integer.parseInt(sActualYear);
			int iExpectedYear = Integer.parseInt(sYear);
			((JavascriptExecutor)webDriver).executeScript("arguments[0].click()", yearAndMonthButton);
			
			if(iActualYear!=iExpectedYear) {			
				WebElement navigateButton = null;						
				WebElement firstListedYear = KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap,webDriver, "@xpath=//table[contains(@class,\"mat-calendar-table\")]/tbody/tr/td/div","1", userName);
				int iFirstListYear = Integer.parseInt(firstListedYear.getText());
			
				int iLastListedYear = iFirstListYear + 23;
				
				if (!(iExpectedYear >= iFirstListYear && iExpectedYear <= iLastListedYear)) {

					if (iExpectedYear > iLastListedYear) {
						navigateButton = KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap,
								webDriver, "@xpath=//button[contains(@class,\"mat-calendar-next-button\")]", "1",
								userName);						
					} else {
						navigateButton = KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap,
								webDriver, "@xpath=//button[contains(@class,\"mat-calendar-previous-button\")]", "1",
								userName);						
					}

					boolean isYearFound = false;

					while (!isYearFound) {
						((JavascriptExecutor) webDriver).executeScript("arguments[0].click()", navigateButton);
						Thread.sleep(500);
						firstListedYear = KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap,
								webDriver, "@xpath=//table[contains(@class,\"mat-calendar-table\")]/tbody/tr/td/div",
								"1", userName);
						iFirstListYear = Integer.parseInt(firstListedYear.getText());
						
						iLastListedYear =iFirstListYear + 23;

						if (iExpectedYear >= iFirstListYear && iExpectedYear <= iLastListedYear) {
							isYearFound = true;
							break;
						}

					}
				}
			}
			
			WebElement yearLink  = KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap,webDriver, "@xpath=//div[contains(@class,\"mat-calendar-body-cell-content\") and text()=\""+sYear+"\"]","1", userName);
			if(yearLink!=null) {
				((JavascriptExecutor)webDriver).executeScript("arguments[0].click()", yearLink);
				//
				WebElement monthLink  = KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap,webDriver, "@xpath=//div[contains(@class,\"mat-calendar-body-cell-content\") and text()=\"" +sMonth +"\"]","1", userName);
				
				if(monthLink!=null) {
					((JavascriptExecutor)webDriver).executeScript("arguments[0].click()", monthLink);
					
					WebElement dayLink =  KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap,webDriver, "@xpath=//div[contains(@class,\"mat-calendar-body-cell-content\") and text()=\"" +sDay +"\"]","1", userName);
					if(dayLink!=null) {
						((JavascriptExecutor)webDriver).executeScript("arguments[0].click()", dayLink);
						testCaseExecutionResult.setStatus(PASS);
					}
					else {
						testCaseExecutionResult.setMessage("Unable to find day link");
						testCaseExecutionResult.setStatus(FAIL);
					}
				}
				else {
					testCaseExecutionResult.setMessage("Unable to find month link");
					testCaseExecutionResult.setStatus(FAIL);
				}
			}
			else {
				testCaseExecutionResult.setMessage("Unable to find Year link");
				testCaseExecutionResult.setStatus(FAIL);
			}
		
		}
		else {
			testCaseExecutionResult.setMessage("Unable to find Year Month element");
			testCaseExecutionResult.setStatus(FAIL);
			
		}		
		
		
	}
}
