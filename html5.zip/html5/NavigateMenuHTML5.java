package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_MENU_NOT_FOUND;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_MENU_NOT_PASSED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.view.config.KTTGuiConstants.EMPTY_STRING;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS_STEP_STATUS;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;
/**
 * @ author  Gyaneshwar.Nandanwar on 02-Dec-2013
 * This keyword selects the specified menu items of a Menubar.
 */
public class NavigateMenuHTML5 extends AbstractKeyword 
{

	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();

	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());

	/**
	 * This is web element object
	 */
	private WebElement elementMegaMenuButton, element_sg_off_canvas_menu,element_nav_pull_right;
	/**
	 *Menu items separated by pipe (|)
	 */
	private String sMenuItems = null;	
	private String megaMenuButtonLocator=null, ulElementLocatorOfMegaMenu=null, ulElementLocatorOfRightCanvas=null;
	@Override
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */

	public TestcaseExecutionResultVO executeScript(String... listOfParameters)
	{
		
		String sMenuToClick = sMenuItems;
		//elementMegaMenuButton = KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap,webDriver, "xpath=//button[@sgid='startMenu_toggle__1' or @fisid='startMenu_toggle__1']","",userName);
		if(megaMenuButtonLocator==null || megaMenuButtonLocator.isEmpty()){
			elementMegaMenuButton = KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap,webDriver, "@xpath=//button[@ng-if='showMenuButton()']","",userName);
		}
		else{
			elementMegaMenuButton = KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap,webDriver, megaMenuButtonLocator,"",userName);
		}
		
		if (sMenuItems.toUpperCase().startsWith("MENU")){
			sMenuToClick=sMenuItems.substring(5);
			if(elementMegaMenuButton==null)
			{
				logger.error("Start Menu Button not found");
				testCaseExecutionResult.setMessage("Start Menu Button not found");
				return testCaseExecutionResult;
			}

			try {
				//element_sg_off_canvas_menu = KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap,webDriver, "css=ul.sg-off-canvas-menu","", userName);
				if(ulElementLocatorOfMegaMenu==null || ulElementLocatorOfMegaMenu.isEmpty()){
					element_sg_off_canvas_menu = KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap,webDriver, "xpath=//ul[contains(@class,'-start-menu-list')]","", userName);
				}
				else{
					element_sg_off_canvas_menu = KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap,webDriver, ulElementLocatorOfMegaMenu,"", userName);
				}
				
			} catch (Exception e) {
				//System.out.println(e.getMessage());
				logger.error("Start Menu Locator not found"+e.getCause().toString());
				testCaseExecutionResult.setMessage("Start Menu Locator not found");
			}	
		}
		else {
			try {
				//element_nav_pull_right = KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap,webDriver, "css=ul.nav.pull-right.ng-scope","1", userName);
				if(ulElementLocatorOfRightCanvas==null || ulElementLocatorOfRightCanvas.isEmpty()){
					element_nav_pull_right = KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap,webDriver, "xpath=//ul[contains(@class,'pull-right')]","1", userName);
				}
				else{
					element_nav_pull_right = KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap,webDriver,ulElementLocatorOfRightCanvas,"1", userName);
				}
				
				//element_nav_pull_right=elements_nav_pull_right.get(0);
			} catch (Exception e) {
				//System.out.println(e.getMessage());
				logger.error("Navigataion Menu Locator not found"+e.getCause().toString());
				testCaseExecutionResult.setMessage("Navigataion Menu Locator not found");
			}
		}
		String sSelectMenuItem =
				"	  return SelectMenu(arguments[0],arguments[1],arguments[2]);																			"+				
						"	  function SelectMenu(menuObj,isMegaMenu, MegaMenuElement)																					"+
						"	  {																							            			"+
						"		try																												"+
						"		{																												"+
						"			if (isMegaMenu=='1')																						"+			
						"			{																											"+
						"				var Body_Ele= document.body;																			"+
						"				var Body_Ele_class = $(Body_Ele).attr('class');															"+				
						"				if (Body_Ele_class.indexOf('-start-menu-opened')==-1){													"+
						"					MegaMenuElement.click();}																			"+
						"			}																											"+
						"			var menuItems=\""+sMenuToClick+"\";																			"+
						"			var SplitedtmenuItems=menuItems.split('|');																	"+
						"			for (var i=0;i<SplitedtmenuItems.length;i++)																"+		
						"			{																											"+
						"				var ul_item=ret_menu_item(menuObj,SplitedtmenuItems[i]);												"+
						"				if(ul_item=='NO_ITEM')																					"+
						"				{																										"+
						"					return('Following Menu item not found =>'+ SplitedtmenuItems[i]);									"+
						"					break;																								"+
						"				}																										"+
						"				else																									"+
						"				{																										"+			
						"					menuObj=ul_item;																					"+
						"				}																										"+
						"			}																											"+
						"			return \""+PASS_STEP_STATUS+"\";																			"+
						"		}catch(error)																									"+
						"		{																												"+
						"			return ('Error- '+error.description);																		"+
						"		}																												"+
						"	  }																													"+
						"	  function ret_menu_item(menuObj, str)																				"+
						"	  {																							            			"+
						"		try																												"+
						"		{																												"+
						"			var element_ul = menuObj;																					"+
						"			var next_element_ul='NO_ITEM';																				"+
						"			jQuery.each($(element_ul).children(), function() 															"+
						"			{																											"+
						"			var menuItemText=($.trim($(this).children().text())).substr(0,str.length);								"+
						"				if (menuItemText==str)																					"+
						"				{																										"+
						"					if (!($(this).hasClass('expanded')) && !($(this).hasClass('open')))									"+
						"					{																									"+
						" 					if ($(this).children(0).children('div').length)														"+
						"						$(this).children(0).children('div')[0].click();													"+
						"					else																								"+
						" 						$(this).children(0)[0].click();																	"+
						"					}																									"+							
						"					next_element_ul= $(this).children().last()[0];														"+
						"					if ($(next_element_ul).children('ul').length)														"+
						"						next_element_ul=$(next_element_ul).children('ul')[0];											"+
						"				return(false);																							"+
						"				}																										"+
						"			});																											"+
						"		return next_element_ul;																							"+
						"		}catch(error)																									"+
						"		{																												"+
						"			return ('Error- '+error.description);																		"+
						"		}																												"+
						"	  }";


		String sFinalRes =EMPTY_STRING;			
		try{
			if (sMenuItems.toUpperCase().startsWith("MENU")){				
				sFinalRes = (String)((JavascriptExecutor)webDriver).executeScript(sSelectMenuItem.toString(), element_sg_off_canvas_menu,"1",elementMegaMenuButton);
			}
			else
				sFinalRes = (String)((JavascriptExecutor)webDriver).executeScript(sSelectMenuItem.toString(), element_nav_pull_right,"0",elementMegaMenuButton);
		}catch(Exception e){
			logger.error(e.getCause().toString());
			sFinalRes=EMPTY_STRING;
		}
		if (sFinalRes==null){
			sFinalRes=EMPTY_STRING;
		}
		if (sFinalRes.equals(PASS_STEP_STATUS))
		{
			testCaseExecutionResult.setStatus(PASS);
			return testCaseExecutionResult;
		} else
		{
			if (sFinalRes.startsWith("Following"))
				testCaseExecutionResult.setMessage(sFinalRes);
			else if (sFinalRes.startsWith("Error-"))
				logger.error(ERROR_MENU_NOT_FOUND);
			testCaseExecutionResult.setMessage(ERROR_MENU_NOT_FOUND);
			return testCaseExecutionResult;
		}		
	}

	@Override

	/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters
	 *            - sMenuItems -
	 * 
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */

	public TestcaseExecutionResultVO validateKeyword(String... listOfParameters)
	{
		// check for required parameter count
		if (listOfParameters != null)
		{			
			 sMenuItems = listOfParameters[0];
			 megaMenuButtonLocator=listOfParameters[1];
			 ulElementLocatorOfMegaMenu=listOfParameters[2];
			 ulElementLocatorOfRightCanvas=listOfParameters[3];

		} else
		{
			// Insufficient Parameters
			logger.error("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}

		testCaseExecutionResult.setTestData("Menu to select: " + sMenuItems);

		if (KeywordUtilities.isEmptyString(sMenuItems))
		{
			logger.error(ERROR_MENU_NOT_PASSED);
			testCaseExecutionResult.setMessage(ERROR_MENU_NOT_PASSED);
			return testCaseExecutionResult;
		}

		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;

	}

	@Override


	/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... listOfParameters) {

		if (webDriver == null) {
			logger.error ("ERROR_BROWSER_NOT_INSTANTIATED");
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}

}