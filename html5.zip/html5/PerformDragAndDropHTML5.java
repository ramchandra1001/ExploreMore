package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.business.keywords.ScrollToElement;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;

public class PerformDragAndDropHTML5 extends AbstractKeyword {
    String elementSourceLocator = "";
    String elementDestinationLocator = "";
    String performusingMouseAction = "";
    String elementSourceInstance="";
    String elementDestinationInstance="";
    String moveXYOffset="";
    String performExplicitScroll="";
       
    private WebElement elementSource = null;
    private WebElement elementDestnation = null;
    TestcaseExecutionResultVO testCaseExecutionResult =  new TestcaseExecutionResultVO();
    Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());

	@Override
	public TestcaseExecutionResultVO validateKeyword(String... params) {
		elementSourceLocator = params[0];
		elementDestinationLocator = params[1];
		elementSourceInstance = params[2];
		elementDestinationInstance=params[3];
		performusingMouseAction = params[4];
		moveXYOffset = params[5];
		performExplicitScroll = params[6];
		
		
		
		if (KeywordUtilities.isEmptyString(performusingMouseAction)){
			performusingMouseAction = "N";
		}
		if (KeywordUtilities.isEmptyString(moveXYOffset)){
			moveXYOffset = "0|0";
		}
		
		if(performExplicitScroll!=null && (performExplicitScroll.equalsIgnoreCase("true") || performExplicitScroll.equalsIgnoreCase("y"))){
			performExplicitScroll = "Y";
		}
		else{
			performExplicitScroll = "N";
		}
		
		if (KeywordUtilities.isEmptyString(elementSourceLocator)){
			logger.error("first element identifier is not present");
			testCaseExecutionResult.setMessage("first element identifier is not present");
			return testCaseExecutionResult;
		}else{
			 if (elementSourceLocator.startsWith(OBJECT_SPECIFIER))
			 {
				 elementSourceLocator = elementSourceLocator.substring(OBJECT_SPECIFIER.length(), elementSourceLocator.length());
			 }
		}
		
		if (KeywordUtilities.isEmptyString(elementDestinationLocator)){
			logger.error("second  element identifier is not present");
			testCaseExecutionResult.setMessage("second  element identifier is not present");
			return testCaseExecutionResult;
		}else{
			if (elementDestinationLocator.startsWith(OBJECT_SPECIFIER))
			 {
				elementDestinationLocator = elementDestinationLocator.substring(OBJECT_SPECIFIER.length(), elementDestinationLocator.length());
			 }			
		}
		testCaseExecutionResult.setValid(true);
		testCaseExecutionResult.setStatus(1);
		return testCaseExecutionResult;
	}

	@Override
	public TestcaseExecutionResultVO validateObject(String... params) {
		if (webDriver == null) {
			logger.error(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}
		
		try {
			elementSource=KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, elementSourceLocator,elementSourceInstance, userName);
		} catch (Exception e) {

			logger.error("Error while finding element to be dragged");
			testCaseExecutionResult.setMessage("Error while finding element to be dragged");
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}
		
		try {
			elementDestnation=KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, elementDestinationLocator,elementDestinationInstance, userName);
		} catch (Exception e) {
			logger.error("Error while finding element to be dragged");
			testCaseExecutionResult.setMessage("Error while finding element to be dragged");
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setValid(true);
		testCaseExecutionResult.setObject(elementSourceLocator);
		return testCaseExecutionResult;
		
	}

	@Override
	public TestcaseExecutionResultVO executeScript(String... params) {
		
		if(elementSource!=null && performExplicitScroll.equals("Y")){
			ScrollToElement scrolToElement = new ScrollToElement();
			String[] params1 = new String[5];
			params1[0]=elementSourceLocator;
			params1[1]="";
			params1[2]="";
			params1[3]="";
			params1[4]="";
			try {
				((JavascriptExecutor)webDriver).executeScript("window.focus();");
			} catch (Exception e1){}

			
			scrolToElement.execute(scriptName, webDriver, configurationMap, workBookMap, userName, params1);			
		}
		
		if(performusingMouseAction.equalsIgnoreCase("Y") || performusingMouseAction.equalsIgnoreCase("Yes")|| performusingMouseAction.equalsIgnoreCase("true") )
		{
			try {

					Action mouseAction = new Actions(webDriver).clickAndHold(elementSource).moveToElement(elementDestnation).click().build();
					mouseAction.perform();				
					testCaseExecutionResult.setStatus(1);
					return testCaseExecutionResult;	} catch (Exception e) {
						logger.error("Error while perform Drage and Drop");	
						testCaseExecutionResult.setMessage("Error while perform Drage and Drop");
							
					}
		}else if(performusingMouseAction.equalsIgnoreCase("WithOffsetFromDestinationElement")){
			
			 String offset[] = moveXYOffset.split("\\|");
			 
			int xOffset = 0;
			int yOffset =0;
			try{
				xOffset = Integer.parseInt(offset[0]);
			}catch(Exception e){logger.error("Exception::",e);}
			try{
				yOffset = Integer.parseInt(offset[1]);
			}catch(Exception e){logger.error("Exception::",e);}			
			try{
				
			Action mouseAction = new Actions(webDriver).clickAndHold(elementSource).moveToElement(elementDestnation).build();
			mouseAction.perform();
			new Actions(webDriver).moveByOffset(xOffset, yOffset).perform();			
			Thread.sleep(500);
			//mouseAction = new Actions(webDriver).release(elementSource).build();
			//mouseAction.perform();
			new Actions(webDriver).release().perform();
			 new Actions(webDriver).click().perform();
			
			testCaseExecutionResult.setStatus(1);
			return testCaseExecutionResult;	} catch (Exception e) {
				logger.error("Error while perform Drage and Drop");
				testCaseExecutionResult.setStatus(0);
						testCaseExecutionResult.setMessage("Error while perform Drage and Drop");
						return testCaseExecutionResult;
						
				}
		}
		
		else if(performusingMouseAction.equalsIgnoreCase("jquery")){
			
			String script1 =  "(function( $ ) {         $.fn.simulateDragDrop = function(options) {                 return this.each(function() {  "+
			"  new $.simulateDragDrop(this, options);                 });         };         $.simulateDragDrop = function(elem, options) {                 this.options = "+
			"options;                 this.simulateEvent(elem, options);         };         $.extend($.simulateDragDrop.prototype, {                 simulateEvent: function(elem, "+
			"options) {                         /*Simulating drag start*/                         var type = 'dragstart';                         var event = this.createEvent"+ 
			"(type);                         this.dispatchEvent(elem, type, event);                          /*Simulating drop*/                         type = 'drop'; "+ 
			"          var dropEvent = this.createEvent(type, {});                         dropEvent.dataTransfer = event.dataTransfer;                         this.dispatchEvent"+ 
			"($(options.dropTarget)[0], type, dropEvent);                          /*Simulating drag end*/                         type = 'dragend';                         var "+ 
			"dragEndEvent = this.createEvent(type, {});                         dragEndEvent.dataTransfer = event.dataTransfer;                         this.dispatchEvent(elem, "+
			"type, dragEndEvent);                 },                 createEvent: function(type) {                         var event = document.createEvent(\"CustomEvent\"); "+ 
			"event.initCustomEvent(type, true, true, null);                         event.dataTransfer = {                                 data: {           "+ 
			"             },                                 setData: function(type, val){                                         this.data[type] = val;                    "+ 
			"     },                                 getData: function(type){                                         return this.data[type];                                 }   "+
			"                   };                         return event;                 },                 dispatchEvent: function(elem, type, event) {                         if"+
			"(elem.dispatchEvent) {                                 elem.dispatchEvent(event);                         }else if( elem.fireEvent ) {                    "+
			"elem.fireEvent(\"on\"+type, event);                         }                 }         }); })(jQuery);"+
			//"$('a:contains(\"Maker, Maker (Maker)\")').simulateDragDrop({dropTarget: 'span:contains(\"Maker\")'}); "+
			"var ele1 = $(arguments[0]); var ele2 = $(arguments[1]); ele1.simulateDragDrop({dropTarget: ele2})";
			try {
				((JavascriptExecutor)webDriver).executeScript(script1,elementSource,elementDestnation);
				testCaseExecutionResult.setStatus(1);
			}catch (Exception e) {
				logger.error("Error while perform Drage and Drop");
				testCaseExecutionResult.setStatus(0);
					testCaseExecutionResult.setMessage("Error while perform Drage and Drop");
			}
			return testCaseExecutionResult;
			
			
		}else{
				try {
					Action dragDrop = new Actions(webDriver).dragAndDrop(elementSource, elementDestnation).build();
					dragDrop.perform();
					testCaseExecutionResult.setStatus(1);
					return testCaseExecutionResult; } catch (Exception e) {
						logger.error("Error while perform Drage and Drop");
						testCaseExecutionResult.setMessage("Error while perform Drage and Drop");
							}
			}
		
		return testCaseExecutionResult;
	}

}
