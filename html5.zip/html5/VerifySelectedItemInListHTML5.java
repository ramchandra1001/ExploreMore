package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.EMPTY_STRING;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;

/**
 *This Keyword will verify selected item in drop down
 */
public class VerifySelectedItemInListHTML5 extends AbstractKeyword  {
	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();
	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
	/**
	 * To find drop down
	 */
	private String sList =  null;
	/**
	 * Value to be verified, Default � BLANK,
	 */
	private String svalueToVerify = null;
	/**
	 * This is web element
	 */
	private WebElement listObjectElement;
	
	private String controltype = null;
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */

	public TestcaseExecutionResultVO executeScript(String... params) {

		String sListName = "kendoDropDownList";		
		String sfinalStatus="FAIL";
		String sgetBrowser=EMPTY_STRING;
		if(controltype.equalsIgnoreCase("COMBOLIST")){
			sListName = "kendoComboBox";
		}else{
			sListName = "kendoDropDownList";	
		}
		
		try {
				sgetBrowser = ((JavascriptExecutor)webDriver).executeScript("return navigator.userAgent").toString();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			sgetBrowser=EMPTY_STRING;
		}
		String mySelector=
			"f(arguments[0]);																								" +
			"function f(ELE)																						" + 
			"{																									" +
			"	var svalueToSelect = \"\";													" +
			"	var listName = \""+sListName+ "\";																" + 
			"	try																								" +
			"	{																								" +
			"		var mObj = ELE;													" +
			"		var mkobj = $(mObj);																		" +
			"		var listDataObject = mkobj.data(listName);													" +
			//"		alert(listDataObject);" +
			"		var allItems = listDataObject.items();" +
			
			"		var index = listDataObject.text();	" +
			"		svalueToSelect = index; 												" +
			"	}																								" +
			"	catch(e)																						" +
			"	{																								" +
			"		svalueToSelect='FAIL'+ e.description;																" +
			"	}																								" +
			"	return svalueToSelect ;																					" +
			"}" ;
	
		
		sfinalStatus="FAIL";
		
		sfinalStatus="FAIL";

		if(sgetBrowser.contains("Firefox")){
			mySelector=mySelector.replaceAll("innerText", "textContent");
		}
		
		try {
				sfinalStatus =((JavascriptExecutor)webDriver).executeScript("var a= "+mySelector+"return a;",listObjectElement).toString();
		} catch (Exception e){
				sfinalStatus="FAIL";
		}

		if(sfinalStatus.contains("FAIL")){
				logger.error(sfinalStatus.replaceAll("FAIL", ""));
				testCaseExecutionResult.setMessage(sfinalStatus.replaceAll("FAIL", ""));
				return testCaseExecutionResult;
		}else{
			if (sfinalStatus.equalsIgnoreCase(svalueToVerify)){
				testCaseExecutionResult.setConfigUpdate(true);
				testCaseExecutionResult.setStatus(1);
				return testCaseExecutionResult;
			}else{
				logger.error("expected value is"+svalueToVerify +" and actual value is"+sfinalStatus);
				testCaseExecutionResult.setMessage("expected value is"+svalueToVerify +" and actual value is"+sfinalStatus );
				return testCaseExecutionResult;
			}
			
		}
		
	}
	
	/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters
	 *              - sList -svalueToVerify
	 * 
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateKeyword(String... params) {

		if(params!=null){			
			sList=params[0];
			svalueToVerify=params[1];	
			controltype=params[2];
		}
		else{
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setTestData(params[0]+DELIMITER+params[1]);
		if(EMPTY_STRING.equals(params[0]))
		{
			logger.error("list box locator not given");
			testCaseExecutionResult.setMessage("list box locator not given");
			return testCaseExecutionResult;
		}
		if(EMPTY_STRING.equals(params[1]))
		{
			logger.error("value to be verified  not given");
			testCaseExecutionResult.setMessage("value to be verified  not given");
			return testCaseExecutionResult;
		}
		
		if(EMPTY_STRING.equals(controltype))
		{
			controltype = "DROPDOWNLIST";
		}
	
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}

/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... params) {

		if (webDriver == null) {
			logger.error(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}

		if (sList.startsWith(OBJECT_SPECIFIER)) {
			sList = sList.substring(OBJECT_SPECIFIER.length(), sList.length());
		} 

		listObjectElement=KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, sList,"", userName);
		testCaseExecutionResult.setExpectedResultFlag(true);
		
		if (listObjectElement==null) {
			logger.error("List box not found");
			testCaseExecutionResult.setObjectError(true);
			testCaseExecutionResult.setValid(false);
			testCaseExecutionResult.setMessage("List box not found");
			
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setObject(sList);
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}
}
