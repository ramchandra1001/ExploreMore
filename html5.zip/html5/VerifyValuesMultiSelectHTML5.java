package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.EMPTY_STRING;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;
/** 
 * This Keyword will verify available option in multiselect control
 */
public class VerifyValuesMultiSelectHTML5 extends AbstractKeyword  {
	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();
	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
	/**
	 * Multiselect Object Locator
	 */
	private String sList = null;	
	/**
	 * This is a webelement
	 */
	private WebElement listObjectElement;
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO executeScript(String... params) {

		try{
			String []valuesToVerify = params[1].split(";");
			String valueNotAvaliable =EMPTY_STRING;					
			List <WebElement> optionElements = new ArrayList <WebElement>();
			if (listObjectElement != null){
				optionElements = listObjectElement.findElements(By.tagName("OPTION"));
			}else{
				logger.error("error while getting options");
				testCaseExecutionResult.setMessage("error while getting options");
				return testCaseExecutionResult;
			}					
			//System.out.println(optionElements.size());					
			if (optionElements.size()!=0)
			{
				for (String value :valuesToVerify)
				{
					boolean found = false;
					for(WebElement option :optionElements)
					{
						String text = option.getAttribute("text");
						if(value.equalsIgnoreCase(text))
						{							
							found = true;
							break;
						}
					}
					if(!found)
					{
						valueNotAvaliable = valueNotAvaliable + value+ ",";	
					}
				}
			}
			else{
				logger.error("error while getting options");
				testCaseExecutionResult.setMessage("error while getting options");
				return testCaseExecutionResult;
			}

			if (!EMPTY_STRING.equalsIgnoreCase(valueNotAvaliable))
			{
				logger.error("List Option "+ valueNotAvaliable +" not found  in list box");
				testCaseExecutionResult.setMessage("List Option "+ valueNotAvaliable +" not found  in list box");					
				return testCaseExecutionResult;
			}

		}catch(Exception e){
			logger.error("Error while verifing value from multiSelect");
			testCaseExecutionResult.setMessage("Error while verifing value from multiSelect");
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setStatus(PASS);			 
		return testCaseExecutionResult;
	}

	/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters
	 *            - sList -
	 * 
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */



	public TestcaseExecutionResultVO validateKeyword(String... params) {

		if(params!=null){
			sList=params[0];
		}
		else{
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setTestData(params[0]+DELIMITER+params[1]);
		if("".equals(params[0])){
			logger.error("list box locator not given");
			testCaseExecutionResult.setMessage("list box locator not given");
			return testCaseExecutionResult;
		}		
		if("".equals(params[1])){
			logger.error("options not given");
			testCaseExecutionResult.setMessage("options not given");
			return testCaseExecutionResult;
		}

		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}
	/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... params) {

		if (webDriver == null) {
			logger.error(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;	}

		if (sList.startsWith(OBJECT_SPECIFIER)) {	
			sList = sList.substring(OBJECT_SPECIFIER.length(), sList.length());	} 
		testCaseExecutionResult.setExpectedResultFlag(true);

		listObjectElement=KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, sList,"", userName);
		if (listObjectElement==null){
			testCaseExecutionResult.setObjectError(true);
			logger.error("List box not found");
			testCaseExecutionResult.setMessage("List box not found");
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;	
		}

		testCaseExecutionResult.setObject(sList);
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}


}
