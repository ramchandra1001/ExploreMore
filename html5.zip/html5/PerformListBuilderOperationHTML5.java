package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.EMPTY_STRING;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;
/**
 * This Keyword performs operation on List Buider control.
 */
public class PerformListBuilderOperationHTML5 extends AbstractKeyword{
	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();
	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
	/**
	 * Value need to move from left or right  box (multiple values spereated by �;�) 
	 */
	private String svalueToSelect  =  null;
	/**
	 * MOVELEFT or  MOVERIGHT MOVELEFTOALL or MOVERIGHTOALL 
	 */
	private String operationToPerform = null;	
	/**
	 * List builder locator
	 */
	private String ListBuilder =  null;
	/**
	 * List builder left box locator
	 */
	private String ListBuilder_Left =  null;
	/**
	 * List builder right box locator
	 */
	private String ListBuilder_Right = null;
	/**
	 * >>,>,<,<<  locator
	 */
	private String ListButtons =  null;
	private String caseSensitiveFlag =  null;
	/**
	 * Following  are webelements
	 */
	private WebElement listBuilderElement=null;
	private WebElement listBuilderElement_Left=null;
	private WebElement listBuilderElement_Right=null;
	/**
	 * Following  are button objects
	 */
	private WebElement listBuilderElement_RightRightButton=null;
	private WebElement listBuilderElement_RightButton=null;
	private WebElement listBuilderElement_LeftButton=null;
	private WebElement listBuilderElement_LeftLeftButton=null;
	private WebElement expectedListBox = null;
	private WebElement expectedButton = null;
	//private WebElement listBuilderElement_UpButton;
	//private WebElement listBuilderElement_DownButton;


	@Override
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */

	public TestcaseExecutionResultVO executeScript(String... params) {
		
		try{
			String svalueToSelect = params[0];

			String []svaluesToSelect = svalueToSelect.split(";");				
			//// shift all option to 
			if (operationToPerform.equalsIgnoreCase("MoveRightAll") )
			{
				if (listBuilderElement_RightRightButton == null)
				{
					logger.error("Shfit all to right button not found");
					testCaseExecutionResult.setMessage("Shfit all to right button not found");
					return testCaseExecutionResult;
				}
				else
				{
					
					try{((JavascriptExecutor)webDriver).executeScript("arguments[0].click(); ",listBuilderElement_RightRightButton);
					}catch(Exception e){listBuilderElement_RightRightButton.click();}
				}

				testCaseExecutionResult.setStatus(1);
				return testCaseExecutionResult;
			}	

			if (operationToPerform.equalsIgnoreCase("MoveLeftAll") )
			{
				if (listBuilderElement_LeftLeftButton == null)
				{
					logger.error("Shfit all to right button not found");
					testCaseExecutionResult.setMessage("Shfit all to right button not found");
					return testCaseExecutionResult;
				}
				else
				{
					
					try{((JavascriptExecutor)webDriver).executeScript("arguments[0].click(); ",listBuilderElement_LeftLeftButton);
					}catch(Exception e){listBuilderElement_LeftLeftButton.click();}
				}
				testCaseExecutionResult.setStatus(1);
				return testCaseExecutionResult;
			}

			if (operationToPerform.equalsIgnoreCase("MoveRight") )
			{	
				expectedListBox = listBuilderElement_Left;
				expectedButton = listBuilderElement_RightButton;				
			}else if (operationToPerform.equalsIgnoreCase("MoveLeft") ){
				expectedListBox = listBuilderElement_Right;
				expectedButton = listBuilderElement_LeftButton;
			}else{
				logger.error("correct operation not provided");
				testCaseExecutionResult.setMessage("correct operation not provided");
				return testCaseExecutionResult;
			}	
			
			if (expectedListBox == null){
				logger.error("List Box not found");
				testCaseExecutionResult.setMessage("List Box not found") ;
				return testCaseExecutionResult;
			}	

			if (expectedButton == null){
				logger.error("Shfit to  button not found");
				testCaseExecutionResult.setMessage("Shfit to  button not found") ;
				return testCaseExecutionResult;
			}	
			
			boolean isIEDriver = false;
			
			if(webDriver instanceof  InternetExplorerDriver){
				isIEDriver = true;
			}
			
			
				
			//List <WebElement> avilableOptions =   expectedListBox.findElements(By.tagName("li"));
			List <WebElement> requiredOptions = new ArrayList <WebElement>();
			for(String valu :svaluesToSelect)
			{
				String script ="";
				
				if(caseSensitiveFlag.equalsIgnoreCase("Y")||caseSensitiveFlag.equalsIgnoreCase("YES")||caseSensitiveFlag.equalsIgnoreCase("TRUE")){
					script = "var b = arguments[0].getElementsByTagName(\"li\");" +
							"var eleList=\""+valu+"\";"+
							"for (var i=0; i<b.length; i++){" +
							"    if( b[i].innerText == eleList){" +
							"           return b[i];" +
							"     }" +
							" }" +				
							" return null; ";	
				
				}else{
					 script = "var b = arguments[0].getElementsByTagName(\"li\");" +
					"var eleList=\""+valu+"\";"+
					"for (var i=0; i<b.length; i++){" +
					"    if( b[i].innerText.toUpperCase()== eleList.toUpperCase()){" +
					"           return b[i];" +
					"     }" +
					" }" +				
					" return null; ";	
				}
				
				if(!isIEDriver)
				{
					script = script.replaceAll("innerText", "textContent");
				}
				
				boolean found = false;
				WebElement reqEle = null;
				try{//((JavascriptExecutor)webDriver).executeScript(script,expectedListBox);
					reqEle = (WebElement)(((JavascriptExecutor)webDriver).executeScript(script,expectedListBox));
				}catch(Exception e){}
				if(reqEle!=null){
					requiredOptions.add(reqEle);
					found = true;
				}				
				
				/*for(WebElement opt :avilableOptions)
				{
					if (opt.getText().equalsIgnoreCase(valu))
					{
						requiredOptions.add(opt);
						found = true;
					}
				}*/
				if (!found)
				{
					logger.error("List Option "+valu +" not found ");
					testCaseExecutionResult.setMessage("List Option "+valu +" not found ");					
					return testCaseExecutionResult;
				}							
			}
			for(WebElement reqOpt:requiredOptions)
			{
				
				try{((JavascriptExecutor)webDriver).executeScript("arguments[0].click(); ",reqOpt);
				}catch(Exception e){reqOpt.click();}
				Thread.sleep(1000);
					
				try{((JavascriptExecutor)webDriver).executeScript("arguments[0].click(); ",expectedButton);
				}catch(Exception e){expectedButton.click();}
			}
			testCaseExecutionResult.setStatus(1);
			return testCaseExecutionResult;								
		}catch(Exception  e)
		{
			logger.error("Error while perform operation");		
			testCaseExecutionResult.setMessage("Error while perform operation")	;		
		}
		return testCaseExecutionResult;				

	}

	/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters listOfParameters[0]
	 *              (Mandatory) - svalueToSelect-operationToPerform-ListBuilder-ListBuilder_Left
	 *                            ListBuilder_Right-ListButtons
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */


	public TestcaseExecutionResultVO validateKeyword(String... params) {
		if(params!=null)
		{
			svalueToSelect  =  params[0];
			operationToPerform=  params[1];
			ListBuilder =  params[2];
			ListBuilder_Left =  params[3];
			ListBuilder_Right =  params[4];
			ListButtons =  params[5];
			caseSensitiveFlag=  params[6];
		}
		else{
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setTestData(svalueToSelect+DELIMITER+operationToPerform+DELIMITER+
				ListBuilder+DELIMITER+ListBuilder_Left+DELIMITER+ ListBuilder_Right+DELIMITER+ ListButtons );
		
		if (EMPTY_STRING.equalsIgnoreCase(caseSensitiveFlag) )
		{
			caseSensitiveFlag = "N";
		}
		
		if (EMPTY_STRING.equalsIgnoreCase(operationToPerform) )
		{
			logger.error("parameters not correct : Param 2 (Operation to perform)");
			testCaseExecutionResult.setMessage("parameters not correct : Param 2 (Operation to perform)");
			return testCaseExecutionResult;
		}  

		if ((operationToPerform.equalsIgnoreCase("MoveRight")||  operationToPerform.equalsIgnoreCase("MoveLeft"))&& EMPTY_STRING.equalsIgnoreCase(svalueToSelect))
		{
			logger.error("parameters not correct");
			testCaseExecutionResult.setMessage("parameters not correct");
			return testCaseExecutionResult;
		} 

		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}


	/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... params) {

		if (webDriver == null) {
			logger.error(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}

		if (EMPTY_STRING.equalsIgnoreCase(ListBuilder)){
			ListBuilder = "xpath=//div[@class='sg-list-builder' or @class='fis-list-builder']";
		}
		else{		
			if (ListBuilder.startsWith(OBJECT_SPECIFIER)) {	
				ListBuilder = ListBuilder.substring(OBJECT_SPECIFIER.length(), ListBuilder.length());
			} }		

		listBuilderElement=KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, ListBuilder,"", userName);
		if (listBuilderElement==null){
			logger.error("List box not found");
			testCaseExecutionResult.setMessage("List box not found");
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}


		////********************* verify object present Left Box *****************************////// 

		if ( !EMPTY_STRING.equals(ListBuilder_Left))
		{			
			if (ListBuilder_Left.startsWith(OBJECT_SPECIFIER)) {	
				ListBuilder_Left = ListBuilder_Left.substring(OBJECT_SPECIFIER.length(), ListBuilder_Left.length());
			} 			
			listBuilderElement_Left = KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, ListBuilder_Left,"", userName);
		}
		else
		{
			try {
				listBuilderElement_Left = KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, "xpath=//div[@class='sg-list-builder-left' or @class='fis-list-builder-left']","", userName);
				//listBuilderElement_Left = listBuilderElement.findElement(By.className("sg-list-builder-left,fis-list-builder-left"));
			} catch (Exception e) {
				listBuilderElement_Left = null;
			}
		}		
		if (listBuilderElement_Left==null){
			logger.error("Left List box not found");
			testCaseExecutionResult.setMessage("Left List box not found");
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}

		// End Verification for Left Box  //


		//// *****************verify object present Right Box ******************///// 

		if ( !EMPTY_STRING .equals(ListBuilder_Right) )
		{			
			if (ListBuilder_Right.startsWith(OBJECT_SPECIFIER)) {	
				ListBuilder_Right = ListBuilder_Right.substring(OBJECT_SPECIFIER.length(), ListBuilder_Right.length());
			} 			
			listBuilderElement_Right = KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, ListBuilder_Right,"", userName);
		}
		else
		{
			try {
				listBuilderElement_Right = KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, "xpath=//div[@class='sg-list-builder-right' or @class='fis-list-builder-right']","", userName);
				//listBuilderElement_Right = listBuilderElement.findElement(By.className("sg-list-builder-right,fis-list-builder-right"));
			} catch (Exception e) {
				listBuilderElement_Right = null;
			}
		}		
		if (listBuilderElement_Right==null){
			logger.error("Right List box not found");
			testCaseExecutionResult.setMessage("Right List box not found");
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}

		// End Verification for right Box /////


		///*********** verify button objects *****************///
		if ( !EMPTY_STRING.equals(ListButtons))
		{			
			if (ListButtons.startsWith(OBJECT_SPECIFIER)) {	
				ListButtons = ListButtons.substring(OBJECT_SPECIFIER.length(), ListButtons.length());
			} 	
			String [] ListButtonsArray = ListButtons.split(";") ;

			if (!EMPTY_STRING.equals(ListButtonsArray[0]))
			{
				listBuilderElement_RightRightButton = KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, ListButtonsArray[0],"", userName);
			}else{
				listBuilderElement_RightRightButton = KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, "xpath=//div[@class='sg-list-builder-right-right-icon' or @class='fis-list-builder-right-right-icon']","", userName);
			//	listBuilderElement_RightRightButton = listBuilderElement.findElement(By.className("sg-list-builder-right-right-icon,fis-list-builder-right-right-icon"));
			}


			if (!EMPTY_STRING .equals(ListButtonsArray[1]) )
			{
				listBuilderElement_RightButton = KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, ListButtonsArray[1],"", userName);
			}else{
				listBuilderElement_RightButton = KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, "xpath=//div[@class='sg-list-builder-right-icon' or @class='fis-list-builder-right-icon']","", userName);
			//	listBuilderElement_RightButton = listBuilderElement.findElement(By.className("sg-list-builder-right-icon,fis-list-builder-right-icon")); 
			}


			if (!EMPTY_STRING.equals(ListButtonsArray[2]) )
			{
				listBuilderElement_LeftLeftButton = KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, ListButtonsArray[2],"", userName);
			}else{
				listBuilderElement_LeftLeftButton = KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, "xpath=//div[@class='sg-list-builder-left-left-icon' or @class='fis-list-builder-left-left-icon']","", userName);
				//listBuilderElement_LeftLeftButton = listBuilderElement.findElement(By.className("sg-list-builder-left-left-icon,fis-list-builder-left-left-icon"));	
			}


			if (!EMPTY_STRING.equals(ListButtonsArray[3]))
			{
				listBuilderElement_LeftButton = KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, ListButtonsArray[3],"", userName);
			}else{
				listBuilderElement_LeftButton = KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, "xpath=//div[@class='sg-list-builder-left-icon' or @class='fis-list-builder-left-icon']","", userName);
				//listBuilderElement_LeftButton = listBuilderElement.findElement(By.className("sg-list-builder-left-icon,fis-list-builder-left-icon"));	
			}


			/*if (EMPTY_STRING != ListButtonsArray[4]){
					listBuilderElement_UpButton = KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, ListButtonsArray[4],"");
				}else{
					listBuilderElement_UpButton = listBuilderElement.findElement(By.className("sg-list-builder-up-icon"));}


				if (EMPTY_STRING != ListButtonsArray[5])
				{
					listBuilderElement_DownButton = KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, ListButtonsArray[5],"");
				}else{
					listBuilderElement_DownButton = listBuilderElement.findElement(By.className("sg-list-builder-down-icon"));}*/
		}
		else
		{
			/*listBuilderElement_RightRightButton = listBuilderElement.findElement(By.className("sg-list-builder-right-right-icon"));
			listBuilderElement_RightButton = listBuilderElement.findElement(By.className("sg-list-builder-right-icon"));
			listBuilderElement_LeftLeftButton = listBuilderElement.findElement(By.className("sg-list-builder-left-left-icon"));
			listBuilderElement_LeftButton = listBuilderElement.findElement(By.className("sg-list-builder-left-icon"));*/
			
			
			listBuilderElement_RightRightButton = listBuilderElement.findElement(By.xpath("//div[@class='sg-list-builder-right-right-icon' or @class='fis-list-builder-right-right-icon']"));
			listBuilderElement_RightButton = listBuilderElement.findElement(By.xpath("//div[@class='sg-list-builder-right-icon' or @class='fis-list-builder-right-icon']"));
			listBuilderElement_LeftLeftButton = listBuilderElement.findElement(By.xpath("//div[@class='sg-list-builder-left-left-icon' or @class='fis-list-builder-left-left-icon']"));
			listBuilderElement_LeftButton = listBuilderElement.findElement(By.xpath("//div[@class='sg-list-builder-left-icon' or @class='fis-list-builder-left-icon']"));
			
			
			//listBuilderElement_UpButton = listBuilderElement.findElement(By.className("sg-list-builder-up-icon"));
			//listBuilderElement_DownButton = listBuilderElement.findElement(By.className("sg-list-builder-down-icon"));
		}


		testCaseExecutionResult.setObject(svalueToSelect);
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;

	}
}
