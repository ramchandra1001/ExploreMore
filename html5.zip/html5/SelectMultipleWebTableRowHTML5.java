package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_SEARCH_VALUE_NOT_FOUND;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_TABLE_COLS_NOT_PASSED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_TABLE_COLUMNS_NOT_FOUND;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_TABLE_LOCATOR_NOT_PASSED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_TABLE_NOT_FOUND;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_TABLE_ROW_NOT_FOUND;
import static com.sungard.ktt.business.keywords.ErrorMessages.MESSAGE_CHKBOX_ALREADY_CHECKED;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.EMPTY_STRING;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS_STEP_STATUS;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;
/**
 *  @author Gyaneshwar.Nandanwar on 25-Oct-2013
 *  This keyword selects multiple web table rows by selecting checkboxes present in first column.
 */
public class SelectMultipleWebTableRowHTML5 extends AbstractKeyword 
{
	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();
	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
	/**
	 * This is webelement
	 */
	private WebElement Element = null;
	/**
	 * This is web element
	 */
	private WebElement elementTable=null;
	/**
	 * To find Table - refer Data grid locator
	 */
	private String sTableLocator = null;
	/**
	 * column name or column number (This is mandatory when Row number is not provided), 
	 * multiple values separated by pipe (|)
	 * If this value is <ALL> then it will select all the rows of a table and Param3 and Param4 would be optional
	 */
	private String sColumnName = null;
	/**
	 * Column value (This is mandatory when Row number is not provided), 
	 * multiple values separated by pipe (|)
	 */
	private String sColumnValues = null;
	/**
	 * Row number to select, (This is mandatory when column name and column value are blank), 
	 * multiple values separated by pipe (|)
	 */
	private String sRowNumbersToSelect = null;
	/**
	 * Header row number if header has multiple rows, 
	 * by default it will take first row 
	 */
	private String sColHeaderStrtRowNum=null;
	/**
	 * It will store the row numbers of selected rows,
	 * pipe separated values
	 */
	private String sVariableName=null;

	public static final String KENDO_GRID_NAME="KendoGridName";
	public static final String DEFAULT_KENDO_GRID_NAME="kendoGrid";

	@Override
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO executeScript(String... listOfParameters)
	{	
		String table=sTableLocator;	
		try {
			elementTable=KeywordUtilities.getWebElement(webDriver, table);
			Element = KeywordUtilitiesHTML5.kendoDataControl(webDriver, elementTable,"grid");
		} catch (Exception e) {
			logger.error("Unable TO Find Element: "+ table);
			testCaseExecutionResult.setMessage("Unable TO Find Element: "+ table);
		}

		if (KeywordUtilities.isEmptyString(sColHeaderStrtRowNum))
		{
			sColHeaderStrtRowNum="0";
		}
		if (KeywordUtilities.isEmptyString(sVariableName))
		{
			sVariableName="RowNumber";
		}

		String sGridName=DEFAULT_KENDO_GRID_NAME;
		try {
			sGridName =configurationMap.get(KENDO_GRID_NAME);
		} catch (Exception e3) {
			sGridName=DEFAULT_KENDO_GRID_NAME;
		}

		if(sGridName==null)
		{
			sGridName=DEFAULT_KENDO_GRID_NAME;
		}
		String numCols[] = sColumnName.trim().split("\\|");
		int iColFlag=1;
		try {
			Integer.parseInt(numCols[0]);
		} catch (NumberFormatException e3) {
			iColFlag=0;
		}
		String sfinalStatus=EMPTY_STRING;		
		String SelectMultWebTableRow=EMPTY_STRING;
		//System.out.println();	
		try {
			String columnNumbers="";
			String RowNumbers="";
			if (KeywordUtilities.isEmptyString(sRowNumbersToSelect)) {
				if (!sColumnName.equalsIgnoreCase("<ALL>")) {
					if (iColFlag==0) {
						columnNumbers = KeywordUtilitiesHTML5.returnColumnNumber(webDriver, Element, sColumnName, sColHeaderStrtRowNum,sGridName);
						if (columnNumbers.equalsIgnoreCase("COL_ERR")) {
							logger.error(ERROR_TABLE_COLUMNS_NOT_FOUND);
							testCaseExecutionResult.setMessage(ERROR_TABLE_COLUMNS_NOT_FOUND);
							return testCaseExecutionResult;
						}					
					}
					else
						columnNumbers=sColumnName;
					String[] splitColumnNumbers = columnNumbers.split("\\|");
					String colNumbers="";
					for (int i=0;i<splitColumnNumbers.length;i++){
						int colNum = Integer.parseInt(splitColumnNumbers[i]);
						colNum--;
						columnNumbers=Integer.toString(colNum);
						if (i==0)
							colNumbers=columnNumbers;
						else
							colNumbers=colNumbers+"|"+columnNumbers;
					}

					RowNumbers = KeywordUtilitiesHTML5.returnRowNumbers(webDriver, Element, colNumbers, sColumnValues, sGridName);
					if (RowNumbers.contains("ROW_ERR")) {
						logger.error(ERROR_TABLE_ROW_NOT_FOUND);
						testCaseExecutionResult.setMessage(ERROR_TABLE_ROW_NOT_FOUND);
						return testCaseExecutionResult;
					}
					configurationMap.put(sVariableName,RowNumbers);
					testCaseExecutionResult.setConfigUpdate(true);
				}
				else
					columnNumbers= sColumnName;
			}
			else
				RowNumbers=sRowNumbersToSelect;

			SelectMultWebTableRow=
					"	  return selectWebtableRow(arguments[0]);																						"+
							"	  function selectWebtableRow(HTML5_Table_obj)																			"+
							"	  {																							            				"+
							"		try																												"+
							"		{" +	
							"	   	var columnNumber=\""+columnNumbers+"\";	"+
							"	   	var rowNumber=\""+RowNumbers+"\";	"+
							"		var HTML5_Table_Kendo=$(HTML5_Table_obj).data('kendoGrid');"+
							"		if (columnNumber=='<ALL>')"+
							"		{"+
							" 			var TableHeader = HTML5_Table_Kendo.thead;	"+
							"			var HeaderColumnRow=TableHeader.find('tr:eq(\""+sColHeaderStrtRowNum+"\")');"+
							"			var column_checkbox= HeaderColumnRow.find('th:eq(0)').find('input[type=checkbox]');"+
							"			if (column_checkbox.length>0 && column_checkbox.prop('checked')==false)"+
							"			{"+
							"				column_checkbox.trigger('click');"+
							"			}		"+
							"			else"+
							"				return (\""+MESSAGE_CHKBOX_ALREADY_CHECKED+"\");"+
							"		}"+
							"		else"+
							"		{"+
							" 			var TableData = HTML5_Table_Kendo.tbody;	"+
							"			var SplitedRowNumber=rowNumber.split(\"|\");"+
							"			for (var i=0;i<SplitedRowNumber.length;i++)"+
							"			{"+
							"				var rowNumber=SplitedRowNumber[i]-1;"+
							"				row = TableData.find('tr:eq('+rowNumber+')');"+
							"				var row_checkbox= row.find('td:eq(0)').find('input[type=checkbox]');"+
							"				if (row_checkbox.length>0 && row_checkbox.prop('checked')==false)"+
							"				{"+
							"					row_checkbox.trigger('click');"+
							"				}		"+
							"				else"+
							"					return (\""+MESSAGE_CHKBOX_ALREADY_CHECKED+"\");"+
							"			}"+
							"			"+
							"		}"+	
							"		}catch(error1)																					"+
							"		{																								"+
							"			return (error1.description);																"+
							"		}																								"+
							"		return 'PASS';"+
							"		}";

			//sgetBrowser = ((JavascriptExecutor)webDriver).executeScript("return navigator.userAgent").toString();
		} catch (Exception e1) {
			logger.error("Exception::",e1);
			//sgetBrowser=EMPTY_STRING;
		}

		try{
			/*if(sgetBrowser.contains("MSIE")) 
			{
				sfinalStatus = (String)((JavascriptExecutor)webDriver).executeScript(SelectMultWebTableRow.toString(), Element);
			}
			else
			{
				SelectMultWebTableRow=SelectMultWebTableRow.replaceAll("innerText", "textContent");
				sfinalStatus = (String)((JavascriptExecutor)webDriver).executeScript(SelectMultWebTableRow.toString(), Element);
			}*/
			sfinalStatus = (String)((JavascriptExecutor)webDriver).executeScript(SelectMultWebTableRow.toString(), Element);
		} catch (Exception e) {
			logger.error("Exception::"+e.getCause().toString());
			testCaseExecutionResult.setMessage(e.getCause().toString());
			return testCaseExecutionResult;
		}

		if (sfinalStatus.trim().equalsIgnoreCase(PASS_STEP_STATUS) || sfinalStatus.trim().equalsIgnoreCase(MESSAGE_CHKBOX_ALREADY_CHECKED))
		{
			testCaseExecutionResult.setMessage(sfinalStatus);
			testCaseExecutionResult.setStatus(PASS);
			return testCaseExecutionResult;
		} else
		{
			logger.error(sfinalStatus);
			testCaseExecutionResult.setMessage(sfinalStatus);
			return testCaseExecutionResult;
		}
	}

	@Override
	/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters listOfParameters[0]
	 *              (Mandatory) - sTableLocator -sColumnName-sColumnValues-sRowNumbersToSelect-sColHeaderStrtRowNum-sVariableName
	 * 
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateKeyword(String... listOfParameters)
	{
		// check for required parameter count
		if (listOfParameters != null)
		{
			sTableLocator = listOfParameters[0];
			sColumnName = listOfParameters[1];
			sColumnValues = listOfParameters[2];
			sRowNumbersToSelect = listOfParameters[3];
			sColHeaderStrtRowNum=listOfParameters[4];
			sVariableName=listOfParameters[5];
		} else
		{
			// Insufficient Parameters
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setTestData(sTableLocator+DELIMITER+  sColumnName +DELIMITER+ sColumnValues +DELIMITER+sRowNumbersToSelect  +DELIMITER+ sColHeaderStrtRowNum +DELIMITER+sVariableName);

		if (KeywordUtilities.isEmptyString(sTableLocator))
		{
			logger.error (ERROR_TABLE_LOCATOR_NOT_PASSED);
			testCaseExecutionResult.setMessage(ERROR_TABLE_LOCATOR_NOT_PASSED);
			return testCaseExecutionResult;
		}
		if (KeywordUtilities.isEmptyString(sRowNumbersToSelect)) {
			if (KeywordUtilities.isEmptyString(sColumnName))
			{
				logger.error (ERROR_TABLE_COLS_NOT_PASSED);
				testCaseExecutionResult.setMessage(ERROR_TABLE_COLS_NOT_PASSED);
				return testCaseExecutionResult;
			}
			if (KeywordUtilities.isEmptyString(sColumnValues) && !sColumnName.equalsIgnoreCase("<ALL>"))
			{
				logger.error (ERROR_SEARCH_VALUE_NOT_FOUND);
				testCaseExecutionResult.setMessage(ERROR_SEARCH_VALUE_NOT_FOUND);
				return testCaseExecutionResult;
			}
		}
		else{
			String numRows[] = sRowNumbersToSelect.trim().split("\\|");
			int iRowFlag=1;
			try {
				for (int i=0; i<numRows.length;i++)
					Integer.parseInt(numRows[i]);
			} catch (NumberFormatException e3) {
				iRowFlag=0;
			}
			if (iRowFlag==0) {
				logger.error ("Row number should be numeric");
				testCaseExecutionResult.setMessage("Row number should be numeric");
				return testCaseExecutionResult;
			}
		}
		if (sColumnName.equalsIgnoreCase("<ALL>")){
			if (!KeywordUtilities.isEmptyString(sColumnValues)) {
				logger.error ("When All rows to be selected, Column Values are not required");
				testCaseExecutionResult.setMessage("When All rows to be selected, Column Values are not required");
				return testCaseExecutionResult;
			}
		}
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;

	}

	@Override
	public TestcaseExecutionResultVO validateObject(String... listOfParameters)
	{
		if (webDriver == null)
		{
			// Browser not instantiated
			logger.error(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;

		}

		testCaseExecutionResult.setObject(sTableLocator);

		if (sTableLocator.startsWith(OBJECT_SPECIFIER))
		{
			sTableLocator = sTableLocator.substring(OBJECT_SPECIFIER.length(),sTableLocator.length());

			if (!KeywordUtilities.waitForElementPresent(configurationMap,webDriver,sTableLocator, userName))
			{
				logger.error(ERROR_TABLE_NOT_FOUND);
				testCaseExecutionResult.setMessage(ERROR_TABLE_NOT_FOUND);
				testCaseExecutionResult.setValid(false);
				return testCaseExecutionResult;
			}

			
		}
		testCaseExecutionResult.setObject(sTableLocator);
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}
}
