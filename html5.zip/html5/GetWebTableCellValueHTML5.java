package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_INVALID_COLUMN_NAME_PASSED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_INVALID_ROW_NUMBER_PASSED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_ROW_NUM_NOT_FOUND;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_TABLE_COLUMNS_NOT_FOUND;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_TABLE_COL_PARA_NOT_PASSED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_TABLE_ENVPARA_NOT_PASSED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_TABLE_NOT_FOUND;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_TABLE_PARA_NOT_PASSED;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.EMPTY_STRING;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;
import com.sungard.ktt.view.config.KTTGuiConstants;
/**
 * @author Dnyaneshwar.Daphal
 * @update Gyaneshwar.Nandanwar on 25-Oct-2013
 */
public class GetWebTableCellValueHTML5 extends AbstractKeyword {
	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();
	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());

	public static final String KENDO_GRID_NAME="KendoGridName";
	public static final String DEFAULT_KENDO_GRID_NAME="kendoGrid";
	
	String [] paramList={};

	/**
	 * This is web element object
	 */
	private WebElement elementTable, elementTableHeader;
	/**
	 * To find Table- refer Data grid locator
	 */
	private String sTableId=null;
	/**
	 * Row number 
	 */
	private String sRowNumber =null;
	/**
	 *column name or column number, column number starting with 1
	 */
	private String sColumnName =null;
	/**
	 * Environment variable to store the cell value
	 */
	private String sEnvVariable=null;	
	/**
	 * Header row number if header has multiple rows, 
	 * by default it will take first row 
	 */
	private String sColHeaderStrtRowNum=null;
	
	private String dynamicTableTag=null;
	@Override
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO executeScript(String... listOfParameters) {

		int row=0;
		try 
		{
			if (KeywordUtilities.isEmptyString(sColHeaderStrtRowNum))
			{
				sColHeaderStrtRowNum="0";
			}
			String sGridName=DEFAULT_KENDO_GRID_NAME;
			try {
				sGridName =configurationMap.get(KENDO_GRID_NAME);
			} catch (Exception e3) {
				sGridName=DEFAULT_KENDO_GRID_NAME;
			}

			if(sGridName==null)
			{
				sGridName=DEFAULT_KENDO_GRID_NAME;
			}
			if (!KeywordUtilities.isEmptyString(sRowNumber))
			{
				row = Integer.parseInt(sRowNumber);
				//row--; // specially for html5 grids/tables
			}	
			
			int iColFlag=1;
			try {
				Integer.parseInt(sColumnName);
			} catch (NumberFormatException e3) {
				iColFlag=0;
			}

			try {
				elementTableHeader=KeywordUtilitiesHTML5.kendoDataControl(webDriver, elementTable,"grid");
			} catch (Exception e) {
				logger.error("Unable TO Find Column Header Element:");
				testCaseExecutionResult.setMessage("Unable TO Find Column Header Element:");
				return testCaseExecutionResult;
			}
		
			
			
		///// changed by rakesh 
			try {
					List<WebElement> tableElements  = new ArrayList<WebElement>();
					tableElements =  elementTableHeader.findElements(By.tagName("table"));
					if (tableElements.size()>1){ row--; }
					else{
							 if(dynamicTableTag.equalsIgnoreCase("y")||dynamicTableTag.equalsIgnoreCase("yes")||dynamicTableTag.equalsIgnoreCase("True"))
							 {
								 row++;
							 }
					}
			} catch (Exception e2) {
				logger.error("Exception::",e2);
			}
		///// End changed by rakesh 
			
			if (iColFlag==0) {		
				sColumnName= KeywordUtilitiesHTML5.returnColumnNumber(webDriver,elementTableHeader, sColumnName, sColHeaderStrtRowNum,sGridName);
				if (sColumnName.equalsIgnoreCase("COL_ERR")) {
					logger.error(ERROR_TABLE_COLUMNS_NOT_FOUND);
					testCaseExecutionResult.setMessage(ERROR_TABLE_COLUMNS_NOT_FOUND);
					return testCaseExecutionResult;
				}
				iColFlag=1;
			}

			String sGetWebTableCellValue=
					"		VerifyRowData(arguments[0]);																			"+
							"		function VerifyRowData(HTML5_Table_obj)																	"+
							"		{																							            "+
							"		var ColId = \""+ sColumnName+ "\";																		"+
							"		var StrtRow=\""+row+"\";																				"+
							//		KeywordUtilities.getDocumentObject(sFrameValue)											 				+
							"		var rtbl=HTML5_Table_obj;																				"+
							"		ColId--;																								"+
							"       var rwsCount=rtbl.rows.length;"
							+"      if(rwsCount<StrtRow)																					"+
							"		{																										"+
							"			return \""+ERROR_INVALID_ROW_NUMBER_PASSED+"\";														"+
							"		}																										"+
							"       var rs=rtbl.rows[StrtRow].cells;																		"+
							"		return trim(rs[ColId].innerText);																		"+
							"		}																										"+
							"		function trim(s)																						"+
							"		{																										"+
							"			return s.replace(/^\\s*/,\"\").replace(/\\s*$/, \"\");												"+
							"		}																										";

			String sfinalStatus = EMPTY_STRING;			
			
			String sgetBrowser=EMPTY_STRING;
			
			//SAF-2665 Now sgetBrowser returns "INTERNET EXPLORER" instead of "MSIE".Hence adding logic to handle this.
			try
			{
				Capabilities caps = ((RemoteWebDriver) this.webDriver).getCapabilities();
				sgetBrowser = caps.getBrowserName();

			}catch(Exception e){						
				sgetBrowser=EMPTY_STRING;}
			
			try{		
				if(sgetBrowser.toUpperCase().contains(KTTGuiConstants.INTERNET_EXPLORER_STRING)) //End of SAF-2665 changes completed
				{
					sfinalStatus =(String)((JavascriptExecutor)webDriver).executeScript(("return "+sGetWebTableCellValue).toString(),elementTable);
				}
				else
				{
					sGetWebTableCellValue=sGetWebTableCellValue.replaceAll("innerText", "textContent");
					sfinalStatus =(String)((JavascriptExecutor)webDriver).executeScript(("return "+sGetWebTableCellValue).toString(),elementTable);
				}				
			} catch (Exception e){ logger.error("Exception::",e);}

			if(sfinalStatus.equalsIgnoreCase(ERROR_TABLE_NOT_FOUND))
			{
				logger.error(ERROR_TABLE_NOT_FOUND);
				testCaseExecutionResult.setMessage(ERROR_TABLE_NOT_FOUND);
				return testCaseExecutionResult;
			} 

			else  if(sfinalStatus.equalsIgnoreCase(ERROR_INVALID_COLUMN_NAME_PASSED))
			{
				logger.error(ERROR_INVALID_COLUMN_NAME_PASSED);
				testCaseExecutionResult.setMessage(ERROR_INVALID_COLUMN_NAME_PASSED);
				return testCaseExecutionResult;
			}

			else  if(sfinalStatus.equalsIgnoreCase(ERROR_INVALID_ROW_NUMBER_PASSED))
			{
				logger.error(ERROR_INVALID_ROW_NUMBER_PASSED);
				testCaseExecutionResult.setMessage(ERROR_INVALID_ROW_NUMBER_PASSED);
				return testCaseExecutionResult;
			}
			else
			{
				configurationMap.put(sEnvVariable, sfinalStatus);
				testCaseExecutionResult.setConfigUpdate(true);
				testCaseExecutionResult.setStatus(PASS);
			}
			return testCaseExecutionResult;
		} 
		catch (Exception e) 
		{	
			logger.error("Exception::"+e.getCause().toString());
			testCaseExecutionResult.setMessage(e.getCause().toString());
			return testCaseExecutionResult;
		}
	}

	@Override

	/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters
	 *            - sTableId -sColumnName-sRowNumber-sEnvVariable-sColHeaderStrtRowNum
	 * 
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */

	public TestcaseExecutionResultVO validateKeyword( String... listOfParameters) {

		if(listOfParameters!=null)
		{
			sTableId=listOfParameters[0];
			sColumnName =listOfParameters[1];
			sRowNumber =listOfParameters[2];
			sEnvVariable=listOfParameters[3];
			sColHeaderStrtRowNum=listOfParameters[4];
			dynamicTableTag=listOfParameters[5];
		}else
		{
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}


		testCaseExecutionResult.setTestData(sTableId+DELIMITER+ sColumnName +DELIMITER+sRowNumber +DELIMITER+sEnvVariable+DELIMITER+ sColHeaderStrtRowNum);
		
		paramList=new String[5];
		paramList[0]=sTableId;
		paramList[1]=sColumnName;
		paramList[2]=sRowNumber;
		paramList[3]=sEnvVariable;
		paramList[4]=sColHeaderStrtRowNum;
		

		if (KeywordUtilities.isEmptyString(sTableId))
		{
			logger.error(ERROR_TABLE_PARA_NOT_PASSED);
			testCaseExecutionResult.setMessage(ERROR_TABLE_PARA_NOT_PASSED);
			return testCaseExecutionResult;
		}

		if (KeywordUtilities.isEmptyString(sColumnName))
		{
			logger.error(ERROR_TABLE_COL_PARA_NOT_PASSED);
			testCaseExecutionResult.setMessage(ERROR_TABLE_COL_PARA_NOT_PASSED);
			return testCaseExecutionResult;
		}

		// check for row number

		if (KeywordUtilities.isEmptyString(sRowNumber)) {
			logger.error(ERROR_ROW_NUM_NOT_FOUND);
			testCaseExecutionResult.setMessage(ERROR_ROW_NUM_NOT_FOUND);
			return testCaseExecutionResult;
		}
		if (!KeywordUtilities.isValidPositiveNumbericValue(sRowNumber)) {
			logger.error(ERROR_INVALID_ROW_NUMBER_PASSED);
			testCaseExecutionResult.setMessage(ERROR_INVALID_ROW_NUMBER_PASSED);
			return testCaseExecutionResult;
		}

		// check for environment variable
		if (KeywordUtilities.isEmptyString(sEnvVariable)) {
			logger.error(ERROR_TABLE_ENVPARA_NOT_PASSED);
			testCaseExecutionResult.setMessage(ERROR_TABLE_ENVPARA_NOT_PASSED);
			return testCaseExecutionResult;
		}

		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;

	}
	@Override

	/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... listOfParameters) {

		if (webDriver == null) {
			logger.error ("ERROR_BROWSER_NOT_INSTANTIATED");
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}
	
		if (sTableId != null && sTableId.trim().startsWith(OBJECT_SPECIFIER)) {
			sTableId = sTableId.substring(OBJECT_SPECIFIER.length(), sTableId.length());
		}

		elementTable=KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap,webDriver, sTableId, "", userName);

		if (elementTable==null) {
			
			logger.error ("Table not found");
			testCaseExecutionResult.setMessage("Table not found");
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setObject(sTableId);
		testCaseExecutionResult.setValid(true);		
		return testCaseExecutionResult;
		
	}
}

