package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.Actual_Page_Title;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_JumpToHTML5_CODE_NOT_PASSED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.view.config.KTTGuiConstants.DEFAULT_OBJECT_WAIT_TIME;
import static com.sungard.ktt.view.config.KTTGuiConstants.DEFAULT_PAGE_LOAD_TIME;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.EMPTY_STRING;
import static com.sungard.ktt.view.config.KTTGuiConstants.FRAME_NAME_ENV;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_RENDERING_ITERATION_WAIT_VARIABLE;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_WAIT_VARIABLE;
import static com.sungard.ktt.view.config.KTTGuiConstants.PAGE_LOAD_WAIT_VARIABLE;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.Keyword;
import com.sungard.ktt.business.keywords.KeywordFactoryImpl;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.config.InitSAFALProperties;
import com.sungard.ktt.model.util.TimeWatcher;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;
/**
 * @author Prakash.Gupta
 * This method runs after all the validations are successfull    
 * @return <code>true</code> if the screen code is entered and the title is
 *         verified, exact error message according to failure
 *
 */
public class NavigateToPageHTML5Keyword extends AbstractKeyword  {
	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();
	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
	/**
	 * This is web element
	 */
	private WebElement elementMegaMenuLink, elementJumpTxtField, elementJumpToLink, elementPageTitle = null;

	/**
	 * (Mandatory) page title to be navigated. It has to be complete page title
	 */
	private String sJumpToHTML5Code = null;
	private String megaMenuIdentifier = null;
	private String skipTypeInTextBox = null;
	private String veirfyPageTile = null;
	private String skipcloseTabs = null;
	private String closeBtnIdentifier = null;
	private String closesubBtnIdentifier = null;
	
	private String rufMegaMenuIdentifier=null;
	private String rufCloseBtnIdentifier =null;
	private String rufCloseSubBtnIdentifier =null;
	private String searchBoxIdentifier=null;
	/**
	 * (Optional) Instance to be passed if multiple screens with same page title are available. 
	 * Bydefault its 1
	 */
	private String sJumpToInstance = null;
	@Override
	public TestcaseExecutionResultVO executeScript(String... listOfParameters) {
		String SelectedFrames = "";
		String alertText=null;
		try{
				SelectedFrames = 	configurationMap.get("FrameName");
				

				try{Integer.parseInt(sJumpToInstance);}catch(Exception e){sJumpToInstance = "1";}
						
				int iWaitForPageLoad  = Integer.parseInt(DEFAULT_PAGE_LOAD_TIME);				
				if (configurationMap != null && null != configurationMap.get(OBJECT_WAIT_VARIABLE)) 
				{
					try {iWaitForPageLoad = Integer.parseInt(configurationMap.get(PAGE_LOAD_WAIT_VARIABLE));
					} catch (NumberFormatException e) {logger.error("NumberFormatException::",e);}
				}
		
				try {webDriver.switchTo().defaultContent();} catch (Exception e2) {logger.error("Exception::",e2);}
//				configurationMap.put("FrameName","");
//			;

				
				KeywordUtilities.updateConfigurationMap(configurationMap,"FrameName","");			
				
				WebElement LoadingIcon=null;		
				
				InitSAFALProperties initSAFALProperties = InitSAFALProperties.getInstance(userName);
				
				int iObjectIterationWaitTime=initSAFALProperties.ObjectRenderingWaitTime;
				try{
						iObjectIterationWaitTime=Integer.parseInt(configurationMap.get(OBJECT_RENDERING_ITERATION_WAIT_VARIABLE));
				}
				catch(Exception e){iObjectIterationWaitTime=initSAFALProperties.ObjectRenderingWaitTime;}

					TimeWatcher timeWatcher = new TimeWatcher(iWaitForPageLoad);
					timeWatcher.startTimeWatcher();					
					
					while(!timeWatcher.isTimeUp(userName))
					{
		
						//SAF-2629 replacing static 1000 milliseconds wait to iObjectIterationWaitTime	

						try {
							LoadingIcon = webDriver.findElement(By.xpath("//body[contains(@class,'loading')]"));
						} catch (Exception e) {
							LoadingIcon=null;
						}
		
						if(LoadingIcon==null)
						{
							logger.info("Page fully loaded..... :");
							break;
						}
						try {Thread.sleep(iObjectIterationWaitTime);
						} catch (InterruptedException e) {
							logger.error("InterruptedException::",e);
						}
					}
					
					timeWatcher.cancel();
		/*
				WebElement LoadedIcon=null;				
	
					timeWatcher.startTimeWatcher();
					while(!timeWatcher.isTimeUp(userName))
					{
						//SAF-2629 replacing static 1000 milliseconds wait to iObjectIterationWaitTime
											
						try {
							LoadedIcon=webDriver.findElement(By.xpath("//body[contains(@class,'sidebar-right')]"));
							//LoadedIcon=webDriver.findElement(By.xpath("//button[@aria-label='Main menu']"));
						} catch (Exception e1) {logger.error("Exception::",e1);}
		
						if(LoadedIcon!=null)
						{
							logger.info("Page fully loaded..... :");
							break;
						}
						try {Thread.sleep(iObjectIterationWaitTime);
						} catch (InterruptedException e) {	
							logger.error("InterruptedException::",e);
						}
					}
					timeWatcher.cancel();
					*/
				if(!skipcloseTabs.equalsIgnoreCase("y"))
				{
					//---------SAF-7039 code for RUF page to close the tabs----------------------
					
					WebElement closeBtn=null;
					TimeWatcher timeWatcher2 = new TimeWatcher(iWaitForPageLoad);
					timeWatcher2.startTimeWatcher();					
					
					while(!timeWatcher2.isTimeUp(userName))
					{
						try {
							closeBtn=webDriver.findElement(By.xpath("(//mat-icon[@fisicon='close'])[last()]"));
							closeBtnIdentifier=rufCloseBtnIdentifier;
							closesubBtnIdentifier=rufCloseSubBtnIdentifier;
						} catch (Exception e1) 
						{
							logger.error("Exception occured for RUF close button:",e1);
						}
						if (closeBtn==null)
						{
							try {
								closeBtn=webDriver.findElement(By.xpath("//i[@aria-label='Close']")); 
								//closeBtnIdentifier="";
								//closesubBtnIdentifier="";
							} catch (Exception e) {
								logger.error("Exception occured for NON RUF close button:",e);
							}
						}
						if(closeBtn!=null)
						{
							logger.info("Close Button found...");
							break;
						}
					}
					
					timeWatcher2.cancel();
					
						List<WebElement> test = null;
						
							test = webDriver.findElements(By.xpath("//div[contains(@class,'displaypanel')]/ul[@class='nav nav-tabs']/li[@data-path and not (@data-path='/welcome' or @data-path='/dashboard' or @data-path='/dropdown/kendoWidgets') ]"));
							if (test==null || test.size()<1)
							{
								test = webDriver.findElements(By.xpath("//div[@role='tab' and contains(@class,'mat-tab-label') and not (@id='mat-tab-label-0-0')]"));
							}
					
					if(test!= null && test.size()>=1)
					{
							Keyword closeTabs = KeywordFactoryImpl.getInstance().get("CloseMainTabs", "false"); 
							String[] params1 = new String[8];
							params1[0] = closeBtnIdentifier;
							params1[1] = closesubBtnIdentifier;
							params1[2] = EMPTY_STRING;
							params1[3] = EMPTY_STRING;
							params1[4] = EMPTY_STRING;
							params1[5] = EMPTY_STRING;
							params1[6] = EMPTY_STRING;
							params1[7] = EMPTY_STRING;	
		
							TestcaseExecutionResultVO TestcaseExecutionResultCloseTabs= null;
							try{
								TestcaseExecutionResultCloseTabs = closeTabs.execute(
										scriptName, this.webDriver, configurationMap,workBookMap,userName,
										params1);
								if (!(TestcaseExecutionResultCloseTabs.getStatus() == PASS) )
								{
									return 		TestcaseExecutionResultCloseTabs;				
								}
		
		
							}catch(Exception e){
								logger.error("Exception occurred: ", e);
							}	
						}	
				}				
					
				
				//------------------ Code for RUF and Non RUF mega menu button click ---------------------------
		
				WebElement megaMenuBtn=null;
				String slink=null;
				String elementsTitleStripIdentifier=null;
				String elementPageTitleIdentifier=null;
				TimeWatcher timeWatcher3 = new TimeWatcher(iWaitForPageLoad);
				timeWatcher3.startTimeWatcher();					
				
				while(!timeWatcher3.isTimeUp(userName))
				{
					try {
						megaMenuBtn=webDriver.findElement(By.xpath("//button[@aria-label='Main menu']"));
						megaMenuIdentifier=rufMegaMenuIdentifier;
						searchBoxIdentifier="css=input[name=filterRef]";
						//slink="xpath=//a[text()='"+sJumpToHTML5Code+"']";
						slink="xpath=(//a[text()='" +sJumpToHTML5Code+ "' and @title='"+sJumpToHTML5Code+"'])[1]";
						elementsTitleStripIdentifier="//div[contains(@class,'mat-tab-label-container')]";
						elementPageTitleIdentifier="//span[text()=' "+ sJumpToHTML5Code +" ']";
					} catch (Exception e1) 
					{
						logger.error("Exception occured for RUF Mega Menu button:",e1);
					}
					if (megaMenuBtn==null)
					{
						try {
							megaMenuBtn=webDriver.findElement(By.xpath("//button[contains(@class,'-home')]"));
							searchBoxIdentifier="css=input[type=search]";
							slink="xpath=//a[text()='"+sJumpToHTML5Code+"']";
							elementsTitleStripIdentifier="//div[contains(@class,'-displaypanel')]";
							elementPageTitleIdentifier="//li[contains(@class,'-tab') and contains(@class,'ng-scope') and contains(@class,'-active')]";
						} catch (Exception e) {
							logger.error("Exception occured for NON RUF Mega Menu button:",e);
						}
					}
					if(megaMenuBtn!=null)
					{
						logger.info("Mega Menu Button found...");
						break;
					}
				}
				
				timeWatcher3.cancel();
				
				
				try{
					elementMegaMenuLink = KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap,webDriver, megaMenuIdentifier, "1", userName);
					if(elementMegaMenuLink==null)
					{
//						configurationMap.put("FrameName",SelectedFrames);
						KeywordUtilities.updateConfigurationMap(configurationMap,"FrameName",SelectedFrames);
						logger.error("Mega Menu button not found");
						testCaseExecutionResult.setMessage("Mega Menu button not found");
						return testCaseExecutionResult;
					}
					// Click Mega Menu
					try {
						((JavascriptExecutor)webDriver).executeScript("arguments[0].focus();",elementMegaMenuLink);

					} catch (Exception e) {logger.error("Exception::",e);}
					try {
						((JavascriptExecutor)webDriver).executeScript("arguments[0].click();",elementMegaMenuLink);
						KeywordUtilities.waitForPageToLoad(webDriver, iWaitForPageLoad,userName);

					} catch (Exception e) 
					{logger.error("Exception::",e);}
					
					if(skipTypeInTextBox.equalsIgnoreCase("N")|| skipTypeInTextBox.equalsIgnoreCase("No")||skipTypeInTextBox.equalsIgnoreCase("False")){
					elementJumpTxtField = KeywordUtilities.waitForElementPresentAndEnabledInstance(configurationMap,webDriver, searchBoxIdentifier,"1", userName);

						if(elementJumpTxtField==null)
						{
//							configurationMap.put("FrameName",SelectedFrames);

							KeywordUtilities.updateConfigurationMap(configurationMap,"FrameName",SelectedFrames);
							logger.error("Search field not found");
							testCaseExecutionResult.setMessage("Search field not found");
							return testCaseExecutionResult;
						}
						try {

							try {
								((JavascriptExecutor)webDriver).executeScript("arguments[0].value='';",elementJumpTxtField);
							} catch (Exception e) {
								logger.error("Exception::",e);
							}
							elementJumpTxtField.sendKeys(sJumpToHTML5Code);
							KeywordUtilities.waitForPageToLoad(webDriver, iWaitForPageLoad,userName);
						} catch (Exception e) {
							elementMegaMenuLink.click();
							KeywordUtilities.waitForPageToLoad(webDriver, iWaitForPageLoad,userName);
//							configurationMap.put("FrameName",SelectedFrames);

							KeywordUtilities.updateConfigurationMap(configurationMap,"FrameName",SelectedFrames);
							logger.error("Could not enter in Search field");
							testCaseExecutionResult.setMessage("Could not enter in Search field");
							return testCaseExecutionResult;
						}
					}
		
					// Checking if desired JumpTo link present in list, if no link then it's invalid.*/
					boolean foundJumpToLink = false;
					try {

						//String slink = "xpath=//a[text()='"+sJumpToHTML5Code+"']";
						elementJumpToLink = waitForElementPresentAndEnabledInstance(configurationMap,webDriver, slink,sJumpToInstance);
						if(elementJumpToLink !=null)
						{
							foundJumpToLink = true;
						}
					} catch (Exception e){logger.error("Exception::",e);}
					if(!foundJumpToLink)
					{
						elementMegaMenuLink.click();				
						KeywordUtilities.waitForPageToLoad(webDriver, iWaitForPageLoad,userName);						
						logger.error("No Records found");
						testCaseExecutionResult.setMessage("No Records found");
//						configurationMap.put("FrameName",SelectedFrames);

						KeywordUtilities.updateConfigurationMap(configurationMap,"FrameName",SelectedFrames);
						return testCaseExecutionResult;
					}
					//clink on JumpTo link
					try {
						try {
							((JavascriptExecutor)webDriver).executeScript("arguments[0].focus();",elementJumpToLink);

						} catch (Exception e){logger.error("Exception::",e);}
						try {
							((JavascriptExecutor)webDriver).executeScript("arguments[0].click();",elementJumpToLink);
							
						} catch (Exception e){
							elementJumpToLink.click();
						}
						try {KeywordUtilities.waitForPageToLoad(webDriver, iWaitForPageLoad,userName);
						} catch (Exception err){logger.error("Exception::",err);}				
					} catch (Exception e) {
						elementMegaMenuLink.click();
						KeywordUtilities.waitForPageToLoad(webDriver, iWaitForPageLoad,userName);
						Thread.sleep(1000);
//						configurationMap.put("FrameName",SelectedFrames);

						KeywordUtilities.updateConfigurationMap(configurationMap,"FrameName",SelectedFrames);
						logger.error("Could not click on Record Link");
						testCaseExecutionResult.setMessage("Could not click on Record Link");
						return testCaseExecutionResult;
					}
		
					
					String sAlertWaitTime=configurationMap.get("NavigateToPage_AlertWaitTime");
					if(sAlertWaitTime!=null){
						int iAlertWaitTime=0;
						try{
							 iAlertWaitTime=Integer.parseInt(sAlertWaitTime);
						}
						catch(Exception e){
							iAlertWaitTime=0;
						}
						
						if(iAlertWaitTime!=0){
							timeWatcher = new TimeWatcher(iAlertWaitTime);
							timeWatcher.startTimeWatcher();
							while(!timeWatcher.isTimeUp(userName))
							{
								try{
									if(webDriver.switchTo().alert()!=null){
										alertText= webDriver.switchTo().alert().getText();
//										configurationMap.put("NavigateToPageAlertText", alertText);

										KeywordUtilities.updateConfigurationMap(configurationMap,"NavigateToPageAlertText", alertText);
										webDriver.switchTo().alert().dismiss();
										break;
									}
								}
								catch(Exception e){
									logger.error("Failed to handle alert"+e);									
								}
								
							}
							timeWatcher.cancel();
						}
					}
					
					// verify page title 
					if(veirfyPageTile.equalsIgnoreCase("y")||veirfyPageTile.equalsIgnoreCase("yes")||veirfyPageTile.equalsIgnoreCase("true")){
						try {
							//SAF-2893
							WebElement elementPageTitlesStrip = webDriver.findElement(By.xpath(elementsTitleStripIdentifier));	

							elementPageTitle = elementPageTitlesStrip.findElement(By.xpath(elementPageTitleIdentifier));
						} catch (Exception e) {
							logger.error("Page Title field not found");
//							configurationMap.put("FrameName",SelectedFrames);

							KeywordUtilities.updateConfigurationMap(configurationMap,"FrameName",SelectedFrames);
							testCaseExecutionResult.setMessage("Page Title field not found");
							return testCaseExecutionResult;
						}
						String pageTitle = (elementPageTitle.getText()).trim();
							if(pageTitle.startsWith(sJumpToHTML5Code)){
								testCaseExecutionResult.setStatus(PASS);
							}
							else{
								logger.error("Expected page title not found, " + Actual_Page_Title + pageTitle);
//								configurationMap.put("FrameName",SelectedFrames);

								KeywordUtilities.updateConfigurationMap(configurationMap,"FrameName",SelectedFrames);
							   testCaseExecutionResult.setMessage("Expected page title not found, " + Actual_Page_Title + pageTitle);
							}
					}else{
						testCaseExecutionResult.setStatus(PASS);
					}
				}catch (Exception e) {
					logger.error("Exception::"+e.getCause().toString());
					testCaseExecutionResult.setMessage(e.getCause().toString());
				}
		}catch(Exception e){
			logger.error("Exception::"+e.getCause().toString());
			testCaseExecutionResult.setMessage(e.getCause().toString());
		}
		finally{
//			configurationMap.put("FrameName",SelectedFrames);
//			;

			KeywordUtilities.updateConfigurationMap(configurationMap,"FrameName",SelectedFrames);			
		}
		
		if(alertText!=null){
			testCaseExecutionResult.setMessage("Found alert:"+alertText);
		}
		return testCaseExecutionResult;
	}

	/**
	 * This method performs validation of the keyword
	 * 
	 * @param listOfParameters
	 *            : This method requires two parameters, one the screen code
	 *            which is to be entered and second the title which is to be
	 *            verified. Second parameter is optional
	 * 
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	@Override
	public TestcaseExecutionResultVO validateKeyword(String... listOfParameters) {

		// the keyword requires two parameters
		// 1)The value to enter
		// 2)The title to verify

		if (listOfParameters != null) {
			sJumpToHTML5Code = listOfParameters[0];
			sJumpToInstance = listOfParameters[1];
			megaMenuIdentifier = listOfParameters[2];
			skipTypeInTextBox = listOfParameters[3];
			veirfyPageTile= listOfParameters[4];
			closeBtnIdentifier= listOfParameters[5];
			closesubBtnIdentifier= listOfParameters[6];
			skipcloseTabs= listOfParameters[7];
			
		//-------- SAF-7039 --------------------------
			rufMegaMenuIdentifier=listOfParameters[2];
			rufCloseBtnIdentifier=listOfParameters[5];
			rufCloseSubBtnIdentifier=listOfParameters[6];
	
		} else {
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}
		
		if (EMPTY_STRING.equals(megaMenuIdentifier)){
			megaMenuIdentifier ="xpath=//button[contains(@class,'-home')]";
			rufMegaMenuIdentifier="xpath=//button[@aria-label='Main menu']";
			
		} else {
			if(megaMenuIdentifier.startsWith(OBJECT_SPECIFIER)){
				megaMenuIdentifier = megaMenuIdentifier.substring(OBJECT_SPECIFIER.length(),megaMenuIdentifier.length());
			}
		}
		if (skipcloseTabs.equalsIgnoreCase("y")||skipcloseTabs.equalsIgnoreCase("yes")||skipcloseTabs.equalsIgnoreCase("true")) {
			skipcloseTabs = "y";
		}else{
			skipcloseTabs = "n";
		}
		if (EMPTY_STRING.equals(skipTypeInTextBox)) {
			skipTypeInTextBox = "Y";
		}
		if (EMPTY_STRING.equals(veirfyPageTile)) {
			veirfyPageTile = "N";
		}
		if (EMPTY_STRING.equals(closeBtnIdentifier)) {
			closeBtnIdentifier = "xpath=//i[@aria-label='Close']";
			rufCloseBtnIdentifier="xpath=(//mat-icon[@fisicon='close'])[last()]";
		}
		if (EMPTY_STRING.equals(closesubBtnIdentifier)) {
			closesubBtnIdentifier = "Close all Tabs";
			rufCloseSubBtnIdentifier="xpath=//h5[text()='Close All Tabs']";
		}
		if (EMPTY_STRING.equals(sJumpToInstance)) {
			testCaseExecutionResult.setTestData(sJumpToHTML5Code);
		} else {
			testCaseExecutionResult.setTestData(sJumpToHTML5Code +DELIMITER + sJumpToInstance);
		}
		if (EMPTY_STRING.equals(sJumpToHTML5Code)) {
			logger.error(ERROR_JumpToHTML5_CODE_NOT_PASSED);
			testCaseExecutionResult.setMessage(ERROR_JumpToHTML5_CODE_NOT_PASSED);
			return testCaseExecutionResult;
		}
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}

	/**
	 * This method validates the required object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	@Override
	public TestcaseExecutionResultVO validateObject(String... listOfParameters) {

		if (webDriver == null) {
			// Browser not instantiated
			logger.error ("ERROR_BROWSER_NOT_INSTANTIATED");
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;

		} 
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;

	}

	public  WebElement waitForElementPresentAndEnabledInstance(final Map<String, String> mapConfigMap ,final WebDriver webDriver, final String sTargetObject, final String instance) 
	{

		int iWaitTime=DEFAULT_OBJECT_WAIT_TIME;
		if (mapConfigMap != null && null != mapConfigMap.get(OBJECT_WAIT_VARIABLE)) 
		{
			try {
				iWaitTime = Integer.parseInt(mapConfigMap.get(OBJECT_WAIT_VARIABLE));
			} catch (NumberFormatException e) {
				iWaitTime = DEFAULT_OBJECT_WAIT_TIME;
			}
		}
		
		InitSAFALProperties initSAFALProperties = InitSAFALProperties.getInstance(userName);
		
		int iObjectRenderingWaitTime=initSAFALProperties.ObjectRenderingWaitTime;
		if (mapConfigMap != null && null != mapConfigMap.get(OBJECT_RENDERING_ITERATION_WAIT_VARIABLE)) 
		{
			try {
				iObjectRenderingWaitTime = Integer.parseInt(mapConfigMap.get(OBJECT_RENDERING_ITERATION_WAIT_VARIABLE));
			} catch (NumberFormatException e) {
				iWaitTime = initSAFALProperties.ObjectRenderingWaitTime;
			}
		}



		TimeWatcher timeWatcher = new TimeWatcher(iWaitTime);
		timeWatcher.startTimeWatcher();

		try
		{
			while(!timeWatcher.isTimeUp(userName))
			{

				try {
					String sFrameValue =mapConfigMap.get(FRAME_NAME_ENV);

					try {
						webDriver.switchTo().defaultContent();			
					} catch (Exception e) {logger.error("Exception::",e);}


					if (!EMPTY_STRING.equals(sFrameValue))
					{
						String splittedFrames[] = sFrameValue.split(";");

						for(int i = 0;i<splittedFrames.length; i++)
						{

							//added for SelectFrame using Weblement, String, 


							try {
								Keyword selectFrame = KeywordFactoryImpl.getInstance().get("SelectFrame", "false");
								String[] listOfParameters = new String[3]; 
								listOfParameters[0]=splittedFrames[i];
								listOfParameters[1]="1";
								listOfParameters[2]="TRUE";

								selectFrame.execute(null, webDriver,mapConfigMap,null, userName, listOfParameters);

							} catch (Exception e){logger.error("Exception::",e);}
						}	

					}

					try {				
						try {
							KeywordUtilities.waitForPageToLoadBoolean(webDriver, iWaitTime,userName);
						} catch (Exception e1) {logger.error("Exception::",e1);}						
						WebElement ele=KeywordUtilities.getWebElementWithInstance(webDriver, sTargetObject, instance);
						if(ele!=null)
						{
							return ele;
						}
					} 
					catch (Exception e) 
					{
						return null;
					}

					try {
						Thread.sleep(iObjectRenderingWaitTime);
					} catch (InterruptedException e) {
						logger.error("InterruptedException",e);
					}
				} catch (Exception e) {
					return null;

				}
			}
		}
		catch (Exception e) 
		{
			return null;

		}
		finally
		{
			timeWatcher.cancel();
		}
		
		
		return null;
	}
	

	
}
