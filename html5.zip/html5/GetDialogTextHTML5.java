package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.EMPTY_STRING;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;

/**
 * @author Ashish Joshi
 * Created for Script_1499 Under SAFAL 8.0.0, patch release 1
 * @creation date 30 Oct 2012
 * Parameters:
 *			sLocator = 	listOfParameters[0]; (Optional ,Locator of DatePicker Object, default: xpath=//span[@class='k-icon k-i-calendar'] )
 *			Value = 	listOfParameters[1]; (Mandatory ,Day to select from the DatePicker Control)
 */
/*This Keyword will get Dialog Text/Message and Title from the
 *  Alert/Confirmation Dialog and store it to Environment variable.
 */
public class GetDialogTextHTML5 extends AbstractKeyword{
	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());

	/**
	 * Dialog Box Locator (Optional Parameter)
	 */
	private String sDialogLocator = null;
	/**
	 *OptionalParameter, Default value: - SAFAL_HTML5_GetDialogText
	 */
	private String sEnvVariableToStoreDialogText = null;
	/**
	 * OptionalParameter, Default value: - SAFAL_HTML5_GetDialogTitle
	 */
	private String sEnvVariableToStoreDialogTitle =null;
	/**
	 * To store dialog text
	 */
	private String sActualDialogText = null;
	/**
	 * These is web element object
	 */
	private WebElement dialogBox = null;  
	private WebElement titleWindow=null;
	private WebElement modalContent=null;
	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();


	@Override
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO executeScript(String... listOfParameters) throws UnhandledAlertException {

		if(EMPTY_STRING.equals(sEnvVariableToStoreDialogText))
		{
			sEnvVariableToStoreDialogText="SAFAL_HTML5_GetDialogText";
		}

		if(EMPTY_STRING.equals(sEnvVariableToStoreDialogTitle))
		{
			sEnvVariableToStoreDialogTitle="SAFAL_HTML5_GetDialogTitle";
		}

		//=========================Using WebDriver===================================================================================================
		String GetAlertTitle=EMPTY_STRING;
		try {
			try {
				titleWindow = dialogBox.findElement(By.xpath("(//span[@ng-bind='sgTitle'])[position()=last()]"));
			} catch (Exception e) {
				titleWindow=null;
			}

			if(titleWindow==null)
			{
				logger.error("Unable to get the Title Element");
				testCaseExecutionResult.setMessage("Unable to get the Title Element");
				return testCaseExecutionResult;
			}

			GetAlertTitle=titleWindow.getText();
			configurationMap.put(sEnvVariableToStoreDialogTitle, GetAlertTitle);
			testCaseExecutionResult.setConfigUpdate(true);
		} catch (Exception e) {
			logger.error("Unable to get Dialog Box Title");
			testCaseExecutionResult.setMessage("Unable to get Dialog Box Title");
		}


		sActualDialogText=EMPTY_STRING;

		try {
			sActualDialogText=modalContent.getText();
			configurationMap.put(sEnvVariableToStoreDialogText, sActualDialogText);
			testCaseExecutionResult.setStatus(PASS);
		} catch (Exception e) {
			logger.error("Unable to get Dialog Box Text");
			testCaseExecutionResult.setMessage("Unable to get Dialog Box Text");
		}
		testCaseExecutionResult.setConfigUpdate(true);
		return testCaseExecutionResult;
	}


	@Override

	/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters
	 *            - sEnvVariableToStoreDialogText -sEnvVariableToStoreDialogTitle-sDialogLocator
	 * 
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateKeyword(String... listOfParameters) {

		if (listOfParameters != null) 
		{
			sEnvVariableToStoreDialogText = listOfParameters[0];
			sEnvVariableToStoreDialogTitle=listOfParameters[1];
			sDialogLocator=listOfParameters[2];

		} else {
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}	

		testCaseExecutionResult.setTestData(sDialogLocator+DELIMITER+sEnvVariableToStoreDialogText+DELIMITER+sEnvVariableToStoreDialogTitle);
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;				
	}

	@Override

	/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... listOfParameters) {

		if (webDriver == null) {
			logger.error(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}

		if(EMPTY_STRING.equals(sDialogLocator))
		{
			sDialogLocator="xpath=(//*[@data-role='window'])[position()=last()]";
		}
		else
		{
			if (sDialogLocator.startsWith(OBJECT_SPECIFIER)) {

				sDialogLocator = sDialogLocator.substring(OBJECT_SPECIFIER.length(), sDialogLocator.length());
			} 
		}

		dialogBox = KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, sDialogLocator,"", userName);


		if(dialogBox==null)
		{
			logger.error("Dialog Box not Found");
			testCaseExecutionResult.setMessage("Dialog Box not Found");
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}
		else
		{
			testCaseExecutionResult.setValid(true);
			testCaseExecutionResult.setObject(sDialogLocator);

			try {
				//modalContent = dialogBox.findElement(By.xpath("(//*[contains(@class,'dialog')])[position()=last()]"));
				modalContent = dialogBox.findElement(By.xpath("(//*[contains(@class,'modal-content')])[position()=last()]"));
			} catch (Exception e) {
				modalContent=null;
			}
			 

			if(modalContent==null)
			{
				logger.error("Unable to get the Dialog Message Element");
				testCaseExecutionResult.setMessage("Unable to get the Dialog Message Element");
				testCaseExecutionResult.setValid(false);
				return testCaseExecutionResult;
			}
		}
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}

}
