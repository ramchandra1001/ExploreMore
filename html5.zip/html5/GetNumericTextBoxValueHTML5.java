package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.EMPTY_STRING;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;

/**
 * @author Ashish Joshi
 * Created for Script_1499 Under SAFAL 8.0.0, patch release 1
 * @creation date 30 Oct 2012
 * Parameters:
 *			sLocator = 	listOfParameters[0]; (Optional ,Locator of DatePicker Object, default: xpath=//span[@class='k-icon k-i-calendar'] )
 *			Value = 	listOfParameters[1]; (Mandatory ,Day to select from the DatePicker Control)
 */
/**
 * @author Ashish.Joshi
 *This Keyword will get value from Numeric Text box control and store it to Environment Variable.
 */

public class GetNumericTextBoxValueHTML5 extends AbstractKeyword{

	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();

	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
	/**
	 * This is web element object
	 */
	private WebElement numericTextBox = null; 
	/**
	 * The TextBox locator
	 */
	private String sLocator = null;
	/**
	 * Instance of the Object Locator, Default BLANK=1
	 */
	private String sLocator_Instance = null;
	/**
	 *Envirnment Variable to Store the value (Default: SAFAL_Numeric_TextBox_Html5_GetValue)
	 */
	private String sEnv_Variable = null;
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO executeScript(String... listOfParameters) {

		if(EMPTY_STRING.equals(sEnv_Variable))
		{
			sEnv_Variable="SAFAL_Numeric_TextBox_Html5_GetValue";
		}

		String mySelector=
				"f(arguments[0]);                                                                                                                         " +
						"function f(ELE)                                                                                                                          " + 
						"{                                                                                                                                            " +
						"     var sNTBLocator = ELE;                                                                                                             " +
						"     var Result='FAIL';                                                                                                                        " +
						"     try                                                                                                                                             " +
						"     {                                                                                                                                               " +
						"			var numerictextbox=$(sNTBLocator).data('kendoNumericTextBox');" +
						"			Result=numerictextbox.value();" +
						"     }                                                                                                                                               " +
						"     catch(e)                                                                                                                                  " +
						"     {                                                                                                                                               " +
						"           Result='FAIL '+ e.description;                                                                                           " +
						"     }                                                                                                                                               " +
						"     return Result;                                                                                                                            " +
						"}" ;

		String sfinalStatus="FAIL";

		try 
		{
			sfinalStatus =((JavascriptExecutor)webDriver).executeScript("return "+mySelector,numericTextBox).toString();                  
		} catch (Exception e1) 
		{
			logger.error("Error while getting the value");
			testCaseExecutionResult.setMessage("Error while getting the value");
			testCaseExecutionResult.setStatus(0);
			return testCaseExecutionResult;
		}
		if(!sfinalStatus.equalsIgnoreCase("FAIL"))
		{
			configurationMap.put(sEnv_Variable, sfinalStatus);
			testCaseExecutionResult.setConfigUpdate(true);
			testCaseExecutionResult.setStatus(PASS);
		}
		else
		{
			logger.error("Unable to get the value in the Numeric Text Box. "+ sfinalStatus);
			testCaseExecutionResult.setMessage("Unable to get the value in the Numeric Text Box. "+ sfinalStatus);
		}
		return testCaseExecutionResult;
	}


	@Override
	/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters
	 *            - sLocator -sEnv_Variable-sLocator_Instance
	 * 
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateKeyword(String... listOfParameters) {

		if (listOfParameters != null) 
		{
			sLocator=listOfParameters[0];
			sEnv_Variable=listOfParameters[1];
			sLocator_Instance=listOfParameters[2];

		} else {
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}	

		testCaseExecutionResult.setTestData(sLocator+DELIMITER+sEnv_Variable+DELIMITER+sLocator_Instance);


		if(KeywordUtilities.isEmptyString(sLocator))
		{
			logger.error ("Numeric Text Box Locator not passed");
			testCaseExecutionResult.setMessage("Numeric Text Box Locator not passed");
			return testCaseExecutionResult;
		}

		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;				
	}

	@Override


	/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... listOfParameters) {

		if(EMPTY_STRING.equals(sLocator_Instance))
		{
			sLocator_Instance="1";
		}

		if (sLocator.startsWith(OBJECT_SPECIFIER)) {
			sLocator = sLocator.substring(OBJECT_SPECIFIER.length(), sLocator.length());}

		if (webDriver == null) {
			logger.error(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setObjectError(true); 
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}

		testCaseExecutionResult.setExpectedResultFlag(true);
		numericTextBox =KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, sLocator,sLocator_Instance, userName);
		if(numericTextBox==null)
		{
			logger.error("NumericText Box object not Found");
			testCaseExecutionResult.setMessage("NumericText Box object not Found");
			testCaseExecutionResult.setObjectError(true); 
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult; 
		}
		testCaseExecutionResult.setValid(true);
		testCaseExecutionResult.setObject(sLocator);
		return testCaseExecutionResult;
	}


}
