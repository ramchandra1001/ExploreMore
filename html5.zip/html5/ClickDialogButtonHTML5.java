package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.EMPTY_STRING;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;

/**
 * @author Ashish Joshi
 * Created for Script_1499 Under SAFAL 8.0.0, patch release 1
 * @creation date 30 Oct 2012
 * Parameters:
 *			sLocator = 	listOfParameters[0]; (Optional ,Locator of DatePicker Object, default: xpath=//span[@class='k-icon k-i-calendar'] )
 *			Value = 	listOfParameters[1]; (Mandatory ,Day to select from the DatePicker Control)
 *
 */



/*
 * This Keyword will click on the button using it�s text on Alert/Confirmation Dialog
 */



public class ClickDialogButtonHTML5 extends AbstractKeyword{

	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO();

	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
	/*
	 * Text Of the Button, Mandatory Parameter
	 */	
	private String sDialogButtonToclick = null;

	/*
	 * Dialog Box Locator (Optional Parameter)
	 */
	private String sDialogLocator=null;


	/**
	 * This is web element object
	 */
	private WebElement dialogBox = null;  

	/**
	 * This is web element object
	 */
	private WebElement dialogButtonToClick = null;


	@Override
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO executeScript(String... listOfParameters) throws UnhandledAlertException {
		try {
			//SAF-3236, Keyword 'ClickDialogButton' needs to be compatible for the IE Browser execution - 17-Mar-2017
			if(webDriver instanceof InternetExplorerDriver) 
			{
				((JavascriptExecutor) webDriver).executeScript("var ele=arguments[0]; ele.click();",dialogButtonToClick);
				logger.info("IEDriver Click");
			}
			else
			{
				dialogButtonToClick.click();
				try {
					Actions builder = new Actions(webDriver);
					builder.click(dialogButtonToClick).build().perform();
				} catch (Exception e) {
						logger.error("Exception::",e);
				}
				logger.info("Other Driver Click");
			}
			testCaseExecutionResult.setStatus(PASS);
		} catch (Exception e) {
			logger.error("Unable to Click on the "+sDialogButtonToclick+" Button");
			testCaseExecutionResult.setMessage("Unable to Click on the "+sDialogButtonToclick+" Button");
		}

		return testCaseExecutionResult;
	}


	@Override

/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters
	 *            -sDialogButtonToclick -sDialogLocator
	 * 
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */


	public TestcaseExecutionResultVO validateKeyword(String... listOfParameters) {
		if (listOfParameters != null) 
		{
			sDialogButtonToclick = listOfParameters[0];
			sDialogLocator=listOfParameters[2];

		} else {
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}	
		testCaseExecutionResult.setTestData(sDialogButtonToclick+DELIMITER+sDialogLocator);
		if(EMPTY_STRING.equals(sDialogButtonToclick))
		{
			logger.error ("Button to Click Not Provided.");
			testCaseExecutionResult.setMessage("Button to Click Not Provided.");
			return testCaseExecutionResult;
		}

	

		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;				
	}

	@Override

/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... listOfParameters) {
		if (webDriver == null) {
			logger.error (ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult;
		}

		if(EMPTY_STRING.equals(sDialogLocator))
		{
			sDialogLocator="xpath=(//*[@data-role='window'])[position()=last()]";
		}
		else
		{
			if (sDialogLocator.startsWith(OBJECT_SPECIFIER)) {

				sDialogLocator = sDialogLocator.substring(OBJECT_SPECIFIER.length(), sDialogLocator.length());
			} 
		}
		dialogBox = KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, sDialogLocator,"", userName);

		if(dialogBox==null)
		{
			testCaseExecutionResult.setValid(false);
			logger.error ("Dialog Box not Found");
			testCaseExecutionResult.setMessage("Dialog Box not Found");
			return testCaseExecutionResult;
		}
		else
		{
			testCaseExecutionResult.setObject(sDialogLocator);
			testCaseExecutionResult.setValid(true);

			try {
				dialogButtonToClick=dialogBox.findElement(By.xpath("(//button[text()=\""+ sDialogButtonToclick+ "\"])[position()=last()]"));
			} catch (Exception e) {
				dialogButtonToClick=null;
			}

			if(dialogButtonToClick==null)
			{
				testCaseExecutionResult.setValid(false);
				logger.error ("Unable to get require button "+sDialogButtonToclick+" on the Dialog");
				testCaseExecutionResult.setMessage("Unable to get require button "+sDialogButtonToclick+" on the Dialog");
			}
		}
		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;
	}


}
