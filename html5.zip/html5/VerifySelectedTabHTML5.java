package com.sungard.ktt.business.keywords.html5;

import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_BROWSER_NOT_INSTANTIATED;
import static com.sungard.ktt.business.keywords.ErrorMessages.ERROR_PARAMETERS_LIST;
import static com.sungard.ktt.view.config.KTTGuiConstants.DELIMITER;
import static com.sungard.ktt.view.config.KTTGuiConstants.EMPTY_STRING;
import static com.sungard.ktt.view.config.KTTGuiConstants.OBJECT_SPECIFIER;
import static com.sungard.ktt.view.config.KTTGuiConstants.PASS;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;

import com.sungard.ktt.business.keywords.AbstractKeyword;
import com.sungard.ktt.business.keywords.KeywordUtilities;
import com.sungard.ktt.model.valueobjects.TestcaseExecutionResultVO;

/**
 * @author Ashish Joshi
 * Created for Script_1499 Under SAFAL 8.0.0, patch release 1
 * @creation date 30 Oct 2012
 * Parameters:
 *			sLocator = 	listOfParameters[0]; (Optional ,Locator of DatePicker Object, default: xpath=//span[@class='k-icon k-i-calendar'] )
 *			Value = 	listOfParameters[1]; (Mandatory ,Day to select from the DatePicker Control)
 */
/**
 * @author Ashish.Joshi
 *This Keyword will verify the selected tab under Kendo tab strip control.
 */
public class VerifySelectedTabHTML5 extends AbstractKeyword{

	TestcaseExecutionResultVO testCaseExecutionResult = new TestcaseExecutionResultVO(); 
	/**
	 * This is logger object used to log keyword actions into a log file
	 */
	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
	/**
	 * This is a webelement
	 */
	WebElement tabElement = null;
	/**
	 * Tab to Verify
	 */
	private String sTabToSelect = null;
	/**
	 *The TabStrip field locator
	 */
	private String sLocator = null;
	/**
	 * Instance of the Object Locator, Default BLANK=1
	 */
	private String sLocator_Instance=null;
	@Override
	/**
	 * This method runs after all the validation has been successful
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO executeScript(String... listOfParameters) throws UnhandledAlertException {

		//==============================================================================================================================================
		//System.out.println();
		String Html5Script=
				"f(arguments[0]);                                                                                                                         " +
						"function f(ELE)                                                                                                                          " + 
						"{                                                                                                                                            " +
						"     var sTabLocator = ELE;                                                                                                             " +
						"     var Result='FAIL';                                                                                                                        " +
						"     try                                                                                                                                             " +
						"     {                                                                                                                                               " +
						"			var tabStrip=$(sTabLocator).kendoTabStrip().data('kendoTabStrip');" +
						//"			var selectedIndex=tabStrip.select().index();" +
						"			var selectedTabText = tabStrip.select().text();" +
						"			var trimmedString = selectedTabText.replace(/^\\s+|\\s+$/g, '');" +
						"			if(trimmedString.match('"+sTabToSelect+"'))" +
						//"			if(trimmedString=='"+sTabToSelect+"')" +
						"		{" +
						"			Result='PASS';" +
						"		}" +
						"		else" +
						"		{" +
						"			Result='FAIL, Found selected tab: '+trimmedString +', Expected was: '+'"+sTabToSelect+"';" +
						"		}	"+
						"     }                                                                                                                                               " +
						"     catch(e)                                                                                                                                  " +
						"     {                                                                                                                                               " +
						"           Result='FAIL '+ e.description;                                                                                           " +
						"     }                                                                                                                                               " +
						"     return Result;                                                                                                                            " +
						"}" ;

		String sfinalStatus="FAIL";
		//System.out.println();

		try 
		{
			sfinalStatus =((JavascriptExecutor)webDriver).executeScript("return "+Html5Script,tabElement).toString();                  
		} catch (Exception e1) 
		{
			logger.error("Error occurred while verifying the selected tab "+ sTabToSelect);
			testCaseExecutionResult.setMessage("Error occurred while verifying the selected tab "+ sTabToSelect);
			testCaseExecutionResult.setStatus(0);
			return testCaseExecutionResult;
		}

		if(sfinalStatus.equals("PASS"))
		{
			testCaseExecutionResult.setStatus(PASS);
		}
		else
		{
			logger.error(sfinalStatus);
			testCaseExecutionResult.setMessage(sfinalStatus);
			testCaseExecutionResult.setStatus(0);
		}

		return testCaseExecutionResult;
	}


	@Override

/**
	 * This method validates the keyword
	 * 
	 * @param listOfParameters
	 *              contains list of parameters
	 *            - sLocator-sTabToSelect-sLocator_Instance
	 * 
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */

	public TestcaseExecutionResultVO validateKeyword(String... listOfParameters) {

		if (listOfParameters != null) 
		{
			sLocator=listOfParameters[0];
			sTabToSelect = listOfParameters[1];
			sLocator_Instance=listOfParameters[2];

		} else {
			logger.error ("Insufficient Parameters!");
			testCaseExecutionResult.setMessage(ERROR_PARAMETERS_LIST);
			return testCaseExecutionResult;
		}	
		testCaseExecutionResult.setTestData(sLocator+DELIMITER+sTabToSelect+DELIMITER+sLocator_Instance);

		if(KeywordUtilities.isEmptyString(sLocator))
		{
			logger.error("Tab Locator not passed");
			testCaseExecutionResult.setMessage("Tab Locator not passed");
			return testCaseExecutionResult;
		}

		if(KeywordUtilities.isEmptyString(sTabToSelect))
		{
			logger.error("Tab to Select not passed");
			testCaseExecutionResult.setMessage("Tab to Select not passed");
			return testCaseExecutionResult;
		}

		testCaseExecutionResult.setValid(true);
		return testCaseExecutionResult;				
	}

	@Override

/**
	 * This method validates the object on the browser
	 * @return ExecutionResults containing step execution status(pass/fail),
	 *         exact error message according to failure
	 */
	public TestcaseExecutionResultVO validateObject(String... listOfParameters) {

		if(EMPTY_STRING.equals(sLocator_Instance))
		{
			sLocator_Instance="1";
		}
		if (webDriver == null) {
		logger.error(ERROR_BROWSER_NOT_INSTANTIATED);
		testCaseExecutionResult.setMessage(ERROR_BROWSER_NOT_INSTANTIATED);
		testCaseExecutionResult.setValid(false);
		return testCaseExecutionResult;
		}
		
		if (sLocator.startsWith(OBJECT_SPECIFIER)) {
			sLocator = sLocator.substring(OBJECT_SPECIFIER.length(), sLocator.length());}


		testCaseExecutionResult.setExpectedResultFlag(true);
		tabElement =KeywordUtilities.waitForElementPresentInstance(configurationMap,webDriver, sLocator,sLocator_Instance, userName);
		if(tabElement==null)
		{
			logger.error(ERROR_BROWSER_NOT_INSTANTIATED);
			testCaseExecutionResult.setMessage("NumericText Box object not Found");
			testCaseExecutionResult.setObjectError(true); 
			testCaseExecutionResult.setValid(false);
			return testCaseExecutionResult; 
		}
		testCaseExecutionResult.setValid(true);
		testCaseExecutionResult.setObject(sLocator);
		return testCaseExecutionResult;
	}

}
