package com.sungard.ktt.business.keywords.html5;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class KeywordUtilitiesHTML5 {

	Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
	public static WebElement kendoDataControl(WebDriver webDriver, WebElement Element, String data_role)
	{
		Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
		WebElement WebElement_Table = null;
		String queryIE =
		"	  return kendoDataControl(arguments[0]);																						"+
		"	  function kendoDataControl(Object_Locator_ID)																			"+
		"	  {																							            		"+
		"		try																											"+
		"		{" +		
		"		var return_obj= Object_Locator_ID;"+
		"		for (var i=0;i<5;i++)"+
		"		{"+
		"			attr_Name = $(return_obj).attr('data-role');"+	
		"		 var childSize=0;"+
		"		 try{"+
		"				childSize=$(return_obj).children().size();" + 
		"			}" +
		"		  catch(e){"
		+ "				childSize=$(return_obj).children().length;"+
		"		 }"+
		"			if (attr_Name==\""+data_role+"\")"+
		"			{"+
		"				if (childSize>0)	"+
		"					return return_obj.get(0);"+
		"				else"+
		"					return(return_obj);"+
		"			}"+
		"			return_obj=$(return_obj).parent();"
		+ "			if(return_obj==null)"
		+ "			{"
		+"				attr_Name = $(return_obj).attr('role');"+	
		"		 var childSize=0;"+
		"		 try{"+
		"				childSize=$(return_obj).children().size();" + 
		"			}" +
		"		  catch(e){"
		+ "				childSize=$(return_obj).children().length;"+
		"		 }"+
		"				if (attr_Name==\""+data_role+"\")"+
		"				{"+
		"					if (childSize>0)	"+
		"						return return_obj.get(0);"+
		"					else"+
		"						return(return_obj);"+
		"				}"+
		"				return_obj=$(return_obj).parent();"
		+ "			}"+
		"		}"+
		" 		return null;"+
		"		}catch(error11)																					"+
		"		{																								"+
		"			return (error11.description);																"+
		"		}																								"+
		"	  }";
		try {
			WebElement_Table = (WebElement)((JavascriptExecutor)webDriver).executeScript(queryIE, Element);
		}catch(Exception E){
			logger.error("Exception::",E);
		}
		return WebElement_Table;
	}
	static WebElement kendoDataControlBackward(WebDriver webDriver, WebElement Element, String data_role)
	{
		Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
		WebElement WebElement_Table = null;
		String queryIE =
		"	  return kendoDataControl(arguments[0]);																		"+
		"	  function kendoDataControl(Object_Locator_ID)																	"+
		"	  {																							            		"+
		"		try																											"+
		"		{																											"+		
		"			var elementChild = Object_Locator_ID.childNodes;																"+
		"			for(i=0,j= elementChild.length; i<j ; i++ ){															"+
		"				attr_Name = $(elementChild[i]).attr('data-role');													"+
		"				if (attr_Name==\""+data_role+"\")																	"+
		"					return elementChild[i];																			"+
		"    		}																										"+		
		" 		return null;																								"+
		"		}catch(error)																								"+
		"		{																											"+
		"			return (error.description);																				"+
		"		}																											"+
		"	  }";
		try {
			WebElement_Table = (WebElement)((JavascriptExecutor)webDriver).executeScript(queryIE, Element);
		}catch(Exception E){
			logger.error("Exception::",E);
		}
		return WebElement_Table;
	}
	public static String returnColumnNumber(WebDriver webDriver, WebElement TableElement, String Column_Header_Name, String HeaderStrtRowNo, String sGridName)
	{
		Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
		String columnNumbers=null;
		String queryIE =
		"	  return kendoDataControl(arguments[0]);																						"+
		"	  function kendoDataControl(Object_Locator_HTML5)																			"+
		"	  {																							            		"+
		"		try																											"+
		"		{" +
		"		var columnNumbers='';"+
		"		var ColName = \""+Column_Header_Name+"\";"+
		"		var SplitedColName=ColName.split(\"|\");																				"+
		" 		var HTML5_Table_Kendo=$(Object_Locator_HTML5).data(\""+sGridName+"\");"+
		" 		var HeaderObj = HTML5_Table_Kendo.thead;							"+
		"		var HeaderColumnRow=HeaderObj.find('tr:eq(\""+HeaderStrtRowNo+"\")');"+
		"		var found=false;"+	
		"		 var childSize=0;"+
		"		 try{"+
		"				childSize=HeaderColumnRow.children().size();" + 
		"			}" +
		"		  catch(e){"
		+ "				childSize=HeaderColumnRow.children().length;"+
		"		 }"+
		"       if(childSize < SplitedColName.length)																					"+
		"		{																										"+
		"			return 'Fail, Input column count not matched with Expected column count';"+														
		"		}"
		+ "		var finaltext='';"
		+ "		var finaltitle='';"+
		"		for (var i=0;i<SplitedColName.length;i++)"+
		"		{"+
		"			for (var j=0;j<childSize;j++)"+
		"			{"+
		"				var HeaderText = 'BLANK';"
		+ "				var HeaderTitle ='BLANK';"
		+ "				try{HeaderText=HeaderColumnRow.find('th:eq('+j+')').text();}catch(e){}"
		+ "				try{HeaderTitle = HeaderColumnRow.find('th:eq('+j+')').attr('datatitle');}catch(e1){}"+	
		" 				if (HeaderText=='')"
		+ "					{"+
		"					HeaderText='BLANK';"
		+ "					HeaderTitle='BLANK';"
		+ "					}"+
		"				if (i==0)"+
		"				{"+
		"					if (HeaderText.indexOf(SplitedColName[i]) > -1)"+
		"					{"+
		"						columnNumbers=(++j);"+
		"						found=true;"+
		"						break;"+
		"					}"+
		"				}"+
		"				else"+
		"				{"+
		"					if (HeaderText.indexOf(SplitedColName[i]) > -1)"+
		"					{"+
		"						columnNumbers=columnNumbers+'|'+(++j);"+
		"						found=true;"+
		"						break;"+
		"					}"+
		"				}"
		+ "				finaltext=finaltext+';'+HeaderText;"+
		"			}"+		
		"		}"+
		"		if (found)"+
		"			return columnNumbers.toString();"+
		"		else"+
		"			return 'FAIL,'+finaltext;"+
		"		}catch(error1)																					"+
		"		{																								"+
		"			return 'FAIL,'+finaltext;																"+
		"		}																								"+
		"	  }";

		try {
			columnNumbers = (String)((JavascriptExecutor)webDriver).executeScript(queryIE, TableElement);
		}catch(Exception E){
			logger.error("Exception::",E);
		}
		return columnNumbers;	
	}
	
	
	
	
	
	static String verifyColumnValues(WebDriver webDriver, WebElement TableElement, String Column_Number, String Column_Value, String startRow, String kendoGridName)
	{
		Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
		String rowNumbers=null;
		String queryIE =
		"	  return verifyColumnValues(arguments[0]);																		"+
		"	  function verifyColumnValues(Object_Locator_HTML5)								"+
		"	  {																							            		"+
		"		try																											"+
		"		{																											"+
		"		var ColNumber = \""+Column_Number+"\";																		"+
		"		var ColValue = \""+Column_Value+"\";																		"+
		"		var StartRow = \""+startRow+"\";																		"+
		"		var SplitedColNumber=ColNumber.split('|');																	"+
		" 		var HTML5_Table_Kendo=$(Object_Locator_HTML5).data(\""+kendoGridName+"\");									"+
		" 		var TableObj = HTML5_Table_Kendo.tbody;																		"+
		"		 var childSize=0;"+
		"		 try{"+
		"				childSize=TableObj.children().size();" + 
		"			}" +
		"		  catch(e){"
		+ "				childSize=TableObj.children().length;"+
		"		 }"+
		"       if(childSize<StartRow)																					"+
		"		{																										"+
		"			return 'INVALID_STRT_ROW';"+														
		"		}"+
		
		"		for (var i=StartRow;i<childSize;i++)																"+
		"		{																											"+
		"			var Row_Obj = TableObj.find('tr:eq('+i+')');															"+
		"			var actualRowData='';"+
		"			for (var j=0;j<SplitedColNumber.length;j++)																"+
		"			{																										"+
		"				var CellValue = Row_Obj.find('td:eq('+SplitedColNumber[j]+')').text();								"+
		"				if (j==0)																							"+
		"				{																									"+
		"					actualRowData= CellValue;																		"+
		"				}																									"+
		"				else																								"+
		"				{																									"+
		"					actualRowData= actualRowData+'|'+CellValue;														"+
		"				}																								"+		
		"			}																										"+
		"			if (actualRowData==ColValue)																			"+
		"			{"+
		"				return 'PASS';																							"+
		"			}"+
		"			else																									"+
		"				actualRowData='';																					"+
		"		}																											"+		
		"			return 'ROW_ERR';																						"+
		"		}catch(error)																								"+
		"		{																											"+
		"			return ('ROW_ERR');																						"+
		"		}																											"+
		"	  }";
		try {
			rowNumbers = (String)((JavascriptExecutor)webDriver).executeScript(queryIE, TableElement);
		}catch(Exception E){
			logger.error("Exception::",E);
		}
		if (rowNumbers==null)
			rowNumbers="ROW_ERR";
		return rowNumbers;	
	}
	public static String returnRowNumbers(WebDriver webDriver, WebElement TableElement, String Column_Number, String Column_Value, String kendoGridName)
	{
		Logger logger = Logger.getLogger("Thread" + Thread.currentThread().getName());
		String rowNumbers=null;
		String queryIE =
		"	  return kendoDataControl(arguments[0]);																		"+
		"	  function kendoDataControl(Object_Locator_HTML5)																"+
		"	  {																							            		"+
		"		try																											"+
		"		{																											"+
		"		var rowNumbers='';																							"+
		"		var ColNumber = \""+Column_Number+"\";																		"+
		"		var ColValue = \""+Column_Value+"\";																		"+
		"		var SplitedColValue=ColValue.split(';');																	"+		
		"		var OutputValue='';		" +
		"		for (var s=0;s<SplitedColValue.length;s++)																	"+
		"		{																											"+
		"	  			var returnValue=returnRowNumberforSingleCol(Object_Locator_HTML5, ColNumber,SplitedColValue[s]);		"+
		"				if (returnValue=='ROW_ERR')"+
		"					return returnValue;"+
		"				if (s==0)"+
		"					OutputValue=returnValue;"+
		"				else"+
		"					OutputValue=OutputValue+'|'+returnValue;"+	    
		"		}																											"+
		"		return OutputValue.toString();																							"+
		"	 	}catch(error1)																								"+
		"		{																											"+
		"			return 'ROW_ERR';																						"+
		"		}																											"+
		"     }																												"+
		"	  function returnRowNumberforSingleCol(Object_Locator_HTML5, ColNumber, ColValue)								"+
		"	  {																							            		"+
		"		try																											"+
		"		{																											"+
		"		var SplitedColNumber=ColNumber.split('|');																	"+
		" 		var HTML5_Table_Kendo=$(Object_Locator_HTML5).data(\""+kendoGridName+"\");									"+
		" 		var TableObj = HTML5_Table_Kendo.tbody;																		"+
		"		 var childSize=0;"+
		"		 try{"+
		"				childSize=TableObj.children().size();" + 
		"			}" +
		"		  catch(e){"
		+ "				childSize=TableObj.children().length;"+
		"		 }"+
		"		for (var i=0;i<childSize;i++)																"+
		"		{																											"+
		"			var Row_Obj = TableObj.find('tr:eq('+i+')');															"+
		"			var actualRowData='';"+
		"			for (var j=0;j<SplitedColNumber.length;j++)																"+
		"			{																										"+
		"				var CellValue = Row_Obj.find('td:eq('+SplitedColNumber[j]+')').text();								"+
		
		"				if (j==0)																							"+
		"				{																									"+
		"					actualRowData= CellValue;																		"+
		"				}																									"+
		"				else																								"+
		"				{																									"+
		"					actualRowData= actualRowData+'|'+CellValue;														"+
		"				}																								"+		
		"			}																										"+
	
		
		"			if (actualRowData==ColValue)																			"+
		"			{"+
		"				return (i+1);																							"+
		"			}"+
		"			else																									"+
		"				actualRowData='';																					"+
		"		}																											"+		
		"			return 'ROW_ERR';																						"+
		"		}catch(error)																								"+
		"		{																											"+
		"			return ('ROW_ERR');																						"+
		"		}																											"+
		"	  }";
		try {
			rowNumbers = (String)((JavascriptExecutor)webDriver).executeScript(queryIE, TableElement);
		}catch(Exception E){
			logger.error("Exception::",E);
		}
		if (rowNumbers==null || "ROW_ERR".equals(rowNumbers)||"".equals(rowNumbers))
		{
			rowNumbers="ROW_ERR";
		}
		return rowNumbers;	
	}
	
	
	
	
	

}
