package operations;

import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.support.locators.RelativeLocator;


public class UIOperations {

	WebDriver driver;

	public String performOperation(Properties p, String operation, String objectName, String objectType, String values)
	{
		System.out.println("Performing the operations");
		String capturedText=null;
		try {
			switch (operation.toUpperCase()) 
			{
			case "GOTOURL":
				driver=launchBrowser(p, objectName);
				System.out.println("In GOTOURL");
				//driver.get(p.getProperty(values));
				driver.get(values);
				return "PASS";
				//break;
			case "SETTEXT":
				System.out.println("In SETTEXT");
				driver.findElement(this.getObject(p, objectName, objectType)).sendKeys(values);
				return "PASS";
				//break;
			case "CLICK":
				JavascriptExecutor jse=(JavascriptExecutor)driver;
				WebElement ele=driver.findElement(this.getObject(p, objectName, objectType));
				jse.executeScript("arguments[0].click()", ele);
				return "PASS";
				//break;
			case "GETTEXT":
				capturedText=driver.findElement(this.getObject(p, objectName, objectType)).getText();
				return capturedText;
				//break;
			case "CLOSEBROWSER":
				driver.quit();
				return "PASS";
				//break;
			default:
				//driver.quit();
				return "No Keyword Match";
			}
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			return e.toString();
		}
	}

	private By getObject(Properties p, String objectName, String objectType) throws Exception
	{
		if(objectType.equalsIgnoreCase("XPATH"))
			return By.xpath(objectName);
		else if(objectType.equalsIgnoreCase("ID"))
			return By.id(objectName);
		else if(objectType.equalsIgnoreCase("CLASSNAME"))
			return By.className(objectName);
		else if(objectType.equalsIgnoreCase("NAME"))
			return By.name(objectName);
		else if(objectType.equalsIgnoreCase("CSS"))
			return By.cssSelector(objectName);
		else if(objectType.equalsIgnoreCase("LINKTEXT"))
			return By.linkText(objectName);
		else if(objectType.equalsIgnoreCase("PARTIALLINK"))
			return By.partialLinkText(objectName);
		else if(objectType.equalsIgnoreCase("TAG"))
			return By.tagName(objectName);
		else if(objectType.equalsIgnoreCase("ABOVE"))
		{
			WebElement el=driver.findElement(RelativeLocator.with(By.xpath("input")));
			return RelativeLocator.with(By.xpath(objectName)).above(el);
		}
		else
			throw new Exception("Incorrect object type");
	}

	/**
	 * @param p
	 * @param browserName
	 * @return
	 */
	public WebDriver launchBrowser(Properties p, String browserName)
	{
		WebDriver driver=null;
		String browser=null;
		try {
			if(browserName.isEmpty()||browserName.equalsIgnoreCase("NA"))
				browser=p.getProperty("browserName");
			else 
				browser=browserName;

			if (browser.equalsIgnoreCase("chrome"))
			{
				System.setProperty(p.getProperty("chromeKey"), p.getProperty("driversPath")+"\\chromedriver.exe");
				driver=new ChromeDriver();
				driver.manage().window().maximize();
				driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
			}

			else if (browser.equalsIgnoreCase("ie"))
			{
				System.setProperty(p.getProperty("ieKey"), p.getProperty("driversPath")+"\\IEDriverServer.exe");

				/*DesiredCapabilities ieCapabilities = DesiredCapabilities.htmlUnit();
				 */
				InternetExplorerOptions options=new InternetExplorerOptions();
				options.setCapability("browserName","internet explorer");
				/*options.setCapability("nativeEvents", false);
				options.setCapability("unexpectedAlertBehaviour", "accept");
				options.setCapability("ignoreProtectedModeSettings", true);
				options.setCapability("disable-popup-blocking", true);
				options.setCapability("enablePersistentHover", true);
				 */
				options.setCapability("ignoreZoomSetting", true);
				driver=new InternetExplorerDriver(options);
				driver.manage().window().maximize();
				driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
			}
			else if (browser.equalsIgnoreCase("firefox"))
			{
				System.setProperty(p.getProperty("firefoxKey"), p.getProperty("driversPath")+"\\geckodriver.exe");
				FirefoxOptions options=new FirefoxOptions();
				options.setCapability("moz:debuggerAddress", false);
				driver=new FirefoxDriver(options);
				driver.manage().window().maximize();
				driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
			}
			else if (browser.equalsIgnoreCase("edge"))
			{
				System.setProperty(p.getProperty("edgeKey"), p.getProperty("driversPath")+"\\msedgedriver.exe");
				driver=new EdgeDriver();
				driver.manage().window().maximize();
				driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
				//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			}
		}
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return driver;
	}
}

