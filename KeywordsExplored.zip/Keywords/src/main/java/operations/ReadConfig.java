package operations;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ReadConfig {

	Properties properties= new Properties();

	public Properties getConfig() throws IOException
	{
		//InputStream is=new FileInputStream(new File(System.getProperty("user.dir")+ "\\Keywords\\src\\main\\java\\config\\config.properties"));
		//InputStream is=new FileInputStream(new File(System.getProperty("user.dir")+"\\src\\main\\java\\config\\config.properties"));
		InputStream is=new FileInputStream(new File(System.getProperty("user.dir")+"\\src\\main\\java\\config\\test_config.properties"));
		properties.load(is);
		return properties;
	}
}
