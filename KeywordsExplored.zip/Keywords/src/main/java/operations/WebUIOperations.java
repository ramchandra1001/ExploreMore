package operations;

import java.awt.RenderingHints.Key;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.apache.poi.hpsf.Array;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.devtools.Event;
import org.openqa.selenium.devtools.SeleniumCdpConnection;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.locators.RelativeLocator;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.internal.AbstractParallelWorker.Arguments;

import io.netty.handler.codec.http.Cookie;
import net.bytebuddy.asm.Advice.Argument;

public class WebUIOperations {

	WebDriver driver;
	WebElement element;
	JavascriptExecutor jse;

	public String performOperation(Properties p, String action, String param1, String param2, String param3, String param4, String param5, String param6, String param7, String param8, String param9)
	{
		System.out.println("Performing the operations");
		String result=null;
		int miliSec=0;
		WebElement element=null;

		jse=(JavascriptExecutor)driver;

		try {
			switch (action.toUpperCase()) 
			{
			case "LAUNCHBROWSER":
				System.out.println("In launch browser");
				if (!(param1.isEmpty()))
				{
					result=launchBrowser(p, param1, param2, param3, param4, param5, param6);
					return result;
				}
				else
				{
					return "URL is missing in param1.";
				}

			case "CLOSEBROWSER":

				//Writing the cookies to file 
				if(param2.equalsIgnoreCase("Y"))
				{
					File file=new File(System.getProperty("user.dir")+"\\Cookies\\Cookies.data");

					file.delete();
					file.createNewFile();
					FileWriter fw=new FileWriter(file);
					BufferedWriter bw=new BufferedWriter(fw);
					for(org.openqa.selenium.Cookie ck: driver.manage().getCookies()) 
					{ 
						bw.write((ck.getName()+";"+ck.getValue()+";"+ck.getDomain()+";"+ck.getPath()+";"+ck.getExpiry()+";"+ck.isSecure())); 
						bw.newLine(); 
					}
					bw.close();
					fw.close();
				}

				//Closing the IE browser along with confirmation popup
				if (param1.equalsIgnoreCase("Y") && p.getProperty("browserName").equalsIgnoreCase("ie"))
				{
					driver.close();
					driver.switchTo().alert().accept();
					driver.quit();
				}

				//TaskKIll
				if(param3.equalsIgnoreCase("Y"))
				{
					String []cmd={"taskkill /F /IM chrome.exe","taskkill /F /IM iexplore.exe","taskkill /F /IM firefox.exe","taskkill /F /IM msedge.exe"};
					Runtime.getRuntime().exec(cmd);
				}

				driver.quit();

				return "Browser closed";

			case "ENTERTEXTVALUE":
				System.out.println("In ENTERTEXTVALUE");
				WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(5));
				wait.until(ExpectedConditions.visibilityOfElementLocated(this.getObject(p, action, param1, param2, param3, param4, param5, param6)));

				element=driver.findElement(this.getObject(p, action, param1, param2, param3, param4, param5, param6));

				//Clear the text box
				if (param4.equalsIgnoreCase("Y")) 
					element.clear();

				//Enter values with Java script or just sendKeys
				if (param5.equalsIgnoreCase("Y")) 
				{	
					element.click();
					jse.executeScript("arguments[0].focus();arguments[0].value='"+param2+"';", element); 
				}
				else
					element.sendKeys(param2);

				//Fire Event ONCHANGE
				if (param6.equalsIgnoreCase("Y"))
				{
					element.sendKeys(Keys.TAB);
					jse.executeScript("$(arguments[0]).change(); return true;",element);
					//jse.executeScript("arguments[0].onchange();",element);
					//jse.executeScript("arguments[0].fireEvent('onchange');",element);
				}

				return "PASS";

			case "SENDINPUTTOOBJECT":
				System.out.println("In SENDINPUTTOOBJECT");
				element=driver.findElement(this.getObject(p, action, param1, param2, param3, param4, param5, param6));

				//Clear the text box
				if (param4.equalsIgnoreCase("Y")||param4.isEmpty()) 
					element.clear();

				//Enter values with keystrokes or just sendKeys
				if (param5.equalsIgnoreCase("Y")||param5.isEmpty()) 
				{
					for (int i = 0; i < param2.length(); i++)
					{
						char c = param2.charAt(i);
						String s = new StringBuilder().append(c).toString();
						element.sendKeys(s);
					} 
					element.sendKeys(Keys.TAB);
				}
				else
					element.sendKeys(param2);

				return "PASS";

			case "GLOBALWAIT":
				System.out.println("In GLOBALWAIT");
				miliSec=(Integer.parseInt(param1))*1000;
				Thread.sleep(miliSec);
				return "PASS";

			case "CLICKBUTTON":
				//JavascriptExecutor jse=(JavascriptExecutor)driver;
				element=driver.findElement(this.getObject(p, action,param1, param2, param3, param4, param5, param6));
				element.click();
				//Actions act= new Actions(driver);
				//act.click(element);
				//jse.executeScript("arguments[0].click()", element);
				return "PASS";

				/*			case "GETTEXT":
				capturedText=driver.findElement(this.getObject(p, objectName, objectType)).getText();
				return capturedText;
				//break;
			case "CLOSEBROWSER":
				driver.quit();
				return "PASS";
				//break;
				 */			
			default:
				return "No Keyword Match";
			}
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			return e.toString();
		}
	}

	private By getObject(Properties p, String action, String param1, String param2, String param3, String param4, String param5, String param6) throws Exception
	{

		//Default index is 1

		if(param1.startsWith("@xpath="))
		{
			if (param3.isEmpty()||Integer.parseInt(param3)==0||Integer.parseInt(param3)==1)
				return By.xpath(param1.split("@xpath=")[1].trim()+"[1]");
			else
				return By.xpath(param1.split("@xpath=")[1].trim()+"["+Integer.parseInt(param3)+"]");
		}
		else if(param1.startsWith("@name="))
		{
			if (param3.isEmpty()||Integer.parseInt(param3)==0||Integer.parseInt(param3)==1)
				return By.name(param1.split("@name=")[1].trim());
			else
				return By.xpath("//*[@name="+param1.split("@name=")[1].trim()+"]"+"["+Integer.parseInt(param3)+"]");
		}
		else if(param1.startsWith("@id="))
		{
			if (param3.isEmpty()||Integer.parseInt(param3)==0||Integer.parseInt(param3)==1)
				return By.id(param1.split("@id=")[1].trim());
			else
				return By.xpath("//*[@id="+param1.split("@id=")[1].trim()+"]"+"["+Integer.parseInt(param3)+"]");
		}

		/*		else if(param1.startsWith("@id="))
			return By.id(param1.split("@id=")[1].trim()+"["+elementIndex+"]");
		else if(param1.startsWith("@name="))
			return By.name(param1.split("@name=")[1].trim()+"["+elementIndex+"]");
		else if(objectType.equalsIgnoreCase("CLASSNAME"))
			return By.className(objectName);
		else if(objectType.equalsIgnoreCase("NAME"))
			return By.name(objectName);
		else if(objectType.equalsIgnoreCase("CSS"))
			return By.cssSelector(objectName);
		else if(objectType.equalsIgnoreCase("LINKTEXT"))
			return By.linkText(objectName);
		else if(objectType.equalsIgnoreCase("PARTIALLINK"))
			return By.partialLinkText(objectName);
		else if(objectType.equalsIgnoreCase("TAG"))
			return By.tagName(objectName);
		else if(objectType.equalsIgnoreCase("ABOVE"))
		{
			WebElement el=driver.findElement(RelativeLocator.with(By.xpath("input")));
			return RelativeLocator.with(By.xpath(objectName)).above(el);
		}*/
		else
			throw new Exception("Incorrect object type");
	}

	/**
	 * @param p
	 * @param browserName
	 * @return
	 */
	public String launchBrowser(Properties p, String param1, String param2, String param3, String param4, String param5, String param6)
	{
		String browser=null;
		int pageLoadTime=0;
		//WebDriver driver=null;
		String language="en-us";

		if (!(param5.isEmpty())||!(param5.equalsIgnoreCase("en-us")))
		{	
			language=param5.trim();
		}

		try {

			if(p.getProperty("browserName").equalsIgnoreCase("NA")||p.getProperty("browserName").isEmpty())
				browser="Chrome";
			else 
				browser=p.getProperty("browserName");

			if(param3.isEmpty())
				pageLoadTime=Integer.parseInt(p.getProperty("PageLoadTime"));
			else 
				pageLoadTime=Integer.parseInt(param3);

			if (browser.equalsIgnoreCase("chrome"))
			{
				System.setProperty(p.getProperty("chromeKey"), p.getProperty("driversPath")+"\\chromedriver.exe");
				ChromeOptions options=new ChromeOptions();
				options.addArguments("--lang="+language);
				driver=new ChromeDriver(options);
			}

			else if (browser.equalsIgnoreCase("ie"))
			{
				System.setProperty(p.getProperty("ieKey"), p.getProperty("driversPath")+"\\IEDriverServer.exe");

				/*DesiredCapabilities ieCapabilities = DesiredCapabilities.htmlUnit();
				 */
				InternetExplorerOptions options=new InternetExplorerOptions();
				options.setCapability("browserName","internet explorer");
				/*options.setCapability("nativeEvents", false);
				options.setCapability("unexpectedAlertBehaviour", "accept");
				options.setCapability("ignoreProtectedModeSettings", true);
				options.setCapability("disable-popup-blocking", true);
				options.setCapability("enablePersistentHover", true);
				 */
				options.setCapability("ignoreZoomSetting", true);
				driver=new InternetExplorerDriver(options);
			}
			else if (browser.equalsIgnoreCase("firefox"))
			{
				System.setProperty(p.getProperty("firefoxKey"), p.getProperty("driversPath")+"\\geckodriver.exe");
				FirefoxOptions options=new FirefoxOptions();
				options.setCapability("moz:debuggerAddress", false);
				driver=new FirefoxDriver(options);
			}
			else if (browser.equalsIgnoreCase("edge"))
			{
				System.setProperty(p.getProperty("edgeKey"), p.getProperty("driversPath")+"\\msedgedriver.exe");
				driver=new EdgeDriver();
			}

			//Maximize browser
			if(!(param6.isEmpty())||param6.equalsIgnoreCase("Y")||param6.equalsIgnoreCase("yes")||param6.equalsIgnoreCase("true"))	
				driver.manage().window().maximize();

			//Launching the URL
			driver.get(param1);

			//Launching the page with stored cookies
			if(param4.equalsIgnoreCase("Y"))
			{
				File file=new File(System.getProperty("user.dir")+"\\Cookies\\Cookies.data");
				FileReader fileReader = new FileReader(file);

				BufferedReader Buffreader = new BufferedReader(fileReader);
				String strline=null;

				while((strline=Buffreader.readLine())!=null)
				{
					StringTokenizer token = new StringTokenizer(strline,";");
					while(token.hasMoreTokens())
					{
						String name = token.nextToken();
						String value = token.nextToken();
						String domain = token.nextToken();
						String path = token.nextToken();
						Date expiry = null;
						String val;
						SimpleDateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
						if(!(val=token.nextToken()).equals("null"))
						{
							expiry = formatter.parse(val);
						}
						Boolean isSecure = new Boolean(token.nextToken()).booleanValue();

						org.openqa.selenium.Cookie ck=new org.openqa.selenium.Cookie(name, value, domain, path, expiry, isSecure);
						//Cookie ck = new Cookie(name,value,domain,path,expiry,isSecure);
						driver.manage().addCookie(ck);
					}
				}
				Buffreader.close();
				driver.get(param1);
			}

			//Implicit wait
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(pageLoadTime));

			//SkippURLValidation
			if (!(param2.equalsIgnoreCase("skipURLValidation")||param2.isEmpty()))
			{
				driver.getCurrentUrl().equalsIgnoreCase(param1);
			}
		}
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			return e.toString();
		}

		return "Browser Launched";
	}
}

