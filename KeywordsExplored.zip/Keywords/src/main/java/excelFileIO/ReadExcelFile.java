package excelFileIO;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelFile {
	
public Sheet readExcel(String excelFilePath, String excelFileName, String excelSheetName)
{
	Workbook excelWorkBook=null;
	Sheet sheet=null;
	try 
	{
		File excel=new File(excelFilePath+"\\"+excelFileName);
		FileInputStream fis=new FileInputStream(excel);
		
		String excelExtension=excelFileName.substring(excelFileName.indexOf("."));
		
		if (excelExtension.equalsIgnoreCase(".xlsx"))
		{
			excelWorkBook=new XSSFWorkbook(fis);
			System.out.println(".xlsx file");
		}
		
		else if (excelExtension.equalsIgnoreCase(".xls"))
		{
			excelWorkBook=new HSSFWorkbook(fis);
			System.out.println(".xls file.");
		}
		
		sheet = excelWorkBook.getSheet(excelSheetName);
		fis.close();
	}
	catch (IOException e) {
		System.out.println(e.getStackTrace());
	}
	finally {
		System.out.println("Read excel completed.");
	}
	
	return sheet;
	
}
}