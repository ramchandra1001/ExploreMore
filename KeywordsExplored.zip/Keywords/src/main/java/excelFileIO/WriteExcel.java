package excelFileIO;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.xml.serializer.OutputPropertyUtils;

public class WriteExcel {

	public void writeToExcel(String excelFilePath, String excelFileName, String sheetName, int rowNum, int colNum, String value, String testID, String testDescription) throws IOException
	{
		Workbook optWorkbook=null;

		File optFile= new File(excelFilePath+"\\"+excelFileName);
		FileInputStream fis=new FileInputStream(optFile);

		String optExcelExtension=excelFileName.substring(excelFileName.indexOf("."));

		if (optExcelExtension.equalsIgnoreCase(".xlsx"))
		{
			optWorkbook=new XSSFWorkbook(fis);
			System.out.println("Write Excel .xlsx file");
		}

		else if (optExcelExtension.equalsIgnoreCase(".xls"))
		{
			optWorkbook=new HSSFWorkbook(fis);
			System.out.println("Write excel .xls file.");
		}

		Sheet outputSheet=optWorkbook.getSheet(sheetName);

		System.out.println("Input " +sheetName +rowNum +colNum);
		
		for (int i=0; i<3;i++)
		{
			//scriptSheet.getRow(rowNum).getCell(0).setCellValue(value);
			
			if (i==0)
			{
				outputSheet.createRow(rowNum).createCell(i).setCellValue(testID);
			}
			else if (i==1)
			{
				outputSheet.getRow(rowNum).createCell(i).setCellValue(testDescription);
			}
			else if(i==2)
			{
				outputSheet.getRow(rowNum).createCell(colNum).setCellValue(value);
			}
		}
		
		FileOutputStream fos=new FileOutputStream(optFile);
		optWorkbook.write(fos);
		fos.close();
		
		System.out.println("Output written to the excel.");	
	}
}
