package testCases;

import java.util.Properties;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import excelFileIO.ReadExcelFile;
import excelFileIO.WriteExcel;
import operations.ReadConfig;
import operations.UIOperations;
import operations.WebUIOperations;

public class RunSAFALTest {

	@Test
	public void runTest() throws Exception
	{
		int rowCount;
		String getText=null;
		
		ReadExcelFile readExcelFile=new ReadExcelFile();
		WriteExcel writeExcel=new WriteExcel();
		ReadConfig rc=new ReadConfig();
		Properties prop=rc.getConfig();
		WebUIOperations uiOperation=new WebUIOperations();
		
		Sheet sheet= readExcelFile.readExcel(prop.getProperty("scriptWorkbookPath").toString(),prop.getProperty("scriptWorkbookName").toString(), prop.getProperty("scriptSheetName").toString());
		rowCount=sheet.getLastRowNum()-sheet.getFirstRowNum();
		System.out.println("Row Count:"+rowCount);
		
		for (int i = 1; i <= rowCount; i++) 
		{
			Row row=sheet.getRow(i);
			if (row.getCell(Integer.parseInt(prop.getProperty("actionIndex"))).toString().length()>0)
			{
				System.out.println("In "+ row.getCell(1).toString()+" " + row.getCell(6).toString()) ;
				getText=uiOperation.performOperation(prop, row.getCell(Integer.parseInt(prop.getProperty("actionIndex"))).toString(), row.getCell(Integer.parseInt(prop.getProperty("param1"))).toString(), row.getCell(Integer.parseInt(prop.getProperty("param2"))).toString(), row.getCell(Integer.parseInt(prop.getProperty("param3"))).toString(), row.getCell(Integer.parseInt(prop.getProperty("param4"))).toString(), row.getCell(Integer.parseInt(prop.getProperty("param5"))).toString(), row.getCell(Integer.parseInt(prop.getProperty("param6"))).toString(), row.getCell(Integer.parseInt(prop.getProperty("param7"))).toString(), row.getCell(Integer.parseInt(prop.getProperty("param8"))).toString(), row.getCell(Integer.parseInt(prop.getProperty("param9"))).toString());
				writeExcel.writeToExcel(prop.getProperty("outputWorkbookPath").toString(),prop.getProperty("outputWorkbookName").toString(), prop.getProperty("outputSheetName").toString(), i, 2,getText,row.getCell(Integer.parseInt(prop.getProperty("testIdIndex"))).toString(),row.getCell(Integer.parseInt(prop.getProperty("testDescriptionIndex"))).toString());
			}
			else
			{
				System.out.println("Blank row");
			}
		}
	}
}
