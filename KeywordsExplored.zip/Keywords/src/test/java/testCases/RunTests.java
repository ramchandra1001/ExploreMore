package testCases;

import java.util.Properties;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import excelFileIO.ReadExcelFile;
import excelFileIO.WriteExcel;
import operations.ReadConfig;
import operations.UIOperations;

public class RunTests {

	@Test
	public void runTest() throws Exception
	{
		int rowCount;
		String getText=null;
		
		ReadExcelFile readExcelFile=new ReadExcelFile();
		WriteExcel writeExcel=new WriteExcel();
		ReadConfig rc=new ReadConfig();
		Properties prop=rc.getConfig();
		UIOperations uiOperation=new UIOperations();
		
		Sheet sheet= readExcelFile.readExcel(prop.getProperty("scriptWorkbookPath").toString(),prop.getProperty("scriptWorkbookName").toString(), prop.getProperty("scriptSheetName").toString());
		rowCount=sheet.getLastRowNum()-sheet.getFirstRowNum();
		System.out.println("Row Count:"+rowCount);
		
		for (int i = 1; i <= rowCount; i++) 
		{
			Row row=sheet.getRow(i);
			if (row.getCell(Integer.parseInt(prop.getProperty("actionIndex"))).toString().length()>0)
			{
				System.out.println("In "+ row.getCell(1).toString()+" " + row.getCell(2).toString()) ;
				getText=uiOperation.performOperation(prop, row.getCell(Integer.parseInt(prop.getProperty("actionIndex"))).toString(), row.getCell(Integer.parseInt(prop.getProperty("locatorIndex"))).toString(), row.getCell(Integer.parseInt(prop.getProperty("locatorTypeIndex"))).toString(), row.getCell(Integer.parseInt(prop.getProperty("valueIndex"))).toString());
				writeExcel.writeToExcel(prop.getProperty("outputWorkbookPath").toString(),prop.getProperty("outputWorkbookName").toString(), prop.getProperty("outputSheetName").toString(), i, 2,getText,row.getCell(Integer.parseInt(prop.getProperty("testIdIndex"))).toString(),row.getCell(Integer.parseInt(prop.getProperty("testDescriptionIndex"))).toString());
			}
			else
			{
				System.out.println("Blank row");
			}
		}
	}
}
