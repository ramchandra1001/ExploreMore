package demo.demo.MavenDemo;

import org.testng.annotations.Test;
import org.testng.annotations.Test;

public class SeleniumTest {
	
	@Test
	public void browserAutomation()
	{
		System.out.println("Selenium test");
	}

	@Test
	public void browserAutomation2()
	{
		System.out.println("Selenium test2");
	}

}
