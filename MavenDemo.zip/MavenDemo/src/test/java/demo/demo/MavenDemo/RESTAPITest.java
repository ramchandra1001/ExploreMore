package demo.demo.MavenDemo;

import org.testng.annotations.Test;
import org.testng.annotations.Test;

public class RESTAPITest {

	@Test
	public void restAutomation()
	{
		System.out.println("Rest test");
	}

	@Test
	public void restAutomation2()
	{
		System.out.println("Rest test2");
	}

}
