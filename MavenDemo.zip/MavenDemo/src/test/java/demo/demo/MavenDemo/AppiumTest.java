package demo.demo.MavenDemo;

import org.testng.annotations.Test;
import org.testng.annotations.Test;

public class AppiumTest {
	
	@Test
	public void appTest()
	{
		System.out.println("App test");
	}

	@Test
	public void appTest2()
	{
		System.out.println("App test2");
	}


}
