package tests;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.annotations.Test;

public class day1 {

	@Test (groups={"smoke"})
	public void demo()
	{
		System.out.println("Demo enabled");
	}

	@Test (groups={"smoke"},enabled=true)
	public void demo22()
	{
		System.out.println("Demo disabled");
	}
	
	@Parameters({"URL"})
	@Test
	public void params(String url)
	{
		System.out.println("parameters:"+url );
	}
	
	
	@Test (dependsOnMethods={"demo"}, dataProvider="getData")
	public void demo2(String user, String pass)
	{
		System.out.println("Demo2: "+user +" "+pass);
	}
	
	@BeforeMethod
	public void dem0()
	{
		System.out.println("Before methods");
		
	}
	
	@AfterMethod
	public void dem0o()
	{
		System.out.println("After methods");
	}
	
	@DataProvider
	public Object getData()
	{
		Object[][] data= new Object[3][2];
		
		data[0][0]="firstusername";
		data[0][1]="passowrd";
		
		data[1][0]="firstusername2";
		data[1][1]="passowrd2";
		
		data[2][0]="firstusername3";
		data[2][1]="passowrd3";
		
		return data;
	}

}
