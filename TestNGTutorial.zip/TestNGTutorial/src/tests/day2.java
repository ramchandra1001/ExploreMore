package tests;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.annotations.Test;

public class day2 {

	@Test(groups={"smoke"})
	public void demo3()
	{
		System.out.println("Demo3");
	}
	
	@Test
	public void demo31()
	{
		System.out.println("Demo33");
	}
	
	@BeforeSuite
	public void demo7()
	{
		System.out.println("Before suite");
	}
	
	@AfterSuite
	public void demo8()
	{
		System.out.println("After suite");
	}
	
	@BeforeTest
	public void demo4()
	{
		System.out.println("Before Test");
	}
	@AfterTest
	public void demo5()
	{
		System.out.println("After test");
	}

	@BeforeMethod
	public void demo9()
	{
		System.out.println("Before Method");
	}
	
	@AfterMethod
	public void demo10()
	{
		System.out.println("After Method");
	}
}
