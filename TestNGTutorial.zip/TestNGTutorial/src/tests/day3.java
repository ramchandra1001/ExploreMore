package tests;

import org.testng.annotations.Test;
import org.testng.annotations.Test;

public class day3 {

	@Test
	public void webloginCarloan()
	{
		System.out.println("weblogin");
	}

	@Test (groups={"smoke"})
	public void mobileloginCarloan()
	{
		System.out.println("mobilelogin");
	}

	@Test
	public void loginAPI()
	{
		System.out.println("API test");
	}
	
}
