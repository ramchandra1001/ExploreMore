
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import java.util.stream.Collectors;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.neilalexander.jnacl.crypto.hsalsa20;

import junit.framework.Assert;

public class StreamTest {

	//@Test
	public void regular()
	{

		ArrayList<String> a= new ArrayList<String>();
		a.add("Atul");
		a.add("Ram");
		a.add("Aman");
		a.add("Rahul");
		a.add("John");
		int count=0;
		for (int i=0; i<a.size();i++)
		{
			if(a.get(i).startsWith("A"))
			{
				count++;
			}
		}
		System.out.println(count);
	}

	@Test
	public void streamFilter()
	{
		ArrayList<String> names= new ArrayList<String>();
		names.add("Atul");
		names.add("Ram");
		names.add("Aman");
		names.add("Rahul");
		names.add("John");

		String s="dasdTDSJK1234dkjsh";
		char c[]=s.toCharArray();
		HashSet hs= new HashSet();
		for(int i=0;i<c.length;i++)
		{
			hs.add(c[i]);
		}
		
		System.out.println(hs.stream().sorted().collect(Collectors.toList()));
		
		//Stream.of("Atul","Ram","Aman","Rahul","John");
		///Prints number of names starts with A
		System.out.println(names.stream().filter(n->n.startsWith("A")).count());

		///Print number of names having length more than 3
		names.stream().filter(n->n.length()>3).forEach(n->System.out.println(n));
		

	}

	//@Test
	public void streamMap()
	{
		ArrayList<String> names2= new ArrayList<String>();
		names2.add("Atul");
		names2.add("Ram");
		names2.add("Aman");
		names2.add("Rahul");
		names2.add("John");

		//names ends with "n" in upper case
		names2.stream().filter(s->s.endsWith("n")).map(s->s.toUpperCase()).forEach(s->System.out.println(s));
		//names starts with "R" in upper case	and sorted order	
		names2.stream().filter(s->s.startsWith("R")).map(s->s.toUpperCase()).sorted().forEach(s->System.out.println(s));

	}

	//@Test
	public void streamCollect()
	{
		ArrayList<String> names3= new ArrayList<String>();
		names3.add("Atul");
		names3.add("Rahul");
		names3.add("Ram");
		names3.add("Aman");
		names3.add("Rahul");
		names3.add("John");
		names3.add("Aman");

		List<String> ls= names3.stream().filter(s->s.endsWith("n")).map(s->s.toUpperCase()).collect(Collectors.toList());
		System.out.println(ls.get(0));

		names3.stream().distinct().sorted().forEach(s->System.out.println(s));

	}

	//@Test
	public void verifyFruits()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Projects\\SAFAL21.3Latest\\SafalConfigs\\Drivers\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/offers");	

		driver.findElement(By.xpath("//tr/th[1]")).click();

		//Compare the list of fruits are in sorted order or not after clicking on column header
		//List<WebElement> elementList=driver.findElements(By.xpath("//tr/td[1]"));

		///List<String> originalList=elementList.stream().map(s->s.getText()).collect(Collectors.toList());
		//List<String> sortedList=originalList.stream().sorted().collect(Collectors.toList());

		///Assert.assertTrue(originalList.equals(sortedList));

		List<String> price;

		//get the price of fruit beans/rice
		do
		{
			List<WebElement> elementList=driver.findElements(By.xpath("//tr/td[1]"));
			price= elementList.stream().filter(s->s.getText().contains("Rice")).map(s->getVegiesPrice(s)).collect(Collectors.toList());
			price.forEach(s->System.out.println(s));
			
			if(price.size()<1)
			{
				driver.findElement(By.cssSelector("[aria-label='Next']")).click();
			}
		}while(price.size()<1);
		
		}

		public static String getVegiesPrice(WebElement element)
		{
			String price=element.findElement(By.xpath("following-sibling::td[1]")).getText();
			return price;
		}
		
		//@Test
		public void filterWebtable()
		{
			System.setProperty("webdriver.chrome.driver", "C:\\Projects\\SAFAL21.3Latest\\SafalConfigs\\Drivers\\chromedriver.exe");
			WebDriver driver= new ChromeDriver();
			driver.get("https://rahulshettyacademy.com/seleniumPractise/#/offers");	

			driver.findElement(By.id("search-field")).sendKeys("Rice");
			
			List<WebElement> veggies=driver.findElements(By.xpath("//tr//td[1]"));
			List<WebElement> filteredList=veggies.stream().filter(s->s.getText().equals("Rice")).collect(Collectors.toList());
			
			Assert.assertEquals(veggies.size(), filteredList.size());
			
			
		}

	}
