

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class SelIntroduction {

	
	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Projects\\SAFAL21.3Latest\\SafalConfigs\\Drivers\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("https://www.google.co.in");	
		//AssertJUnit.assertEquals(driver.getTitle(), "Google");
		driver.close();

	}

	
}