package stepDefinitions;

import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.cucumber.java.en.And;
import io.cucumber.java.en.*;
import io.cucumber.junit.Cucumber;


@RunWith(Cucumber.class)
public class StepDefinition {

	@Given("User is on NetBanking landing page")
	public void user_is_on_netbanking_landing_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Projects\\Eclipse_Learning\\CCAutomation\\Drivers\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("https://www.google.co.in");
	}

	@When("User login into application with {string} and password {string}")
	public void user_login_into_application_with_and_password(String string1, String string2) throws Throwable {
		System.out.println("In When: "+string1 +" "+string2);
	}

	@Then("Home page is populated")
	public void home_page_is_populated() throws Throwable {
		System.out.println("In then");
	}

	@And("Cards displayed are {string}")
	public void cards_are_displayed(String string1) throws Throwable {
		System.out.println("In And:"+string1);
	}

}